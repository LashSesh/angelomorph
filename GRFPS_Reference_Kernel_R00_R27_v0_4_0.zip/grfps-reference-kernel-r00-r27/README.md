# GRFPS Reference Kernel — R00–R27

**Version:** 0.4.0  
**Normative parent:** GRFPS v3.0.0 — Generative Rotor-Fiber Perceptual Substrate  
**Stage:** Perceptual-OS reference vertical through blind multiscale navigation and Desktop Second Layer

```text
R00–R05  Machine Floor + Perceptual Genome Compiler
R06–R11  Adaptive Ophan Field
R12–R19  Graph-Infogenetic Cartography + Reflection Region
R20–R27  Scale Lattice + Gyrosphere + Axis/Compass + Attractor + Second Layer + Blind Witness
```

## Executable normal form

```text
PerceptualGenome
 -> Adaptive Ophan Field
 -> GraphInfogenome / Gluing / Nerve
 -> Mirror / Reflection Region / Phase Horizon
 -> Multiscale Lattice / Gyrosphere
 -> Attractor Potential / Axis / Tangent Compass
 -> Density Materialization / Desktop Second Layer
 -> Blind Witness / Replay
```

## Conformance

```bash
./run_conformance.sh
```

The W24 reference world begins with a mesoscopic direction fan, lifts to micro resolution, locks an axis, performs three topological advances and reaches the structurally encoded attractor. The desktop harness renders the machine state as deterministic SVG/HTML with complete provenance.

## Canonical handoff

`conformance/r20-r27-exit.json` is the parent artifact for R28. The next vertical is `Sedimentation Lineage -> Real-time Carrier Interface -> XR Prototype -> Capability Release`.
