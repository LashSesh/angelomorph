#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export PYTHONPATH="$ROOT/python:$ROOT/tests"
python3 "$ROOT/scripts/build_conformance.py" > "$ROOT/conformance/r00-r05-build-log.txt"
python3 "$ROOT/scripts/build_r06_r11_conformance.py" > "$ROOT/conformance/r06-r11-build-log.txt"
python3 "$ROOT/scripts/build_r12_r19_conformance.py" > "$ROOT/conformance/r12-r19-build-log.txt"
python3 "$ROOT/scripts/build_r20_r27_conformance.py" > "$ROOT/conformance/r20-r27-build-log.txt"
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest "$ROOT/tests" -q | tee "$ROOT/conformance/test-log.txt"
if command -v cargo >/dev/null 2>&1; then
  cargo test --workspace --quiet | tee "$ROOT/conformance/cargo-test-log.txt"
fi
