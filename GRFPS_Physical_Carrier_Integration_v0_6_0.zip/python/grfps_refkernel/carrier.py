from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from math import cos, sin
from statistics import mean
from typing import Any, Iterable

from .canon import digest_record


@dataclass(frozen=True)
class CarrierConfig:
    carrier_id: str = "carrier.sim.reference-v1"
    frame_rate_hz: float = 90.0
    frame_count: int = 180
    base_display_latency_ms: float = 11.1
    base_input_latency_ms: float = 4.0
    fov_deg: float = 100.0
    calibration_ref: str = "calibration.reference-v1"


class CarrierSimulator:
    """Deterministic implementation of the GRFPS Carrier Interface.

    It emulates the continuous contract before hardware binding. Time is a
    declared synthetic monotonic clock, making the reference run replayable.
    """

    SCENARIOS = ("nominal", "tracking_loss", "clock_drift", "occlusion", "latency_spike")

    def __init__(self, config: CarrierConfig | None = None):
        self.config = config or CarrierConfig()
        self.dt_ns = int(round(1_000_000_000 / self.config.frame_rate_hz))

    @staticmethod
    def _quat_yaw(theta: float) -> list[float]:
        return [0.0, sin(theta / 2.0), 0.0, cos(theta / 2.0)]

    def _tracking(self, scenario: str, i: int) -> str:
        if scenario == "tracking_loss" and 54 <= i < 63:
            return "LOST"
        if scenario == "tracking_loss" and 63 <= i < 68:
            return "REACQUIRED"
        return "TRACKED"

    def frame(self, scenario: str, i: int) -> dict[str, Any]:
        if scenario not in self.SCENARIOS:
            raise ValueError(scenario)
        drift_ns = (i * 75_000) if scenario == "clock_drift" else 0
        clock_ns = i * self.dt_ns + drift_ns
        tracking = self._tracking(scenario, i)
        theta = 0.0075 * i
        position = [0.001 * i, 0.015 * sin(theta), 0.02 * cos(theta)]
        orientation = self._quat_yaw(theta)
        occ = []
        if scenario == "occlusion" and 70 <= i < 105:
            occ = [{"kind": "rect", "normalized": [0.35, 0.25, 0.65, 0.72], "confidence": 1.0}]
        display_latency = self.config.base_display_latency_ms + (18.0 if scenario == "latency_spike" and 80 <= i < 110 else 0.0)
        input_latency = self.config.base_input_latency_ms + (12.0 if scenario == "latency_spike" and 80 <= i < 110 else 0.0)
        fov = self.config.fov_deg - (25.0 if scenario == "occlusion" and occ else 0.0)
        calibration_sigma = 0.0015 + 0.000015 * (i % 11)
        registration_error = calibration_sigma * (3.0 if tracking == "LOST" else 1.0)
        frame = {
            "carrier_id": self.config.carrier_id,
            "scenario": scenario,
            "frame_index": i,
            "clock_ns": clock_ns,
            "pose": {
                "position_m": position,
                "orientation_xyzw": orientation,
                "covariance_diag": [calibration_sigma] * 6,
                "tracking": tracking,
            },
            "frames": {
                "world": "FW",
                "machine": "FM",
                "human": "FH",
                "display": "FD",
                "transforms": [
                    {"source": "FW", "target": "FM", "translation_m": [0.0, 0.0, 0.0], "rotation_xyzw": [0.0,0.0,0.0,1.0], "timestamp_ns": clock_ns, "calibration_ref": self.config.calibration_ref, "uncertainty": calibration_sigma},
                    {"source": "FM", "target": "FH", "translation_m": position, "rotation_xyzw": orientation, "timestamp_ns": clock_ns, "calibration_ref": self.config.calibration_ref, "uncertainty": calibration_sigma},
                    {"source": "FH", "target": "FD", "translation_m": [0.0,0.0,0.0], "rotation_xyzw": [0.0,0.0,0.0,1.0], "timestamp_ns": clock_ns, "calibration_ref": self.config.calibration_ref, "uncertainty": calibration_sigma},
                ],
            },
            "input": {"latency_ms": input_latency, "events": []},
            "display": {"latency_ms": display_latency, "fov_deg": fov, "refresh_hz": self.config.frame_rate_hz},
            "sensors": {"pose": True, "orientation": True, "position": True},
            "occlusion": occ,
            "calibration": {"ref": self.config.calibration_ref, "registration_error_m": registration_error},
            "latency": {"display_ms": display_latency, "input_ms": input_latency, "clock_drift_ns": drift_ns},
            "capabilities": {"position_tracking": True, "orientation_tracking": True, "occlusion_mask": True, "input": ["TargetSelect","Align","Forward","Hold","Scale"]},
        }
        frame["digest"] = digest_record("GRFPS.CarrierFrame", "1.0.0", frame)
        return frame

    def run_scenario(self, scenario: str) -> dict[str, Any]:
        frames = [self.frame(scenario, i) for i in range(self.config.frame_count)]
        tracked = [f for f in frames if f["pose"]["tracking"] == "TRACKED"]
        lost = [f for f in frames if f["pose"]["tracking"] == "LOST"]
        reacquired = [f for f in frames if f["pose"]["tracking"] == "REACQUIRED"]
        errors = [f["calibration"]["registration_error_m"] for f in frames]
        display = [f["display"]["latency_ms"] for f in frames]
        inputs = [f["input"]["latency_ms"] for f in frames]
        occluded = [f for f in frames if f["occlusion"]]
        report = {
            "carrier_id": self.config.carrier_id,
            "scenario": scenario,
            "frame_count": len(frames),
            "frame_rate_hz": self.config.frame_rate_hz,
            "tracking_fraction": len(tracked) / len(frames),
            "lost_frames": len(lost),
            "reacquired_frames": len(reacquired),
            "occluded_frames": len(occluded),
            "max_registration_error_m": max(errors),
            "mean_registration_error_m": mean(errors),
            "max_display_latency_ms": max(display),
            "mean_display_latency_ms": mean(display),
            "max_input_latency_ms": max(inputs),
            "mean_input_latency_ms": mean(inputs),
            "max_clock_drift_ns": max(abs(f["latency"]["clock_drift_ns"]) for f in frames),
            "traceability_rate": 1.0,
            "replay_class": "EXACT_SIMULATED",
        }
        report["digest"] = digest_record("GRFPS.CarrierScenarioReport", "1.0.0", report, tuple(f["digest"] for f in frames))
        return {"frames": frames, "report": report}

    def run_suite(self) -> dict[str, Any]:
        scenarios = {name: self.run_scenario(name) for name in self.SCENARIOS}
        summary = {
            "carrier_id": self.config.carrier_id,
            "contract": {
                "Pose": True, "Frames": True, "Clock": True, "Input": True, "Display": True,
                "Sensors": True, "Occlusion": True, "Calibration": True, "Latency": True, "Capabilities": True,
            },
            "scenario_reports": [scenarios[name]["report"] for name in self.SCENARIOS],
            "all_traceable": all(scenarios[name]["report"]["traceability_rate"] == 1.0 for name in self.SCENARIOS),
            "replay_class": "EXACT_SIMULATED",
        }
        summary["digest"] = digest_record("GRFPS.CarrierSuite", "1.0.0", summary, tuple(x["report"]["digest"] for x in scenarios.values()))
        return {"summary": summary, "scenarios": scenarios, "digest": summary["digest"]}
