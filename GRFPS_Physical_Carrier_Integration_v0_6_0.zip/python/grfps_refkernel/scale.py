from __future__ import annotations
from collections import defaultdict, deque
from copy import deepcopy
from typing import Any
from .canon import digest_record

class ScaleLattice:
    def __init__(self, spec: dict[str, Any]):
        self.spec=deepcopy(spec)
        self.scales={str(s['id']):{'id':str(s['id']),'rank':int(s.get('rank',0))} for s in spec.get('scales',[])}
        if not self.scales: raise ValueError('empty scale lattice')
        self.quotients=[]
        for tr in spec.get('transitions',[]):
            if tr.get('kind')=='quotient':
                a,b=str(tr['source']),str(tr['target'])
                if a not in self.scales or b not in self.scales: raise ValueError('unknown scale transition')
                self.quotients.append((a,b))
        self._check_acyclic()
        self.cells={}; self.children_of=defaultdict(list); self.parents_of=defaultdict(list)

    def _check_acyclic(self):
        adj=defaultdict(list); indeg={s:0 for s in self.scales}
        for a,b in self.quotients: adj[a].append(b); indeg[b]+=1
        q=deque(sorted([s for s,d in indeg.items() if d==0])); seen=0
        while q:
            u=q.popleft(); seen+=1
            for v in sorted(adj[u]):
                indeg[v]-=1
                if indeg[v]==0:q.append(v)
        if seen!=len(self.scales): raise ValueError('cyclic scale lattice')

    def adjacent_finer(self,s): return sorted(a for a,b in self.quotients if b==s)
    def adjacent_coarser(self,s): return sorted(b for a,b in self.quotients if a==s)

    def add_cell(self,*,scale,local_id,machine_refs,position,features=None,parent_refs=None,source_ref=None):
        payload={'scale':scale,'local_id':str(local_id),'rank':self.scales[scale]['rank'],'machine_refs':sorted(set(machine_refs)),'position':[float(x) for x in position],'features':deepcopy(features or {}),'parent_refs':sorted(set(parent_refs or [])),'source_ref':source_ref}
        payload['cell_id']=digest_record('GRFPS.ScaleCellId','1.0.0',payload,payload['machine_refs'])
        payload['digest']=digest_record('GRFPS.ScaleCell','1.0.0',payload,payload['machine_refs'])
        self.cells[payload['cell_id']]=payload
        for p in payload['parent_refs']:
            self.children_of[p].append(payload['cell_id']); self.parents_of[payload['cell_id']].append(p)
        return deepcopy(payload)

    @staticmethod
    def _mean_positions(ps):
        if not ps:return [0.,0.,0.]
        return [sum(float(p[i]) for p in ps)/len(ps) for i in range(3)]

    def bind_cartographic_cycle(self,cycle,*,node_geometry,micro_signal=None,micro_scale='micro',meso_scale='meso',macro_scale='macro'):
        micro_signal=micro_signal or {}
        w_by_ref={w['digest']:w for w in cycle['graph_windows']}; r_by_ref={r['window_ref']:r for r in cycle['graph_resonites']}
        patch_to_meso={}; meso=[]
        for p in sorted(cycle['patches'],key=lambda x:x['patch_id']):
            m=list(p['members']); w=w_by_ref[p['window_ref']]; r=r_by_ref[p['window_ref']]
            pos=self._mean_positions([node_geometry[x] for x in m])
            feat={'member_count':len(m),'cycle_rank':int(r['properties']['cycle_rank']),'cut_edges':len(w['boundary']['cut_edges']),'density':float(cycle['density_by_patch'].get(p['patch_id'],0.0)),'mean_signal':sum(float(micro_signal.get(x,0.0)) for x in m)/max(1,len(m)),'members':m}
            c=self.add_cell(scale=meso_scale,local_id=p['patch_id'],machine_refs=[p['digest'],r['digest']],position=pos,features=feat,source_ref=p['digest'])
            patch_to_meso[p['patch_id']]=c['cell_id']; meso.append(c)
        micro=[]
        if micro_scale in self.scales:
            for p in sorted(cycle['patches'],key=lambda x:x['patch_id']):
                parent=patch_to_meso[p['patch_id']]
                for member in sorted(p['members']):
                    micro.append(self.add_cell(scale=micro_scale,local_id=f"{p['patch_id']}::{member}",machine_refs=[p['digest']],position=node_geometry[member],features={'node':member,'signal':float(micro_signal.get(member,0.0)),'meso_patch':p['patch_id']},parent_refs=[parent],source_ref=p['digest']))
        macro=[]
        if macro_scale in self.scales:
            reg=cycle['reflection_state']['region']; mids=[patch_to_meso[x] for x in reg['member_patches']]
            c=self.add_cell(scale=macro_scale,local_id=reg['region_id'],machine_refs=[reg['digest'],cycle['reflection_state']['digest']],position=self._mean_positions([self.cells[x]['position'] for x in mids]),features={'measure':reg['measure'],'density':reg['density'],'meso_count':len(mids)},source_ref=reg['digest'])
            macro.append(c); macro_ref=c['cell_id']
            for child in mids:
                self.parents_of[child].append(macro_ref); self.children_of[macro_ref].append(child)
                self.cells[child]['parent_refs']=sorted(set(self.cells[child].get('parent_refs',[])+[macro_ref]))
                self.cells[child]['digest']=digest_record('GRFPS.ScaleCell','1.0.0',{k:v for k,v in self.cells[child].items() if k!='digest'},self.cells[child]['machine_refs'])
        for k in list(self.children_of):self.children_of[k]=sorted(set(self.children_of[k]))
        for k in list(self.parents_of):self.parents_of[k]=sorted(set(self.parents_of[k]))
        rts=[self.roundtrip(p) for p in sorted(self.children_of) if self.children_of[p]]
        return {'state':self.snapshot(roundtrips=rts,atlas_ref=cycle['atlas_state']['digest']),'patch_to_meso':patch_to_meso,'micro_cells':micro,'meso_cells':[deepcopy(self.cells[x]) for x in sorted(patch_to_meso.values())],'macro_cells':macro}

    def lift(self,parent_ref):
        children=sorted(self.children_of.get(parent_ref,[])); payload={'source_ref':parent_ref,'source_scale':self.cells[parent_ref]['scale'],'target_scales':sorted({self.cells[x]['scale'] for x in children}),'children':children}
        payload['digest']=digest_record('GRFPS.ScaleLift','1.0.0',payload,(self.cells[parent_ref]['digest'],)); return payload
    def quotient(self,child_refs):
        refs=sorted(set(child_refs)); common=set(self.parents_of.get(refs[0],[])) if refs else set()
        for r in refs[1:]:common&=set(self.parents_of.get(r,[]))
        parents=sorted(common); payload={'child_refs':refs,'child_scales':sorted({self.cells[x]['scale'] for x in refs}),'parent_refs':parents,'status':'UNIQUE' if len(parents)==1 else 'AMBIGUOUS' if parents else 'OPEN'}
        payload['digest']=digest_record('GRFPS.ScaleQuotient','1.0.0',payload,[self.cells[x]['digest'] for x in refs]); return payload
    def roundtrip(self,parent_ref):
        l=self.lift(parent_ref); q=self.quotient(l['children']); ok=q['parent_refs']==[parent_ref]
        payload={'parent_ref':parent_ref,'lift_ref':l['digest'],'quotient_ref':q['digest'],'recovered_parent_refs':q['parent_refs'],'error':0.0 if ok else 1.0,'status':'PASS' if ok else 'FAIL'}
        payload['digest']=digest_record('GRFPS.CrossScaleWitness','1.0.0',payload,(self.cells[parent_ref]['digest'],)); return payload
    def scale_gain(self,current_scale,*,ambiguity,target_support=None):
        target_support=target_support or {}; c=[]
        for s in self.adjacent_finer(current_scale):c.append({'action':'LIFT','scale':s,'gain':float(target_support.get(s,0.0))+float(ambiguity)})
        for s in self.adjacent_coarser(current_scale):c.append({'action':'QUOTIENT','scale':s,'gain':float(target_support.get(s,0.0))+max(0.,0.25-float(ambiguity))})
        c.append({'action':'HOLD','scale':current_scale,'gain':float(target_support.get(current_scale,0.0))}); c.sort(key=lambda x:(-x['gain'],x['action'],x['scale']))
        payload={'current_scale':current_scale,'ambiguity':float(ambiguity),'candidates':c,'selected':c[0]}; payload['digest']=digest_record('GRFPS.ScaleGainReport','1.0.0',payload); return payload
    def snapshot(self,*,roundtrips=None,atlas_ref=None):
        states=[]
        for sid in sorted(self.scales,key=lambda x:(self.scales[x]['rank'],x)):
            parents=self.adjacent_coarser(sid); children=self.adjacent_finer(sid)
            states.append({'scale_id':sid,'rank':self.scales[sid]['rank'],'parent':parents[0] if len(parents)==1 else parents,'children':children,'lift_ops':[{'source':p,'target':sid} for p in parents],'quotient_ops':[{'source':sid,'target':p} for p in parents],'roundtrip_witnesses':[w['digest'] for w in (roundtrips or []) if self.cells.get(w['parent_ref'],{}).get('scale')==sid]})
        payload={'lattice':{'scales':sorted(self.scales.values(),key=lambda x:(x['rank'],x['id'])),'quotients':[{'source':a,'target':b} for a,b in self.quotients]},'scale_states':states,'cells':[deepcopy(self.cells[k]) for k in sorted(self.cells)],'roundtrip_witnesses':deepcopy(roundtrips or []),'atlas_ref':atlas_ref}
        payload['digest']=digest_record('GRFPS.ScaleStateBundle','1.0.0',payload,tuple(x['digest'] for x in payload['cells'])); return payload
