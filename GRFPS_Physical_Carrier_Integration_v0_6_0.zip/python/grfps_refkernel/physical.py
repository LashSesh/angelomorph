from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Any, Iterable

from .canon import digest_record


MEASUREMENT_CLASSES = {
    "runtime": "runtime-derived",
    "application": "application-derived",
    "external": "externally-measured",
}


@dataclass(frozen=True)
class PhysicalCarrierPolicy:
    max_registration_p95_m: float = 0.02
    min_traceability: float = 0.99
    min_tracking_fraction: float = 0.95
    max_application_frame_p95_ms: float = 20.0
    min_interaction_roundtrip: float = 0.99
    require_external_display_latency: bool = False


class PhysicalCarrierSession:
    """Canonical recorder for XR-derived physical carrier telemetry.

    The recorder is transport-agnostic. An OpenXR host, WebXR page, or another
    carrier adapter can emit the same canonical frame records.
    """

    def __init__(self, session_id: str, carrier_id: str, runtime: str, reference_space: str):
        self.session_id = session_id
        self.carrier_id = carrier_id
        self.runtime = runtime
        self.reference_space = reference_space
        self.frames: list[dict[str, Any]] = []
        self.events: list[dict[str, Any]] = []
        self.external_measurements: dict[str, Any] = {}

    @staticmethod
    def _finite(x: Any) -> bool:
        return isinstance(x, (int, float)) and x == x and x not in (float("inf"), float("-inf"))

    def append_frame(self, frame: dict[str, Any]) -> dict[str, Any]:
        required = (
            "frame_index",
            "monotonic_time_ns",
            "predicted_display_time_ns",
            "predicted_display_period_ns",
            "session_state",
            "should_render",
            "head_pose",
            "views",
        )
        missing = [k for k in required if k not in frame]
        if missing:
            raise ValueError(f"missing frame fields: {missing}")

        idx = int(frame["frame_index"])
        if self.frames and idx != int(self.frames[-1]["frame_index"]) + 1:
            raise ValueError("frame_index must be contiguous")
        if self.frames and int(frame["monotonic_time_ns"]) <= int(self.frames[-1]["monotonic_time_ns"]):
            raise ValueError("monotonic_time_ns must increase")
        if int(frame["predicted_display_period_ns"]) <= 0:
            raise ValueError("predicted_display_period_ns must be positive")

        pose = frame["head_pose"]
        for key in ("position_m", "orientation_xyzw"):
            if key not in pose:
                raise ValueError(f"head_pose missing {key}")
            if not all(self._finite(v) for v in pose[key]):
                raise ValueError(f"head_pose {key} contains non-finite value")

        normalized = {
            "session_id": self.session_id,
            "carrier_id": self.carrier_id,
            "runtime": self.runtime,
            "reference_space": self.reference_space,
            **frame,
        }
        parent = (self.frames[-1]["digest"],) if self.frames else ()
        normalized["digest"] = digest_record("GRFPS.PhysicalCarrierFrame", "1.0.0", normalized, parent)
        self.frames.append(normalized)
        return normalized

    def append_event(self, event: dict[str, Any]) -> dict[str, Any]:
        payload = {"session_id": self.session_id, **event}
        parents = tuple([self.frames[-1]["digest"]] if self.frames else [])
        payload["digest"] = digest_record("GRFPS.PhysicalCarrierEvent", "1.0.0", payload, parents)
        self.events.append(payload)
        return payload

    def bind_external_measurement(self, name: str, value: Any, *, unit: str, method: str, evidence_ref: str = "") -> None:
        record = {
            "name": name,
            "value": value,
            "unit": unit,
            "method": method,
            "evidence_ref": evidence_ref,
            "measurement_class": MEASUREMENT_CLASSES["external"],
        }
        record["digest"] = digest_record("GRFPS.ExternalMeasurement", "1.0.0", record)
        self.external_measurements[name] = record

    def seal(self) -> dict[str, Any]:
        if not self.frames:
            raise ValueError("session requires frames")
        bundle = {
            "session_id": self.session_id,
            "carrier_id": self.carrier_id,
            "runtime": self.runtime,
            "reference_space": self.reference_space,
            "frame_count": len(self.frames),
            "first_monotonic_time_ns": self.frames[0]["monotonic_time_ns"],
            "last_monotonic_time_ns": self.frames[-1]["monotonic_time_ns"],
            "frame_head_digest": self.frames[-1]["digest"],
            "event_digests": [e["digest"] for e in self.events],
            "external_measurements": self.external_measurements,
            "frames": self.frames,
            "events": self.events,
        }
        bundle["digest"] = digest_record(
            "GRFPS.PhysicalCarrierSession",
            "1.0.0",
            bundle,
            tuple(f["digest"] for f in self.frames),
        )
        return bundle


class PhysicalCarrierEvaluator:
    @staticmethod
    def percentile(values: list[float], q: float) -> float:
        if not values:
            raise ValueError("empty percentile input")
        xs = sorted(float(x) for x in values)
        if len(xs) == 1:
            return xs[0]
        pos = (len(xs) - 1) * q
        lo = int(pos)
        hi = min(lo + 1, len(xs) - 1)
        w = pos - lo
        return xs[lo] * (1.0 - w) + xs[hi] * w

    @classmethod
    def evaluate(cls, session: dict[str, Any], policy: PhysicalCarrierPolicy | None = None) -> dict[str, Any]:
        policy = policy or PhysicalCarrierPolicy()
        frames = session["frames"]
        reg = [float(f.get("registration_error_m", 0.0)) for f in frames if f.get("registration_error_m") is not None]
        app = [float(f.get("application_frame_ms", 0.0)) for f in frames if f.get("application_frame_ms") is not None]
        traced = [bool(f.get("provenance_ref")) for f in frames]
        tracked = [str(f.get("tracking_state", "TRACKED")) in {"TRACKED", "POSITION_VALID", "ORIENTATION_VALID"} for f in frames]
        interaction_events = [e for e in session.get("events", []) if e.get("kind") == "interaction"]
        interaction_ok = [bool(e.get("roundtrip_ok")) for e in interaction_events]

        metrics = {
            "frame_count": len(frames),
            "tracking_fraction": sum(tracked) / len(tracked),
            "view_traceability": sum(traced) / len(traced),
            "registration_error_m": {
                "mean": mean(reg) if reg else None,
                "p95": cls.percentile(reg, 0.95) if reg else None,
                "max": max(reg) if reg else None,
                "measurement_class": MEASUREMENT_CLASSES["application"],
            },
            "application_frame_ms": {
                "mean": mean(app) if app else None,
                "p95": cls.percentile(app, 0.95) if app else None,
                "max": max(app) if app else None,
                "measurement_class": MEASUREMENT_CLASSES["application"],
            },
            "interaction_roundtrip": (sum(interaction_ok) / len(interaction_ok)) if interaction_ok else None,
            "display_latency_ms": session.get("external_measurements", {}).get("DisplayLatency_ms"),
        }

        checks = {
            "tracking": metrics["tracking_fraction"] >= policy.min_tracking_fraction,
            "traceability": metrics["view_traceability"] >= policy.min_traceability,
            "registration": metrics["registration_error_m"]["p95"] is not None and metrics["registration_error_m"]["p95"] <= policy.max_registration_p95_m,
            "application_frame": metrics["application_frame_ms"]["p95"] is not None and metrics["application_frame_ms"]["p95"] <= policy.max_application_frame_p95_ms,
            "interaction": metrics["interaction_roundtrip"] is None or metrics["interaction_roundtrip"] >= policy.min_interaction_roundtrip,
            "display_latency": (metrics["display_latency_ms"] is not None) if policy.require_external_display_latency else True,
        }
        status = "MEASURED_PASS" if all(checks.values()) else "MEASURED_HOLD"
        result = {
            "witness_class": "PHYSICAL_CARRIER_MEASUREMENT",
            "session_ref": session["digest"],
            "policy": policy.__dict__,
            "metrics": metrics,
            "checks": checks,
            "status": status,
        }
        result["digest"] = digest_record("GRFPS.PhysicalCarrierWitness", "1.0.0", result, (session["digest"],))
        return result

    @staticmethod
    def capability_envelope(*, witness: dict[str, Any], simulated_reference: dict[str, Any]) -> dict[str, Any]:
        metrics = witness["metrics"]
        physical = {
            "measurement_status": witness["status"],
            "tracking_fraction": metrics["tracking_fraction"],
            "view_traceability": metrics["view_traceability"],
            "registration_error_m": metrics["registration_error_m"],
            "application_frame_ms": metrics["application_frame_ms"],
            "interaction_roundtrip": metrics["interaction_roundtrip"],
            "display_latency_ms": metrics["display_latency_ms"],
        }
        envelope = {
            "envelope_class": "PHYSICAL_CARRIER_CAPABILITY",
            "reference_capability_ref": simulated_reference["digest"],
            "physical_witness_ref": witness["digest"],
            "domains": simulated_reference.get("domains", []),
            "scales": simulated_reference.get("scales", []),
            "physical": physical,
            "reference": {
                "accuracy": simulated_reference.get("accuracy", {}),
                "coverage": simulated_reference.get("coverage", {}),
                "interaction": simulated_reference.get("interaction", {}),
            },
            "status": "DEVICE_MEASURED" if witness["status"] == "MEASURED_PASS" else "DEVICE_MEASURED_HOLD",
        }
        envelope["digest"] = digest_record(
            "GRFPS.PhysicalCapabilityEnvelope",
            "1.0.0",
            envelope,
            (simulated_reference["digest"], witness["digest"]),
        )
        return envelope


def load_jsonl(path: str | Path) -> list[dict[str, Any]]:
    out = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.strip():
            out.append(json.loads(line))
    return out


def save_json(path: str | Path, payload: Any) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return path
