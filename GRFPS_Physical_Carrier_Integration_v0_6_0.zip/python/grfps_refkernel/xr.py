from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

from .canon import digest_record


REQUIRED_OBJECTS = (
    "CenterMarker", "HorizonRing", "PatchSurface", "AttractorMarker",
    "TangentArrow", "DirectionFan", "ScalePortal", "TraceTrail",
)
REQUIRED_INTERACTIONS = ("TargetSelect", "Align", "Forward", "Hold", "Scale")


class XRPrototypeBuilder:
    """Carrier-bound XR presentation contract.

    This builder emits a standalone browser prototype and a conformance report.
    Physical-headset measurements are represented by a separate witness and are
    never inferred from the simulator.
    """

    @staticmethod
    def prototype_report(*, human_view: dict[str, Any], carrier_suite: dict[str, Any], interaction_roundtrip: dict[str, bool], render_objects: list[str] | None = None) -> dict[str, Any]:
        kinds = {o.get("kind") for o in human_view.get("objects", [])}
        # TraceTrail may be synthesized from the view's trace reference when the older renderer lacks it.
        materialized = set(kinds) | set(render_objects or [])
        if human_view.get("trace_ref") or human_view.get("provenance_map"):
            materialized.add("TraceTrail")
        object_checks = {k: k in materialized for k in REQUIRED_OBJECTS}
        interaction_checks = {k: bool(interaction_roundtrip.get(k)) for k in REQUIRED_INTERACTIONS}
        nominal = next(r for r in carrier_suite["summary"]["scenario_reports"] if r["scenario"] == "nominal")
        report = {
            "prototype_class": "XR_CARRIER_SOFTWARE_PROTOTYPE",
            "carrier_ref": carrier_suite["digest"],
            "human_view_ref": human_view["digest"],
            "objects": object_checks,
            "interactions": interaction_checks,
            "metrics": {
                "FrameRegistrationError_m": nominal["max_registration_error_m"],
                "DisplayLatency_ms": nominal["mean_display_latency_ms"],
                "ViewTraceability": nominal["traceability_rate"],
                "InteractionRoundtrip": sum(interaction_checks.values()) / len(interaction_checks),
            },
            "software_status": "SEALED" if all(object_checks.values()) and all(interaction_checks.values()) else "HOLD",
            "physical_headset_witness": "PENDING_EXTERNAL_HARDWARE",
        }
        report["digest"] = digest_record("GRFPS.XRPrototypeReport", "1.0.0", report, (carrier_suite["digest"], human_view["digest"]))
        return report

    @staticmethod
    def write_html(human_view: dict[str, Any], carrier_suite: dict[str, Any], report: dict[str, Any], path: str | Path) -> Path:
        import json
        path = Path(path)
        payload = json.dumps({"view": human_view, "carrier": carrier_suite["summary"], "report": report}, sort_keys=True)
        html = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>GRFPS XR Carrier Prototype</title>
<style>
html,body{margin:0;height:100%;background:#080b12;color:#e8edf7;font-family:ui-monospace,Consolas,monospace;overflow:hidden}
#c{width:100%;height:100%;display:block}.hud{position:fixed;left:16px;top:14px;padding:10px 12px;background:#0c1220cc;border:1px solid #65708a;border-radius:8px;max-width:420px}.hud b{display:block;margin-bottom:4px}.ok{color:#c9ffd9}.pending{color:#ffe9a8}.controls{position:fixed;right:16px;bottom:16px;background:#0c1220dd;padding:10px;border:1px solid #65708a;border-radius:8px}
button{margin:2px;background:#17213a;color:#eef4ff;border:1px solid #607099;border-radius:5px;padding:6px 8px}
</style></head><body><canvas id="c"></canvas><div class="hud"><b>GRFPS · XR Carrier Prototype</b><span class="ok" id="status"></span><br><span class="pending" id="xr"></span><div id="metric"></div></div><div class="controls" id="controls"></div>
<script>
const DATA=__PAYLOAD__;
const c=document.getElementById('c'),ctx=c.getContext('2d'); let t=0, action='Hold';
const acts=['TargetSelect','Align','Forward','Hold','Scale']; const ctr=document.getElementById('controls');
acts.forEach(a=>{const b=document.createElement('button');b.textContent=a;b.onclick=()=>action=a;ctr.appendChild(b)});
function resize(){c.width=innerWidth*devicePixelRatio;c.height=innerHeight*devicePixelRatio;ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0)} addEventListener('resize',resize);resize();
function draw(){t++; const w=innerWidth,h=innerHeight,cx=w/2,cy=h/2;
ctx.fillStyle='#080b12';ctx.fillRect(0,0,w,h);
// Horizon ring
ctx.strokeStyle='#65708a';ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(cx,cy,Math.min(w,h)*0.34,Math.min(w,h)*0.20,0,0,Math.PI*2);ctx.stroke();
// Patch surface
ctx.strokeStyle='#34415d';for(let i=-4;i<=4;i++){ctx.beginPath();ctx.moveTo(cx-260,cy+i*28);ctx.lineTo(cx+260,cy+i*28);ctx.stroke()}for(let i=-5;i<=5;i++){ctx.beginPath();ctx.moveTo(cx+i*48,cy-120);ctx.lineTo(cx+i*48,cy+120);ctx.stroke()}
// Center
ctx.fillStyle='#eef4ff';ctx.beginPath();ctx.arc(cx,cy,5,0,Math.PI*2);ctx.fill();
// Attractor
const ax=cx+180, ay=cy-55;ctx.strokeStyle='#eef4ff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(ax,ay,14,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.arc(ax,ay,4,0,Math.PI*2);ctx.fill();
// Tangent arrow
ctx.strokeStyle='#cbd8ff';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+115,cy-36);ctx.stroke();ctx.beginPath();ctx.moveTo(cx+115,cy-36);ctx.lineTo(cx+97,cy-39);ctx.lineTo(cx+104,cy-20);ctx.stroke();
// Direction fan
ctx.globalAlpha=.45;[-.3,0,.3].forEach(a=>{ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+90*Math.cos(a),cy+90*Math.sin(a));ctx.stroke()});ctx.globalAlpha=1;
// Scale portal
ctx.strokeStyle='#9faed1';ctx.beginPath();ctx.arc(cx-160,cy+78,26,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#9faed1';ctx.fillText('μ↕m↕M',cx-178,cy+83);
// Trace trail
ctx.strokeStyle='#4b5873';ctx.setLineDash([5,6]);ctx.beginPath();ctx.moveTo(cx-210,cy+95);ctx.quadraticCurveTo(cx-70,cy+60,cx,cy);ctx.stroke();ctx.setLineDash([]);
ctx.fillStyle='#d8e2f6';ctx.fillText('Action: '+action,18,h-20);
requestAnimationFrame(draw)}
const m=DATA.report.metrics;document.getElementById('status').textContent='software witness: '+DATA.report.software_status;document.getElementById('metric').textContent=`registration ${m.FrameRegistrationError_m.toFixed(4)} m · display ${m.DisplayLatency_ms.toFixed(1)} ms · trace ${m.ViewTraceability.toFixed(2)}`;
if(navigator.xr){navigator.xr.isSessionSupported('immersive-vr').then(v=>document.getElementById('xr').textContent=v?'WebXR immersive-vr reported by browser':'WebXR present; immersive-vr unavailable').catch(()=>document.getElementById('xr').textContent='WebXR query failed')}else document.getElementById('xr').textContent='physical XR runtime not detected in this browser';
draw();
</script></body></html>'''.replace('__PAYLOAD__', payload)
        path.write_text(html, encoding='utf-8')
        return path


def build_capability_envelope(*, blind_report: dict[str, Any], carrier_suite: dict[str, Any], xr_report: dict[str, Any], scales: list[str]) -> dict[str, Any]:
    reports = carrier_suite["summary"]["scenario_reports"]
    nominal = next(r for r in reports if r["scenario"] == "nominal")
    robustness = {
        r["scenario"]: {
            "tracking_fraction": r["tracking_fraction"],
            "max_registration_error_m": r["max_registration_error_m"],
            "max_display_latency_ms": r["max_display_latency_ms"],
            "replay_class": r["replay_class"],
        }
        for r in reports
    }
    envelope = {
        "envelope_class": "SIMULATED_REFERENCE_CAPABILITY",
        "domains": [blind_report.get("world_id", "synthetic")],
        "scales": list(scales),
        "latency": {
            "display_mean_ms": nominal["mean_display_latency_ms"],
            "display_max_ms": nominal["max_display_latency_ms"],
            "input_mean_ms": nominal["mean_input_latency_ms"],
        },
        "accuracy": {
            "target": blind_report["metrics"]["target_accuracy"],
            "arrival": blind_report["metrics"]["arrival_accuracy"],
            "boundary_iou": blind_report["metrics"]["boundary_iou"],
        },
        "coverage": {"view_traceability": xr_report["metrics"]["ViewTraceability"]},
        "robustness": robustness,
        "interaction": {"roundtrip": xr_report["metrics"]["InteractionRoundtrip"], "actions": list(REQUIRED_INTERACTIONS)},
        "resourceEnvelope": {
            "reference_frame_rate_hz": 90.0,
            "reference_frame_count": next(iter(carrier_suite["scenarios"].values()))["report"]["frame_count"],
            "carrier_scenarios": len(reports),
        },
        "software_reference_status": "SEALED",
        "physical_capability_status": "PENDING_EXTERNAL_HARDWARE_MEASUREMENT",
    }
    envelope["digest"] = digest_record("GRFPS.CapabilityEnvelope", "1.0.0", envelope, (blind_report["digest"], carrier_suite["digest"], xr_report["digest"]))
    return envelope
