from __future__ import annotations
from collections import deque
from copy import deepcopy
from .canon import digest_record
from .gyrosphere import normalize

def adjacency(atlas,patch_to_cell):
    a={cid:set() for cid in patch_to_cell.values()}
    for tr in atlas.get('transitions',[]):
        x=patch_to_cell.get(tr['source']);y=patch_to_cell.get(tr['target'])
        if x and y:a[x].add(y);a[y].add(x)
    return a
def distances(adj,target):
    d={target:0};q=deque([target])
    while q:
        u=q.popleft()
        for v in sorted(adj.get(u,[])):
            if v not in d:d[v]=d[u]+1;q.append(v)
    return d

class NavigationRatchet:
    def match(self,f,p):
        x=f.get(p['feature']);op=p.get('op','eq');v=p.get('value')
        if op=='eq':return x==v
        if op=='gte':return x is not None and float(x)>=float(v)
        if op=='lte':return x is not None and float(x)<=float(v)
        if op=='contains':return v in (x or [])
        raise ValueError(op)
    def contract(self,cells,predicates):
        by={c['cell_id']:c for c in cells};rem=sorted(by);st=[]
        for i,p in enumerate(predicates):
            before=list(rem);rem=[cid for cid in rem if self.match(by[cid]['features'],p)];s={'index':i,'predicate':deepcopy(p),'before':before,'after':list(rem),'contracted':len(rem)<len(before),'status':'ADVANCE' if rem else 'RESIDUAL'};s['digest']=digest_record('GRFPS.RatchetStage','1.0.0',s);st.append(s)
            if not rem:break
        out={'initial_set':sorted(by),'remaining_set':rem,'classified':sorted(set(by)-set(rem)),'stages':st,'termination':'UNIQUE' if len(rem)==1 else 'EMPTY' if not rem else 'MULTI'};out['digest']=digest_record('GRFPS.NavigationRatchet','1.0.0',out);return out

class AttractorRuntime:
    def __init__(self):self.epoch=-1;self.binding=None;self.ratchet=NavigationRatchet()
    def bind(self,spec,*,cells):
        self.epoch+=1;sp=deepcopy(spec);sp['digest']=digest_record('GRFPS.AttractorSpec','1.0.0',spec);rat=self.ratchet.contract(cells,spec.get('predicates',[]));cands=rat['remaining_set'];by={c['cell_id']:c for c in cells};target=sorted(cands,key=lambda cid:(-sum(float(w)*float(by[cid]['features'].get(k,0)) for k,w in spec.get('quality_weights',{'mean_signal':1.0}).items()),cid))[0] if cands else None
        b={'spec_ref':sp['digest'],'epoch':self.epoch,'status':'BOUND' if len(cands)==1 else 'BOUND_CLASS' if cands else 'UNRESOLVED','candidate_refs':sorted(cands),'target_ref':target,'ratchet_ref':rat['digest'],'selected_at':0,'validated_at':0 if target else None,'stale_reason':None};b['digest']=digest_record('GRFPS.AttractorBinding','1.0.0',b,(sp['digest'],rat['digest']));self.binding=b;return {'spec':sp,'binding':deepcopy(b),'ratchet':rat}
    def potential(self,*,cells,atlas,patch_to_cell,resolution_scale='meso',micro_weight=.35):
        target=self.binding['target_ref'];adj=adjacency(atlas,patch_to_cell);dist=distances(adj,target);by={c['cell_id']:c for c in cells};p={}
        for cid in sorted(by):
            base=float(dist.get(cid,10**6))
            if resolution_scale=='micro' and cid!=target:base+=micro_weight*(1-float(by[cid]['features'].get('mean_signal',0)))
            p[cid]=float(format(base,'.17g'))
        out={'attractor_epoch':self.binding['epoch'],'target_ref':target,'resolution_scale':resolution_scale,'potentials':p,'micro_weight':micro_weight if resolution_scale=='micro' else 0.};out['digest']=digest_record('GRFPS.AttractorPotential','1.0.0',out,(self.binding['digest'],));return out
    def arrived(self,current_ref,*,potential,tolerance=0.):
        val=float(potential['potentials'].get(current_ref,float('inf')));ok=current_ref==self.binding['target_ref'] and val<=tolerance+1e-12;out={'epoch':self.binding['epoch'],'current_ref':current_ref,'target_ref':self.binding['target_ref'],'potential':val,'tolerance':float(tolerance),'arrived':ok,'status':'ARRIVED' if ok else 'EN_ROUTE'};out['digest']=digest_record('GRFPS.AttractorArrival','1.0.0',out,(self.binding['digest'],potential['digest']));return out

class AxisEngine:
    def discover(self,*,current_ref,cells,atlas,patch_to_cell,potential,attractor_epoch,lock_margin=.03):
        by={c['cell_id']:c for c in cells};adj=adjacency(atlas,patch_to_cell);cv=potential['potentials'][current_ref];c=[]
        for n in sorted(adj[current_ref]):
            pv=potential['potentials'][n];gain=cv-pv;d=normalize([by[n]['position'][i]-by[current_ref]['position'][i] for i in range(3)]);c.append({'next_ref':n,'potential':pv,'gain':float(format(gain,'.17g')),'direction':d,'witnesses':[by[current_ref]['digest'],by[n]['digest'],potential['digest']]})
        c.sort(key=lambda x:(-x['gain'],x['potential'],x['next_ref']));pos=[x for x in c if x['gain']>0]
        if not pos:status='STATIONARY';sel=None;fan=[];margin=0.
        else:
            margin=float(format(pos[0]['gain']-(pos[1]['gain'] if len(pos)>1 else 0),'.17g'));tied=[x for x in pos if abs(x['gain']-pos[0]['gain'])<=lock_margin]
            if len(tied)>1 or margin<lock_margin:status='AMBIGUOUS';sel=None;fan=tied
            else:status='LOCKED';sel=pos[0];fan=[]
        out={'current_ref':current_ref,'attractor_epoch':int(attractor_epoch),'resolution_scale':potential['resolution_scale'],'candidates':c,'selected':sel,'fan':fan,'margin':margin,'status':status};out['digest']=digest_record('GRFPS.AxisDiscovery','1.0.0',out,(potential['digest'],));return out
    def lock(self,d,persistence=1):
        s=d.get('selected')
        if d['status']=='LOCKED' and s:
            out={'axis_class':f"{d['current_ref']}->{s['next_ref']}",'margin':d['margin'],'witnesses':[d['digest'],*s['witnesses']],'persistence':persistence,'attractor_epoch':d['attractor_epoch'],'transport_ref':None,'confidence':min(1.,.5+d['margin']),'status':'LOCKED','direction':s['direction'],'next_ref':s['next_ref']}
        else:out={'axis_class':None,'margin':d['margin'],'witnesses':[d['digest']],'persistence':0,'attractor_epoch':d['attractor_epoch'],'transport_ref':None,'confidence':0.,'status':'OPEN','direction':None,'next_ref':None}
        out['digest']=digest_record('GRFPS.AxisLock','1.0.0',out,(d['digest'],));return out
    def transport(self,lock,*,new_current_ref):
        out={'axis_ref':lock['digest'],'source_ref':lock['axis_class'].split('->')[0] if lock.get('axis_class') else None,'target_ref':new_current_ref,'predicted_direction':lock.get('direction'),'correction':[0.,0.,0.],'residual':0. if lock.get('next_ref')==new_current_ref else 1.,'status':'CONSISTENT' if lock.get('next_ref')==new_current_ref else 'REACQUIRE'};out['digest']=digest_record('GRFPS.AxisTransport','1.0.0',out,(lock['digest'],));return out

class TangentCompass:
    def build(self,*,discovery,axis_lock,scale_lattice,observation_scale,target_support=None,arrived=False):
        ambiguity=1. if discovery['status']=='AMBIGUOUS' else max(0.,1-float(axis_lock['confidence']));sr=scale_lattice.scale_gain(observation_scale,ambiguity=ambiguity,target_support=target_support or {})
        if arrived:
            c=scale_lattice.adjacent_coarser(observation_scale);sa={'action':'QUOTIENT','scale':c[0],'gain':1.} if c else {'action':'HOLD','scale':observation_scale,'gain':0.}
        elif discovery['status']=='AMBIGUOUS':
            f=scale_lattice.adjacent_finer(observation_scale);sa={'action':'LIFT','scale':f[0],'gain':1.} if f else sr['selected']
        else:sa={'action':'HOLD','scale':observation_scale,'gain':sr['selected']['gain']}
        if discovery['status']=='LOCKED':dof={'kind':'VECTOR','direction':axis_lock['direction'],'next_ref':axis_lock['next_ref']};alts=[];prog=max(0.,discovery['selected']['gain'])
        elif discovery['status']=='AMBIGUOUS':dof={'kind':'FAN','items':[{'direction':x['direction'],'next_ref':x['next_ref'],'gain':x['gain']} for x in discovery['fan']]};alts=[x['next_ref'] for x in discovery['fan']];prog=max(x['gain'] for x in discovery['fan'])
        else:dof={'kind':'HOLD','direction':None};alts=[];prog=0.
        out={'target_epoch':discovery['attractor_epoch'],'axis_ref':axis_lock['digest'],'direction_or_fan':dof,'scale_action':sa,'alternatives':alts,'expected_progress':float(format(prog,'.17g')),'uncertainty':float(format(ambiguity,'.17g')),'stop_reason':'ARRIVED' if arrived else None,'validity':'SEALED','scale_report_ref':sr['digest']};out['digest']=digest_record('GRFPS.NavigationProposal','1.0.0',out,(axis_lock['digest'],sr['digest']));return {'proposal':out,'scale_report':sr}

class NavigationRuntime:
    def __init__(self,*,scale_lattice,attractor=None):self.scales=scale_lattice;self.attractor=attractor or AttractorRuntime();self.axis=AxisEngine();self.compass=TangentCompass()
    def step(self,*,current_ref,observation_scale,meso_cells,atlas,patch_to_cell,target_support=None,previous_lock=None):
        pot=self.attractor.potential(cells=meso_cells,atlas=atlas,patch_to_cell=patch_to_cell,resolution_scale=observation_scale);arr=self.attractor.arrived(current_ref,potential=pot);d=self.axis.discover(current_ref=current_ref,cells=meso_cells,atlas=atlas,patch_to_cell=patch_to_cell,potential=pot,attractor_epoch=self.attractor.binding['epoch']);lock=self.axis.lock(d,persistence=(int(previous_lock.get('persistence',0))+1 if previous_lock and previous_lock.get('status')=='LOCKED' else 1));c=self.compass.build(discovery=d,axis_lock=lock,scale_lattice=self.scales,observation_scale=observation_scale,target_support=target_support,arrived=arr['arrived']);return {'potential':pot,'arrival':arr,'axis_discovery':d,'axis_lock':lock,'navigation_proposal':c['proposal'],'scale_gain':c['scale_report']}
