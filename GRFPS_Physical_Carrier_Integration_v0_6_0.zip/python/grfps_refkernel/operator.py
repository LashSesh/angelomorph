from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .canon import digest_record
from .types import OperatorSpec


@dataclass(frozen=True)
class RegistryEntry:
    spec: OperatorSpec
    digest: str

    def to_dict(self) -> dict:
        return {"digest": self.digest, **self.spec.payload()}


class OperatorRegistry:
    def __init__(self, specs: Iterable[OperatorSpec] = ()):
        self._by_digest: dict[str, RegistryEntry] = {}
        self._by_name: dict[tuple[str, str], RegistryEntry] = {}
        for spec in specs:
            self.register(spec)

    @staticmethod
    def digest_spec(spec: OperatorSpec) -> str:
        return digest_record("GRFPS.OperatorSpec", spec.version, spec.payload())

    def register(self, spec: OperatorSpec) -> RegistryEntry:
        digest = self.digest_spec(spec)
        entry = RegistryEntry(spec=spec, digest=digest)
        key = (spec.operator_id, spec.version)
        existing = self._by_name.get(key)
        if existing and existing.digest != digest:
            raise ValueError(f"operator identity collision for {key}")
        self._by_digest[digest] = entry
        self._by_name[key] = entry
        return entry

    def resolve_digest(self, digest: str) -> RegistryEntry:
        try:
            return self._by_digest[digest]
        except KeyError as exc:
            raise KeyError(f"unresolved operator digest: {digest}") from exc

    def resolve_name(self, operator_id: str, version: str) -> RegistryEntry:
        return self._by_name[(operator_id, version)]

    def snapshot(self) -> dict:
        entries = [entry.to_dict() for _, entry in sorted(self._by_digest.items())]
        digest = digest_record("GRFPS.OperatorRegistry", "1.0.0", entries)
        return {"entries": entries, "digest": digest}

    @classmethod
    def core_registry(cls) -> "OperatorRegistry":
        from .types import DeterminismClass

        rows = [
            ("constitution.bindRun", "Constitution", "RunInput", "RunDescriptor", "constitution"),
            ("constitution.bindCenter", "Constitution", "CenterInput", "CenterBinding", "constitution"),
            ("constitution.bindWorld", "Constitution", "WorldInput", "WorldBinding", "constitution"),
            ("constitution.canon", "Constitution", "AnyCanonicalizable", "CanonicalRecord", "constitution"),
            ("constitution.digest", "Constitution", "CanonicalRecord", "Digest", "constitution"),
            ("constitution.seal", "Constitution", "KernelState", "SealedRun", "constitution"),
            ("genome.parseGenome", "Genome", "GenomePackage", "GenomeAst", "genome"),
            ("genome.resolveGenes", "Genome", "GenomeAst", "ResolvedGenome", "genome"),
            ("genome.typeGenome", "Genome", "ResolvedGenome", "TypedGenome", "genome"),
            ("genome.canonicalizeGenome", "Genome", "TypedGenome", "CanonicalGenome", "genome"),
            ("genome.linkGenome", "Genome", "CanonicalGenome", "LinkedGenome", "genome"),
            ("genome.planGenome", "Genome", "LinkedGenome", "CompilePlan", "genome"),
            ("genome.sealGenome", "Genome", "CompilePlan", "CompileManifest", "genome"),
            ("ledger.appendTrace", "Ledger", "Transition", "TraceSegment", "ledger"),
            ("ledger.checkpoint", "Ledger", "RuntimeState", "Checkpoint", "ledger"),
            ("ledger.replay", "Ledger", "ReplayManifest", "ReplayResult", "ledger"),
        ]
        specs = [
            OperatorSpec(
                operator_id=op,
                version="1.0.0",
                family=family,
                domain=domain,
                codomain=codomain,
                determinism=DeterminismClass.DETERMINISTIC,
                capability_namespace=cap,
                witness_products=("TraceWitness",),
                residue_classes=("TypedResidual",),
                trace_fields=("input_digest", "pre_digest", "post_digest"),
            )
            for op, family, domain, codomain, cap in rows
        ]
        return cls(specs)
    @classmethod
    def r00_r11_registry(cls) -> "OperatorRegistry":
        from .types import DeterminismClass

        base = [entry.spec for entry in cls.core_registry()._by_digest.values()]
        rows = [
            ("ophan.compileOphan", "Ophan", "OphanGene", "OphanSpec", "ophan"),
            ("ophan.spawnOphan", "Ophan", "OphanSpec", "OphanState", "ophan"),
            ("ophan.calibrateOphan", "Ophan", "OphanState", "OphanState", "ophan"),
            ("ophan.activateOphan", "Ophan", "OphanState", "OphanState", "ophan"),
            ("ophan.expose", "Ophan", "OphanState", "ExposureState", "ophan"),
            ("ophan.retireOphan", "Ophan", "OphanState", "OphanState", "ophan"),
            ("coherence.buildOperatorGraph", "Coherence", "OphanBank", "CoherenceGraph", "coherence"),
            ("coherence.updateCoherence", "Coherence", "CoherenceGraph", "CoherenceGraph", "coherence"),
            ("coherence.quotientDependencies", "Coherence", "ResponseSet", "DependencyProfile", "coherence"),
            ("coherence.scoreCandidate", "Coherence", "ScheduleCandidate", "ScoredCandidate", "scheduler"),
            ("coherence.allocateBudget", "Coherence", "ScoredCandidateSet", "SchedulerDecision", "scheduler"),
            ("coherence.reconfigureGraph", "Coherence", "SchedulerDecision", "OphanBank", "scheduler"),
        ]
        extra = [
            OperatorSpec(
                operator_id=op,
                version="1.0.0",
                family=family,
                domain=domain,
                codomain=codomain,
                determinism=DeterminismClass.DETERMINISTIC,
                capability_namespace=cap,
                witness_products=("OphanWitness", "TraceWitness") if family == "Ophan" else ("CoherenceWitness", "TraceWitness"),
                residue_classes=("TypedResidual",),
                trace_fields=("input_digest", "pre_digest", "post_digest"),
                budget_class="perceptual-runtime",
            )
            for op, family, domain, codomain, cap in rows
        ]
        return cls([*base, *extra])


    @classmethod
    def r00_r19_registry(cls) -> "OperatorRegistry":
        from .types import DeterminismClass

        base = [entry.spec for entry in cls.r00_r11_registry()._by_digest.values()]
        rows = [
            ("infogenetic.decomposeWindow", "InfogeneticMap", "EvidenceGraph", "GraphWindowSet", "infogenetic"),
            ("infogenetic.canonGraph", "InfogeneticMap", "GraphWindow", "CanonicalGraph", "infogenetic"),
            ("infogenetic.fingerprintGraph", "InfogeneticMap", "CanonicalGraph", "GraphFingerprint", "infogenetic"),
            ("infogenetic.emitGraphResonite", "InfogeneticMap", "GraphWindow", "GraphResonite", "infogenetic"),
            ("infogenetic.updateGraphInfogenome", "InfogeneticMap", "GraphResoniteSet", "GraphInfogenome", "infogenetic"),
            ("infogenetic.compareOverlap", "InfogeneticMap", "PatchPair", "OverlapReport", "infogenetic"),
            ("infogenetic.witnessSeam", "InfogeneticMap", "OverlapReport", "SeamWitness", "infogenetic"),
            ("infogenetic.gluePatches", "InfogeneticMap", "PatchSet", "GluingCertificate", "infogenetic"),
            ("infogenetic.buildNerve", "InfogeneticMap", "GluingCertificate", "NerveState", "infogenetic"),
            ("mirror.updateMirror", "Mirror", "EvidenceConstraints", "MirrorState", "mirror"),
            ("mirror.contractEvidence", "Mirror", "MirrorState", "MirrorState", "mirror"),
            ("mirror.computeMarginalGain", "Mirror", "MirrorState", "MarginalGain", "mirror"),
            ("reflection.buildReflection", "Reflection", "InfogeneticMap", "ReflectionState", "reflection"),
            ("reflection.projectPlus", "Reflection", "ReflectionState", "PlusProjection", "reflection"),
            ("reflection.projectMinus", "Reflection", "ReflectionState", "MinusProjection", "reflection"),
            ("reflection.optimizeRegion", "Reflection", "PatchComplex", "BoundaryRegion", "reflection"),
            ("reflection.renewBoundary", "Reflection", "BoundaryRegion", "BoundaryRegion", "reflection"),
            ("reflection.certifyClosure", "Reflection", "BoundaryRegion", "BoundaryCertificate", "reflection"),
            ("navigation.buildHorizon", "Navigation", "ReflectionState", "HorizonState", "navigation"),
        ]
        extra = [
            OperatorSpec(
                operator_id=op,
                version="1.0.0",
                family=family,
                domain=domain,
                codomain=codomain,
                determinism=DeterminismClass.DETERMINISTIC,
                capability_namespace=cap,
                witness_products=(
                    "GraphWitness", "TraceWitness"
                ) if family == "InfogeneticMap" else (
                    "MirrorWitness", "TraceWitness"
                ) if family == "Mirror" else (
                    "BoundaryWitness", "TraceWitness"
                ) if family == "Reflection" else (
                    "HorizonWitness", "TraceWitness"
                ),
                residue_classes=("TypedResidual",),
                trace_fields=("input_digest", "pre_digest", "post_digest"),
                budget_class="perceptual-cartography",
            )
            for op, family, domain, codomain, cap in rows
        ]
        return cls([*base, *extra])


    @classmethod
    def r00_r27_registry(cls) -> "OperatorRegistry":
        from .types import DeterminismClass
        base = [entry.spec for entry in cls.r00_r19_registry()._by_digest.values()]
        rows = [
            ("scale.bindScale","Scale","AtlasState","ScaleState","scale"),("scale.liftScale","Scale","ScaleState","ScaleLift","scale"),("scale.quotientScale","Scale","ScaleState","ScaleQuotient","scale"),("scale.compareScaleRoundtrip","Scale","ScaleRoundtrip","CrossScaleWitness","scale"),("scale.migrateScale","Scale","ScalePose","ScalePose","scale"),("scale.estimateScaleGain","Scale","ScaleState","ScaleGainReport","scale"),
            ("gyrosphere.orient","Gyrosphere","ReflectionRegion","GyroState","gyrosphere"),("gyrosphere.relax","Gyrosphere","GyroState","GyroState","gyrosphere"),("gyrosphere.splitCell","Gyrosphere","GyroCell","GyroCellSet","gyrosphere"),("gyrosphere.mergeCell","Gyrosphere","GyroCellSet","GyroCell","gyrosphere"),("gyrosphere.measureCoverage","Gyrosphere","GyroState","CoverageReport","gyrosphere"),("gyrosphere.closeLift","Gyrosphere","GyroState","GyroClosure","gyrosphere"),("gyrosphere.measureHolonomy","Gyrosphere","GyroState","HolonomyWitness","gyrosphere"),
            ("navigation.bindAttractor","Navigation","AttractorSpec","AttractorBinding","navigation"),("navigation.switchAttractor","Navigation","AttractorBinding","AttractorBinding","navigation"),("navigation.compilePotential","Navigation","AttractorBinding","AttractorPotential","navigation"),("navigation.discoverAxis","Navigation","AttractorPotential","AxisDiscovery","navigation"),("navigation.lockAxis","Navigation","AxisDiscovery","AxisLock","navigation"),("navigation.trackAxis","Navigation","AxisLock","AxisTransport","navigation"),("navigation.reacquireAxis","Navigation","AxisDiscovery","AxisReacquisition","navigation"),("navigation.buildCompass","Navigation","AxisLock","NavigationProposal","navigation"),("navigation.advance","Navigation","NavigationProposal","AxisTransport","navigation"),("navigation.ratchet","Navigation","AttractorSpec","NavigationRatchet","navigation"),
            ("view.buildViewObject","View","MachineRecord","ViewObject","view"),("view.renderDensity","View","ReflectionRegion","PerceptualDensityField","view"),("view.renderHorizon","View","HorizonState","ViewObjectSet","view"),("view.renderCompass","View","NavigationProposal","ViewObject","view"),("view.renderScale","View","ScaleState","ViewObject","view"),("view.registerFrames","View","WorldBinding","FrameRegistration","view"),("view.composeView","View","ViewObjectSet","HumanView","view"),
        ]
        witness={"Scale":("ScaleWitness","TraceWitness"),"Gyrosphere":("GyroWitness","TraceWitness"),"Navigation":("NavigationWitness","TraceWitness"),"View":("ViewWitness","TraceWitness")}
        extra=[OperatorSpec(operator_id=op,version="1.0.0",family=fam,domain=dom,codomain=cod,determinism=DeterminismClass.DETERMINISTIC,capability_namespace=cap,witness_products=witness[fam],residue_classes=("TypedResidual",),trace_fields=("input_digest","pre_digest","post_digest"),budget_class="perceptual-navigation") for op,fam,dom,cod,cap in rows]
        return cls([*base,*extra])

    @classmethod
    def r00_r31_registry(cls) -> "OperatorRegistry":
        from .types import DeterminismClass
        base = [entry.spec for entry in cls.r00_r27_registry()._by_digest.values()]
        rows = [
            ("sedimentation.collectRuns","Sedimentation","SealedRunSet","EvaluationSet","lineage"),
            ("sedimentation.proposeGenes","Sedimentation","EvaluationSet","CandidateGeneSet","lineage"),
            ("sedimentation.compileShadow","Sedimentation","CandidateGeneSet","GenomeShadow","lineage"),
            ("sedimentation.evaluateShadow","Sedimentation","GenomeShadow","EvaluationBundle","lineage"),
            ("sedimentation.sedimentGenome","Sedimentation","EvaluationBundle","SedimentationRecord","lineage"),
            ("carrier.bindInterface","Carrier","CarrierConfig","CarrierBinding","carrier"),
            ("carrier.ingestFrame","Carrier","CarrierFrame","CarrierState","carrier"),
            ("carrier.registerFrames","Carrier","CarrierFrame","FrameRegistration","carrier"),
            ("carrier.classifyStale","Carrier","CarrierState","CarrierState","carrier"),
            ("carrier.reportSuite","Carrier","CarrierStateSet","CarrierSuite","carrier"),
            ("xr.composeCarrierView","XR","HumanView","XRView","xr"),
            ("xr.handleInteraction","XR","XRInput","XRInteractionReceipt","xr"),
            ("xr.measurePrototype","XR","XRView","XRPrototypeReport","xr"),
            ("capability.sealEnvelope","Capability","CapabilityMeasurements","CapabilityEnvelope","capability"),
        ]
        witness = {
            "Sedimentation": ("SedimentationWitness", "TraceWitness"),
            "Carrier": ("CarrierWitness", "FrameWitness", "TraceWitness"),
            "XR": ("XRViewWitness", "InteractionWitness", "TraceWitness"),
            "Capability": ("CapabilityWitness", "TraceWitness"),
        }
        extra = [
            OperatorSpec(
                operator_id=op, version="1.0.0", family=fam, domain=dom, codomain=cod,
                determinism=DeterminismClass.DETERMINISTIC, capability_namespace=cap,
                witness_products=witness[fam], residue_classes=("TypedResidual",),
                trace_fields=("input_digest","pre_digest","post_digest"), budget_class="perceptual-release",
            ) for op,fam,dom,cod,cap in rows
        ]
        return cls([*base, *extra])
