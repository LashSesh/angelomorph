from __future__ import annotations
from copy import deepcopy
from html import escape
from pathlib import Path
from .canon import digest_record

class DensityRenderer:
    def build(self,*,scale_cells,scale='meso'):
        samples=[]
        for c in sorted([x for x in scale_cells if x.get('scale')==scale],key=lambda x:x['cell_id']):
            density=float(c.get('features',{}).get('density',0.0));unc=max(0.,1-density);eff=max(0.,min(1.,density*(1-unc)))
            lod=0 if eff<.25 else 1 if eff<.5 else 2 if eff<.75 else 3;geom=('MARKER','EDGE','SURFACE','REGION')[lod]
            samples.append({'cell_ref':c['cell_id'],'position':deepcopy(c['position']),'density':density,'uncertainty':unc,'effective_density':eff,'lod':lod,'geometry_class':geom,'machine_refs':deepcopy(c.get('machine_refs',[]))})
        out={'chart':'rolling-atlas/current','scale':scale,'density_samples':samples,'estimator':'glue-degree-x-confidence/v1','uncertainty':max([s['uncertainty'] for s in samples],default=1.)};out['digest']=digest_record('GRFPS.PerceptualDensityField','1.0.0',out,tuple(x for s in samples for x in s['machine_refs']));return out

class ViewCompositor:
    def register_frames(self,clock=0):
        I=[[1.,0.,0.,0.],[0.,1.,0.,0.],[0.,0.,1.,0.],[0.,0.,0.,1.]];out={'world_frame':'world://synthetic/root','machine_frame':'machine://grfps/root','human_frame':'human://desktop/reference','transforms':[{'source':'world://synthetic/root','target':'machine://grfps/root','matrix':I,'clock':clock,'uncertainty':0.},{'source':'machine://grfps/root','target':'human://desktop/reference','matrix':I,'clock':clock,'uncertainty':0.}]};out['digest']=digest_record('GRFPS.FrameRegistration','1.0.0',out);return out
    @staticmethod
    def obj(kind,machine_ref,geometry,style,provenance,scale='meso',uncertainty=0.,interaction=None):
        p={'kind':kind,'machine_ref':machine_ref,'geometry':deepcopy(geometry),'style':deepcopy(style),'facticity':'Simulated','uncertainty':float(uncertainty),'scale':scale,'interaction':interaction,'provenance':sorted(set(provenance))};p['id']=digest_record('GRFPS.ViewObjectId','1.0.0',p,tuple(p['provenance']));p['digest']=digest_record('GRFPS.ViewObject','1.0.0',p,(machine_ref,));return p
    def compose(self,*,cartographic_cycle,scale_bundle,density_field,gyro_state,attractor_bundle,navigation_proposal,current_ref,observation_scale,clock=0):
        fr=self.register_frames(clock);cells={c['cell_id']:c for c in scale_bundle['cells']};meso=[c for c in cells.values() if c['scale']=='meso'];den={x['cell_ref']:x for x in density_field['density_samples']};objs=[]
        for c in sorted(meso,key=lambda x:x['cell_id']):
            d=den[c['cell_id']];objs.append(self.obj('PatchSurface',c['digest'],{'type':'point','position':c['position'],'lod':d['lod'],'geometry_class':d['geometry_class']},{'stroke':'#666','weight':1+d['lod']},[*c['machine_refs'],density_field['digest']],uncertainty=d['uncertainty']))
        p2c={c['local_id']:c['cell_id'] for c in meso}
        for tr in cartographic_cycle['atlas_state']['transitions']:
            a,b=p2c.get(tr['source']),p2c.get(tr['target'])
            if a in cells and b in cells:objs.append(self.obj('SeamLine',tr['seam_ref'],{'type':'line','from':cells[a]['position'],'to':cells[b]['position']},{'stroke':'#999','weight':1},[tr['seam_ref'],cartographic_cycle['atlas_state']['digest']]))
        objs.append(self.obj('HorizonRing',cartographic_cycle['horizon_state']['digest'],{'type':'ring','status':'CURRENT'},{'stroke':'#222','dash':'8 5','weight':2},[cartographic_cycle['reflection_state']['digest'],cartographic_cycle['horizon_state']['digest']],scale=observation_scale))
        target=attractor_bundle['binding']['target_ref']
        if target in cells:objs.append(self.obj('AttractorMarker',attractor_bundle['binding']['digest'],{'type':'target','position':cells[target]['position'],'target_ref':target},{'stroke':'#111','weight':4},[attractor_bundle['spec']['digest'],attractor_bundle['binding']['digest']],interaction='SelectAttractor'))
        cur=cells[current_ref];objs.append(self.obj('CenterMarker',cur['digest'],{'type':'center','position':cur['position']},{'stroke':'#000','weight':3},[cur['digest']]))
        dof=navigation_proposal['direction_or_fan']
        if dof['kind']=='VECTOR':objs.append(self.obj('TangentArrow',navigation_proposal['digest'],{'type':'vector','origin':cur['position'],'direction':dof['direction'],'next_ref':dof['next_ref']},{'stroke':'#000','weight':4},[navigation_proposal['axis_ref'],navigation_proposal['digest']],scale=observation_scale,interaction='Forward'))
        elif dof['kind']=='FAN':objs.append(self.obj('DirectionFan',navigation_proposal['digest'],{'type':'fan','origin':cur['position'],'items':deepcopy(dof['items'])},{'stroke':'#333','dash':'3 3','weight':2},[navigation_proposal['axis_ref'],navigation_proposal['digest']],scale=observation_scale))
        sa=navigation_proposal['scale_action'];objs.append(self.obj('ScalePortal',navigation_proposal['scale_report_ref'],{'type':'scale','action':sa['action'],'target_scale':sa['scale'],'position':cur['position']},{'stroke':'#555','dash':'2 2','weight':2},[navigation_proposal['scale_report_ref'],navigation_proposal['digest']],scale=observation_scale,interaction='Scale'))
        prov={o['id']:o['provenance'] for o in objs};hv={'frame':fr['human_frame'],'clock':clock,'objects':objs,'facticity_styles':{'Simulated':'solid','Unknown':'dotted'},'horizon_styles':{'current':'ring','counterfactual':'fan','open':'diffuse'},'scale_styles':{'micro':'fine','meso':'medium','macro':'coarse'},'provenance_map':prov,'trace_ref':navigation_proposal['digest'],'frame_registration_ref':fr['digest'],'gyro_ref':gyro_state['digest']};hv['digest']=digest_record('GRFPS.HumanView','1.0.0',hv,(fr['digest'],navigation_proposal['digest'],density_field['digest']));return {'human_view':hv,'frame_registration':fr}
    @staticmethod
    def write_svg(hv,path,width=960,height=720):
        path=Path(path);pts=[]
        for o in hv['objects']:
            g=o['geometry']
            for k in ('position','origin','from','to'):
                if isinstance(g.get(k),list) and len(g[k])>=2:pts.append(g[k])
        xs=[p[0] for p in pts] or [0,1];ys=[p[1] for p in pts] or [0,1];xmin,xmax=min(xs),max(xs);ymin,ymax=min(ys),max(ys);dx=max(1e-6,xmax-xmin);dy=max(1e-6,ymax-ymin);pad=80
        def xy(p):return pad+(p[0]-xmin)/dx*(width-2*pad),height-pad-(p[1]-ymin)/dy*(height-2*pad)
        def ln(a,b,stroke='#777',w=1,dash=None):
            x1,y1=xy(a);x2,y2=xy(b);dd=f' stroke-dasharray="{dash}"' if dash else '';return f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{stroke}" stroke-width="{w}"{dd}/>'
        s=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}"><rect width="100%" height="100%" fill="#f8f8f8"/><text x="24" y="34" font-family="monospace" font-size="18">GRFPS Second Layer · {escape(hv["digest"][:16])}</text>']
        for o in hv['objects']:
            g=o['geometry']
            if o['kind']=='SeamLine':s.append(ln(g['from'],g['to'],'#999',1))
        for o in hv['objects']:
            g=o['geometry']
            if o['kind']=='PatchSurface':x,y=xy(g['position']);r=5+3*g['lod'];s.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r}" fill="#fff" stroke="#666" stroke-width="2"/>')
            elif o['kind']=='AttractorMarker':x,y=xy(g['position']);s.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="18" fill="none" stroke="#111" stroke-width="4"/><circle cx="{x:.1f}" cy="{y:.1f}" r="4" fill="#111"/>')
            elif o['kind']=='CenterMarker':x,y=xy(g['position']);s.append(f'<rect x="{x-7:.1f}" y="{y-7:.1f}" width="14" height="14" fill="#fff" stroke="#000" stroke-width="3"/>')
            elif o['kind']=='TangentArrow':o0=g['origin'];d=g['direction'];e=[o0[0]+d[0]*.9,o0[1]+d[1]*.9,0];s.append(ln(o0,e,'#000',5));x,y=xy(e);s.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="5" fill="#000"/>')
            elif o['kind']=='DirectionFan':
                for it in g['items']:o0=g['origin'];d=it['direction'];e=[o0[0]+d[0]*.75,o0[1]+d[1]*.75,0];s.append(ln(o0,e,'#333',2,'3 3'))
        sp=next((o for o in hv['objects'] if o['kind']=='ScalePortal'),None)
        if sp:s.append(f'<text x="24" y="{height-34}" font-family="monospace" font-size="16">Scale: {escape(sp["scale"])} → {escape(sp["geometry"]["action"])} {escape(sp["geometry"]["target_scale"])}</text>')
        s.append('</svg>');path.write_text('\n'.join(s)+'\n');return path
    @staticmethod
    def write_html(hv,svg_path,path):
        path=Path(path);rows=''.join(f'<tr><td>{escape(o["kind"])}</td><td><code>{escape(o["machine_ref"][:16])}</code></td><td>{escape(o["scale"])}</td></tr>' for o in hv['objects']);path.write_text(f'<!doctype html><meta charset="utf-8"><title>GRFPS Second Layer</title><style>body{{font-family:system-ui;max-width:1100px;margin:2rem auto}}img{{width:100%;border:1px solid #ddd}}table{{width:100%;border-collapse:collapse}}td,th{{padding:.4rem;border-bottom:1px solid #ddd;text-align:left}}</style><h1>GRFPS Desktop Second Layer</h1><p><code>{escape(hv["digest"])}</code></p><img src="{escape(Path(svg_path).name)}"><table><tr><th>Class</th><th>Machine ref</th><th>Scale</th></tr>{rows}</table>');return path
