from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Iterable

from .canon import canonical_json, digest_record


@dataclass(frozen=True)
class CandidateGene:
    candidate_id: str
    family: str
    gene: dict[str, Any]
    rationale: tuple[str, ...]
    expected_gain: dict[str, float]
    parent_genome_ref: str

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "candidate_id": self.candidate_id,
            "family": self.family,
            "gene": deepcopy(self.gene),
            "rationale": list(self.rationale),
            "expected_gain": deepcopy(self.expected_gain),
            "parent_genome_ref": self.parent_genome_ref,
        }
        payload["digest"] = digest_record("GRFPS.CandidateGene", "1.0.0", payload, (self.parent_genome_ref,))
        return payload


class SedimentationEngine:
    """Deterministic slow-loop reference implementation for R28.

    The engine operates only on sealed run/evaluation bundles. It produces a
    shadow genome, an explicit delta, a migration map and a lineage node. It
    does not mutate a running genome in place.
    """

    def __init__(self, *, acceptance_threshold: float = 0.95):
        self.acceptance_threshold = float(acceptance_threshold)

    @staticmethod
    def _metric_score(report: dict[str, Any]) -> float:
        checks = report.get("checks", {})
        if checks:
            return sum(1.0 for v in checks.values() if bool(v)) / len(checks)
        metrics = report.get("metrics", {})
        vals = [float(v) for v in metrics.values() if isinstance(v, (int, float)) and 0 <= float(v) <= 1]
        return sum(vals) / len(vals) if vals else 0.0

    def propose(self, parent_genome: dict[str, Any], run_bundles: Iterable[dict[str, Any]], evaluation_bundles: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
        parent_ref = parent_genome["digest"]
        evals = list(evaluation_bundles)
        score = min((self._metric_score(e) for e in evals), default=0.0)
        candidates: list[CandidateGene] = []
        if score >= self.acceptance_threshold:
            candidates.append(CandidateGene(
                candidate_id="candidate.render.xr-trace-v1",
                family="render_grammar",
                gene={
                    "id": "render.xr-second-layer",
                    "params": {
                        "mode": "xr-carrier-second-layer",
                        "objects": [
                            "CenterMarker", "HorizonRing", "PatchSurface", "AttractorMarker",
                            "TangentArrow", "DirectionFan", "ScalePortal", "TraceTrail"
                        ],
                        "interactions": ["TargetSelect", "Align", "Forward", "Hold", "Scale"],
                        "stale_visualization": "age-and-dash",
                    },
                },
                rationale=("blind-witness-pass", "view-provenance-pass", "replay-chain-pass"),
                expected_gain={"carrier_readiness": 1.0, "view_traceability": 1.0},
                parent_genome_ref=parent_ref,
            ))
            candidates.append(CandidateGene(
                candidate_id="candidate.phase.realtime-carrier-v1",
                family="phase_profiles",
                gene={
                    "id": "phase.realtime-carrier",
                    "params": {
                        "carrier": "CarrierInterface/v1",
                        "clock": "monotonic-frame-clock",
                        "pose_interpolation": "deterministic-slerp-linear",
                        "stale_after_frames": 3,
                        "tracking_states": ["TRACKED", "DEGRADED", "LOST", "REACQUIRED"],
                    },
                },
                rationale=("axis-transport-pass", "frame-binding-required", "xr-handoff"),
                expected_gain={"realtime_continuity": 1.0, "frame_registration": 1.0},
                parent_genome_ref=parent_ref,
            ))
        return [c.to_dict() for c in sorted(candidates, key=lambda x: x.candidate_id)]

    @staticmethod
    def _bump_minor(version: str) -> str:
        major, minor, patch = (int(x) for x in version.split("."))
        return f"{major}.{minor + 1}.0"

    def build_shadow(self, parent_genome: dict[str, Any], candidates: list[dict[str, Any]]) -> tuple[dict[str, Any], dict[str, Any]]:
        shadow = deepcopy(parent_genome)
        shadow.pop("digest", None)
        shadow["version"] = self._bump_minor(parent_genome["version"])
        shadow["lineage"] = list(dict.fromkeys([*parent_genome.get("lineage", []), parent_genome["digest"]]))
        added: list[dict[str, str]] = []
        for candidate in candidates:
            family = candidate["family"]
            gene = deepcopy(candidate["gene"])
            existing = {g.get("id") for g in shadow.get(family, [])}
            if gene["id"] not in existing:
                shadow.setdefault(family, []).append(gene)
                added.append({"family": family, "gene_id": gene["id"], "candidate_ref": candidate["digest"]})
        # Normalize stable ordering at source level. The compiler performs the final canonicalization.
        for family in ("render_grammar", "phase_profiles"):
            if family in shadow:
                shadow[family] = sorted(shadow[family], key=lambda g: canonical_json(g))
        delta = {
            "change_class": "MINOR",
            "parent_version": parent_genome["version"],
            "shadow_version": shadow["version"],
            "added": added,
            "preserved_gene_ids": sorted({g.get("id") for fam in ("observables", "relations", "ophan_templates", "phase_profiles", "attractor_programs", "boundary_programs", "render_grammar", "evolution_programs") for g in parent_genome.get(fam, []) if g.get("id")}),
        }
        delta["digest"] = digest_record("GRFPS.GenomeDelta", "1.0.0", delta, (parent_genome["digest"],))
        return shadow, delta

    def sediment(self, *, parent_genome: dict[str, Any], candidate_genes: list[dict[str, Any]], compiled_shadow: dict[str, Any], shadow_evaluation: dict[str, Any], conformance: dict[str, Any], run_refs: list[str]) -> dict[str, Any]:
        score = self._metric_score(shadow_evaluation)
        accepted = score >= self.acceptance_threshold and all(bool(v) for v in conformance.values())
        shadow, delta = self.build_shadow(parent_genome, candidate_genes)
        mapping = {
            "parent_genome_ref": parent_genome["digest"],
            "child_genome_ref": compiled_shadow["digest"],
            "gene_identity_map": sorted(
                [{"parent": gid, "child": gid} for gid in delta["preserved_gene_ids"]],
                key=lambda x: x["parent"],
            ),
            "added_gene_ids": sorted(x["gene_id"] for x in delta["added"]),
        }
        mapping["digest"] = digest_record("GRFPS.GenomeMigrationMap", "1.0.0", mapping, (parent_genome["digest"], compiled_shadow["digest"]))
        record = {
            "parent": parent_genome["digest"],
            "child": compiled_shadow["digest"],
            "delta": delta,
            "candidate_refs": [c["digest"] for c in candidate_genes],
            "evidence": sorted(run_refs),
            "metrics": deepcopy(shadow_evaluation.get("metrics", {})),
            "tests": deepcopy(conformance),
            "residues": [],
            "canon": compiled_shadow["digest"],
            "migration_ref": mapping["digest"],
            "status": "SEDIMENTED" if accepted else "SHADOW",
        }
        record["digest"] = digest_record("GRFPS.SedimentationRecord", "1.0.0", record, (parent_genome["digest"], compiled_shadow["digest"]))
        node = {
            "genome_ref": compiled_shadow["digest"],
            "version": compiled_shadow["version"],
            "parents": [parent_genome["digest"]],
            "conformance": deepcopy(conformance),
            "evaluation_ref": shadow_evaluation.get("digest", ""),
            "migration_ref": mapping["digest"],
            "sedimentation_ref": record["digest"],
            "status": record["status"],
        }
        node["digest"] = digest_record("GRFPS.GenomeLineageNode", "1.0.0", node, (parent_genome["digest"],))
        return {
            "candidate_genes": deepcopy(candidate_genes),
            "shadow_source": shadow,
            "delta": delta,
            "migration": mapping,
            "sedimentation_record": record,
            "lineage_node": node,
            "status": record["status"],
            "digest": digest_record("GRFPS.SedimentationBundle", "1.0.0", {"record": record["digest"], "node": node["digest"]}, (parent_genome["digest"], compiled_shadow["digest"])),
        }
