from __future__ import annotations
from copy import deepcopy
from math import acos,cos,sin,sqrt
from .canon import digest_record

def norm(v):return sqrt(sum(float(x)*float(x) for x in v))
def normalize(v):
    n=norm(v); return [1.,0.,0.] if n<=1e-15 else [float(x)/n for x in v]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def qnorm(q):
    n=norm(q);return [1.,0.,0.,0.] if n<=1e-15 else [x/n for x in q]
def quat_from_x(direction):
    a=[1.,0.,0.]; b=normalize(direction); c=max(-1.,min(1.,dot(a,b)))
    if c>1-1e-12:return [1.,0.,0.,0.]
    if c<-1+1e-12:return [0.,0.,0.,1.]
    axis=normalize(cross(a,b)); ang=acos(c); s=sin(ang/2); return qnorm([cos(ang/2),axis[0]*s,axis[1]*s,axis[2]*s])
def qmatrix(q):
    w,x,y,z=qnorm(q); return [[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]]
def sector(d):
    x,y,z=normalize(d); vals=[(abs(x),'PX' if x>=0 else 'NX'),(abs(y),'PY' if y>=0 else 'NY'),(abs(z),'PZ' if z>=0 else 'NZ')]; vals.sort(key=lambda a:(-a[0],a[1]));return vals[0][1]

class GyrosphereEngine:
    SECTORS=('PX','NX','PY','NY','PZ','NZ')
    def orient(self,*,scale_bundle,current_scale,current_cell_ref,attractor_epoch,target_direction=None,nerve_state=None):
        cells=[c for c in scale_bundle['cells'] if c['scale']==current_scale]; cur=next(c for c in cells if c['cell_id']==current_cell_ref); center=cur['position']; gc=[]; covered=set()
        for c in sorted(cells,key=lambda x:x['cell_id']):
            d=normalize([c['position'][i]-center[i] for i in range(3)]) if c['cell_id']!=current_cell_ref else [1.,0.,0.]; q=quat_from_x(d); sec=sector(d);covered.add(sec)
            p={'id':digest_record('GRFPS.GyroCellId','1.0.0',{'scale_cell':c['cell_id'],'scale':current_scale}),'scale_cell_ref':c['cell_id'],'lifted_orientation':q,'visible_orientation':qmatrix(q),'direction':d,'aperture':{'kind':'scale-cell','scale':current_scale},'ophan_ref':c.get('source_ref'),'weight':float(c.get('features',{}).get('density',1.0)),'confidence':1.0,'residue_ref':None,'sector':sec}
            p['digest']=digest_record('GRFPS.GyroCell','1.0.0',p,tuple(c.get('machine_refs',[])));gc.append(p)
        holes=sorted(set(self.SECTORS)-covered); cov={'domain':'S2/reference-6-sector','scale':current_scale,'covered':sorted(covered),'holes':holes,'coverage_fraction':len(covered)/6,'redundancy':max(0,len(gc)-len(covered)),'dependency_rank':len(covered),'uncertainty':1-len(covered)/6};cov['digest']=digest_record('GRFPS.CoverageReport','1.0.0',cov)
        td=normalize(target_direction or [1.,0.,0.]); q=quat_from_x(td); hol=list((nerve_state or {}).get('holonomy_refs',[])); st={'lifted_orientation':q,'visible_orientation':qmatrix(q),'cells':gc,'coverage_ref':cov['digest'],'scale_pose':{'scale':current_scale,'cell_ref':current_cell_ref,'rank':cur['rank']},'attractor_epoch':int(attractor_epoch),'holonomy':hol,'closure':{'spinor_normalized':abs(norm(q)-1)<=1e-12,'coverage_bound':True,'holonomy_witness_count':len(hol),'closed':abs(norm(q)-1)<=1e-12},'target_direction':td};st['digest']=digest_record('GRFPS.GyroState','1.0.0',st,(cov['digest'],current_cell_ref));return {'gyro_state':st,'coverage_report':cov}
    def relax(self,state,*,target_direction,step=1.0):
        step=max(0.,min(1.,float(step))); a=normalize(state['target_direction']);b=normalize(target_direction);d=normalize([(1-step)*a[i]+step*b[i] for i in range(3)]);out=deepcopy(state);out['target_direction']=d;out['lifted_orientation']=quat_from_x(d);out['visible_orientation']=qmatrix(out['lifted_orientation']);out['digest']=digest_record('GRFPS.GyroState','1.0.0',{k:v for k,v in out.items() if k!='digest'},(state['digest'],));return out
