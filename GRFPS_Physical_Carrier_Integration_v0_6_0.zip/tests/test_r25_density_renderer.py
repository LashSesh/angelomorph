from _r20_helpers import run_once

def test_r25_density_materializes_multiple_lod_classes():
    run=run_once(); samples=run['density_field']['density_samples']
    assert samples
    assert len({s['lod'] for s in samples})>=2
    assert all(0.0<=s['effective_density']<=1.0 for s in samples)
