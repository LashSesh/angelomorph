from _r20_helpers import run_once

def test_r20_scale_roundtrips_are_exact():
    run=run_once(); rts=run['scale_bundle']['roundtrip_witnesses']
    assert rts and all(x['status']=='PASS' and x['error']==0.0 for x in rts)
    assert {s['scale_id'] for s in run['scale_bundle']['scale_states']}=={'micro','meso','macro'}
