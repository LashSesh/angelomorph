from grfps_refkernel.view import ViewCompositor
from _r20_helpers import run_once

def test_r26_every_view_object_is_machine_bound_and_svg_is_emittable(tmp_path):
    run=run_once(); hv=run['human_view']
    assert all(o['machine_ref'] and o['provenance'] for o in hv['objects'])
    assert any(o['kind']=='TangentArrow' for o in hv['objects'])
    p=ViewCompositor.write_svg(hv,tmp_path/'view.svg')
    assert p.exists() and '<svg' in p.read_text()
