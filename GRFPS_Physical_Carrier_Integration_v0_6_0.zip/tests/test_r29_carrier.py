from grfps_refkernel.carrier import CarrierSimulator

def test_r29_carrier_suite_is_replayable_and_fault_typed():
    a=CarrierSimulator().run_suite(); b=CarrierSimulator().run_suite()
    assert a['digest']==b['digest']
    reports={r['scenario']:r for r in a['summary']['scenario_reports']}
    assert reports['nominal']['tracking_fraction']==1.0
    assert reports['tracking_loss']['lost_frames']>0
    assert reports['tracking_loss']['reacquired_frames']>0
    assert reports['occlusion']['occluded_frames']>0
    assert reports['latency_spike']['max_display_latency_ms']>reports['nominal']['max_display_latency_ms']
    assert reports['clock_drift']['max_clock_drift_ns']>0
