import json
from pathlib import Path
from grfps_refkernel.carrier import CarrierSimulator
from grfps_refkernel.xr import XRPrototypeBuilder, build_capability_envelope

ROOT=Path(__file__).resolve().parents[1]

def test_r31_capability_envelope_is_scoped_to_simulated_reference_carrier():
    blind=json.loads((ROOT/'conformance/blind-witness-report.json').read_text())
    run=json.loads((ROOT/'examples/navigation-run-bundle.json').read_text())
    suite=CarrierSimulator().run_suite()
    rep=XRPrototypeBuilder.prototype_report(human_view=run['human_view'],carrier_suite=suite,interaction_roundtrip={x:True for x in ['TargetSelect','Align','Forward','Hold','Scale']},render_objects=['CenterMarker','HorizonRing','PatchSurface','AttractorMarker','TangentArrow','DirectionFan','ScalePortal','TraceTrail'])
    env=build_capability_envelope(blind_report=blind,carrier_suite=suite,xr_report=rep,scales=['micro','meso','macro'])
    assert env['software_reference_status']=='SEALED'
    assert env['physical_capability_status']=='PENDING_EXTERNAL_HARDWARE_MEASUREMENT'
    assert env['accuracy']['target']==1.0
