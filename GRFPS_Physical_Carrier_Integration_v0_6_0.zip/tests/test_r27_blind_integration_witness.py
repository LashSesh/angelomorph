from grfps_refkernel.integration import BlindPerceptualOSHarness
from _r20_helpers import ROOT,load_world,load_gt

def test_r27_blind_witness_passes_and_replays():
    h=BlindPerceptualOSHarness(root=ROOT); a=h.execute_observable(load_world(),ROOT/'genomes/reference-navigation.pgen.json'); b=h.execute_observable(load_world(),ROOT/'genomes/reference-navigation.pgen.json')
    report=h.evaluate(a,load_gt())
    assert report['status']=='PASS'
    assert a['replay_manifest']['expected_digests']==b['replay_manifest']['expected_digests']
    assert a['digest']==b['digest']
