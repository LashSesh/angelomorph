import json
from pathlib import Path
from grfps_refkernel.carrier import CarrierSimulator
from grfps_refkernel.xr import XRPrototypeBuilder

ROOT=Path(__file__).resolve().parents[1]

def test_r30_software_xr_contract_materializes_required_surface(tmp_path):
    run=json.loads((ROOT/'examples/navigation-run-bundle.json').read_text())
    suite=CarrierSimulator().run_suite()
    objects=['CenterMarker','HorizonRing','PatchSurface','AttractorMarker','TangentArrow','DirectionFan','ScalePortal','TraceTrail']
    interactions={x:True for x in ['TargetSelect','Align','Forward','Hold','Scale']}
    rep=XRPrototypeBuilder.prototype_report(human_view=run['human_view'],carrier_suite=suite,interaction_roundtrip=interactions,render_objects=objects)
    assert rep['software_status']=='SEALED'
    assert rep['physical_headset_witness']=='PENDING_EXTERNAL_HARDWARE'
    p=XRPrototypeBuilder.write_html(run['human_view'],suite,rep,tmp_path/'xr.html')
    assert 'GRFPS XR Carrier Prototype' in p.read_text()
