from _r20_helpers import run_once

def test_r20_r27_full_vertical_reaches_target_with_scale_disambiguation():
    r=run_once(); acts=[s['action'] for s in r['navigation_steps']]
    assert acts==['LIFT','ADVANCE','ADVANCE','ADVANCE','STOP']
    assert r['chain_valid']
    assert r['final_current_ref']==r['attractor']['binding']['target_ref']
    assert r['human_view']['digest']!=r['final_human_view']['digest']
