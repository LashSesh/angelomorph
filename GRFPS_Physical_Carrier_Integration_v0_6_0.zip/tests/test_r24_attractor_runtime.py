from _r20_helpers import run_once

def test_r24_ratchet_binds_unique_target_and_arrives():
    run=run_once(); a=run['attractor']
    assert a['ratchet']['termination']=='UNIQUE'
    assert len(a['binding']['candidate_refs'])==1
    assert run['final_current_ref']==a['binding']['target_ref']
    assert run['navigation_steps'][-1]['arrival']['arrived']
