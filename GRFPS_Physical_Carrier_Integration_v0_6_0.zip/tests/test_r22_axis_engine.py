from _r20_helpers import run_once

def test_r22_axis_is_ambiguous_then_locks_after_scale_lift():
    run=run_once(); steps=run['navigation_steps']
    assert steps[0]['axis_discovery']['status']=='AMBIGUOUS'
    assert any(s['axis_lock']['status']=='LOCKED' and s['observation_scale_before']=='micro' for s in steps)
