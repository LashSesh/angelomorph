import json
from pathlib import Path
from grfps_refkernel.integration import BlindPerceptualOSHarness

ROOT=Path(__file__).resolve().parents[1]

def load_world(): return json.loads((ROOT/'examples/w24-observable-world.json').read_text())
def load_gt(): return json.loads((ROOT/'conformance/w24-ground-truth.sealed.json').read_text())
def run_once(): return BlindPerceptualOSHarness(root=ROOT).execute_observable(load_world(),ROOT/'genomes/reference-navigation.pgen.json')
