import json
from pathlib import Path
from grfps_refkernel.genome import GenomeCompiler
from grfps_refkernel.operator import OperatorRegistry
from grfps_refkernel.sedimentation import SedimentationEngine

ROOT=Path(__file__).resolve().parents[1]

def test_r28_sediments_passing_blind_witness_into_minor_lineage():
    schema=json.loads((ROOT/'schemas/perceptual-genome.schema.json').read_text())
    parent_source=json.loads((ROOT/'genomes/reference-navigation.pgen.json').read_text())
    reg=OperatorRegistry.r00_r31_registry(); parent,_=GenomeCompiler(reg,schema).compile(parent_source)
    report=json.loads((ROOT/'conformance/blind-witness-report.json').read_text())
    engine=SedimentationEngine(); cands=engine.propose(parent,[],[report]); shadow,delta=engine.build_shadow(parent,cands)
    child,_=GenomeCompiler(reg,schema).compile(shadow)
    bundle=engine.sediment(parent_genome=parent,candidate_genes=cands,compiled_shadow=child,shadow_evaluation=report,conformance={'compile':True,'blind':True,'replay':True},run_refs=[report['observable_run_ref']])
    assert cands and bundle['status']=='SEDIMENTED'
    assert child['version']=='1.2.0'
    assert parent['digest'] in child['lineage']
    assert delta['change_class']=='MINOR'
