from _r20_helpers import run_once

def test_r23_compass_has_horizontal_and_vertical_decisions():
    run=run_once(); p0=run['navigation_steps'][0]['navigation_proposal']
    assert p0['direction_or_fan']['kind']=='FAN'
    assert p0['scale_action']['action']=='LIFT'
    p1=run['navigation_steps'][1]['navigation_proposal']
    assert p1['direction_or_fan']['kind']=='VECTOR'
    assert p1['scale_action']['action']=='HOLD'
