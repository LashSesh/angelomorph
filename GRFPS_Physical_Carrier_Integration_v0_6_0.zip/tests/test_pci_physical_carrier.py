from __future__ import annotations

import json
from pathlib import Path

from jsonschema import validate

from grfps_refkernel.physical import PhysicalCarrierEvaluator, PhysicalCarrierPolicy, PhysicalCarrierSession

ROOT = Path(__file__).resolve().parents[1]


def make_frame(i: int, dt_ns: int = 11_111_111):
    return {
        "frame_index": i,
        "monotonic_time_ns": (i + 1) * dt_ns,
        "predicted_display_time_ns": (i + 2) * dt_ns,
        "predicted_display_period_ns": dt_ns,
        "session_state": "OPENXR_ACTIVE",
        "should_render": True,
        "tracking_state": "TRACKED",
        "head_pose": {"position_m": [0.001 * i, 0.0, 0.0], "orientation_xyzw": [0.0, 0.0, 0.0, 1.0]},
        "views": [
            {"index": 0, "pose": {"position_m": [-0.032, 0.0, 0.0], "orientation_xyzw": [0.0, 0.0, 0.0, 1.0]}},
            {"index": 1, "pose": {"position_m": [0.032, 0.0, 0.0], "orientation_xyzw": [0.0, 0.0, 0.0, 1.0]}},
        ],
        "registration_error_m": 0.003 + (i % 5) * 0.0001,
        "application_frame_ms": 5.5 + (i % 7) * 0.05,
        "provenance_ref": f"trace:frame:{i}",
        "source_api": "DRY_RUN",
    }


def build_session(n=120):
    s = PhysicalCarrierSession("pci-dry-run", "carrier.dry-run", "OpenXR-compatible dry run", "LOCAL")
    for i in range(n):
        s.append_frame(make_frame(i))
    for action in ("Hold", "Align", "TargetSelect", "Forward", "Scale"):
        s.append_event({"kind": "interaction", "action": action, "roundtrip_ok": True, "monotonic_time_ns": (n + 1) * 11_111_111})
    return s.seal()


def test_pci00_frame_schema():
    schema = json.loads((ROOT / "schemas" / "physical-carrier-frame.schema.json").read_text())
    validate(make_frame(0), schema)


def test_pci01_session_digest_chain():
    session = build_session(60)
    assert session["frame_count"] == 60
    assert len(session["digest"]) == 64
    assert session["frames"][0]["digest"] != session["frames"][1]["digest"]


def test_pci02_contiguous_frame_contract():
    s = PhysicalCarrierSession("s", "c", "r", "LOCAL")
    s.append_frame(make_frame(0))
    bad = make_frame(2)
    try:
        s.append_frame(bad)
    except ValueError as e:
        assert "contiguous" in str(e)
    else:
        raise AssertionError("expected contiguous-frame validation")


def test_pci03_physical_witness_pass():
    session = build_session()
    witness = PhysicalCarrierEvaluator.evaluate(session, PhysicalCarrierPolicy())
    assert witness["status"] == "MEASURED_PASS"
    assert witness["checks"]["tracking"]
    assert witness["checks"]["traceability"]
    assert witness["checks"]["registration"]


def test_pci04_external_display_measurement_channel():
    s = PhysicalCarrierSession("s2", "c2", "r2", "LOCAL")
    for i in range(20):
        s.append_frame(make_frame(i))
    s.bind_external_measurement("DisplayLatency_ms", 18.4, unit="ms", method="external-instrument", evidence_ref="evidence:latency:1")
    session = s.seal()
    witness = PhysicalCarrierEvaluator.evaluate(session, PhysicalCarrierPolicy(require_external_display_latency=True))
    assert witness["status"] == "MEASURED_PASS"
    assert witness["metrics"]["display_latency_ms"]["value"] == 18.4


def test_pci05_capability_merge():
    session = build_session()
    witness = PhysicalCarrierEvaluator.evaluate(session)
    reference = json.loads((ROOT / "conformance" / "capability-envelope.simulated.json").read_text())
    cap = PhysicalCarrierEvaluator.capability_envelope(witness=witness, simulated_reference=reference)
    assert cap["status"] == "DEVICE_MEASURED"
    assert cap["reference_capability_ref"] == reference["digest"]
    assert cap["physical_witness_ref"] == witness["digest"]


def test_webxr_probe_and_openxr_bridge_are_present():
    assert (ROOT / "native" / "webxr" / "grfps_webxr_probe.html").exists()
    assert (ROOT / "native" / "openxr" / "grfps_openxr_capture.cpp").exists()
