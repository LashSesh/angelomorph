from math import sqrt
from _r20_helpers import run_once

def test_r21_gyro_lift_and_coverage_are_bound():
    run=run_once(); g=run['gyro_state']; q=g['lifted_orientation']
    assert abs(sqrt(sum(x*x for x in q))-1.0)<1e-12
    assert g['closure']['closed']
    assert 0.0 < run['coverage_report']['coverage_fraction'] <= 1.0
