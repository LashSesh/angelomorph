# GRFPS Physical Carrier Instantiation v0.6.0

## Status

This phase binds the R00–R31 Perceptual Operating Substrate to a concrete XR carrier contract. It converts the previously simulated carrier boundary into a device-measurable session protocol while preserving the same Genome, Runtime, Horizon, Navigation, HumanView, Ledger and Replay identity.

The phase introduces six implementation sediments:

| ID | Sediment | Product |
|---|---|---|
| PCI-00 | Carrier ABI Lock | canonical physical frame/session schemas |
| PCI-01 | OpenXR/WebXR Bridge | host-side telemetry capture paths |
| PCI-02 | Frame Registration | calibration and registration measurement slots |
| PCI-03 | Session Ledger | frame/event digest chain and sealed session bundle |
| PCI-04 | Physical Witness Evaluator | measured metrics, policy checks and witness digest |
| PCI-05 | Capability Seal | merge of device witness with the simulated reference envelope |

## 1. Physical carrier normal form

The carrier is an adapter from a concrete XR runtime into the GRFPS machine frame:

```text
XR Runtime
  -> predicted frame time
  -> head/view pose
  -> reference-space binding
  -> interaction events
  -> GRFPS PhysicalCarrierFrame
  -> Session Ledger
  -> PhysicalCarrierWitness
  -> PhysicalCapabilityEnvelope
```

A frame is an observation product. It carries the runtime timestamp, predicted display time and period, reference-space identity, head pose, view poses, application timing, trace reference and optional registration measurements.

## 2. Measurement classes

GRFPS carries three explicit measurement classes:

1. **runtime-derived** — values exposed by the XR runtime, including predicted display time, predicted display period, poses and view parameters;
2. **application-derived** — values measured by the GRFPS host, including application frame time, provenance completeness and registration residuals against calibration anchors;
3. **externally-measured** — values produced by an independent instrument channel, including end-to-end display latency when such instrumentation is used.

The capability record preserves the class of each measurement.

## 3. OpenXR binding

The native bridge is designed for an OpenXR 1.1 host. The host owns the OpenXR application lifecycle. GRFPS attaches at the frame boundary and converts the host's current carrier state into a canonical telemetry record.

The integration source is located at:

```text
native/openxr/grfps_openxr_capture.hpp
native/openxr/grfps_openxr_capture.cpp
```

The call is made after frame synchronization using the predicted display time of the active frame. The bridge samples the viewer/base-space relation and view poses, then emits one JSON object per carrier frame.

## 4. WebXR device probe

`native/webxr/grfps_webxr_probe.html` is the browser carrier probe. It enters an immersive session, binds a local reference space, records viewer poses and view transforms, captures select/squeeze interaction events and exports the same line-oriented telemetry form accepted by the physical session recorder.

Run the local probe with:

```text
python scripts/serve_webxr.py
```

Then open the printed localhost address in an XR-capable browser and start the immersive session from the page.

## 5. Session sealing

A raw carrier trace is normalized by:

```text
python scripts/record_physical_session.py \
  --input <telemetry.jsonl> \
  --output <session.json> \
  --session-id <id> \
  --carrier-id <model-instance> \
  --runtime <runtime-name>
```

The resulting `PhysicalCarrierSession` contains a contiguous frame chain, interaction/event records, optional external measurements and a session digest.

## 6. Physical witness

A sealed session is evaluated with:

```text
python scripts/evaluate_physical_session.py \
  --session <session.json> \
  --output <witness.json>
```

The witness evaluates:

- tracking fraction,
- view traceability,
- registration-error distribution,
- application-frame distribution,
- interaction roundtrip,
- externally bound display-latency evidence when present.

The thresholds are carried by `PhysicalCarrierPolicy` and become part of the witness digest.

## 7. Capability seal

The device witness is merged with the existing simulated reference capability by:

```text
python scripts/seal_physical_capability.py \
  --witness <witness.json> \
  --reference conformance/capability-envelope.simulated.json \
  --output <physical-capability.json>
```

The resulting envelope binds the real carrier measurement lineage to the same GRFPS reference capability that produced the synthetic W24 witness.

## 8. Carrier calibration profile

The physical carrier profile binds the transform chain

```text
FW <-> FM <-> FH <-> FD
```

and records calibration references at each bridge. Registration residuals are attached to frames or calibration epochs. Recalibration therefore changes an explicit calibration lineage while preserving the Perceptual Genome and run identity.

## 9. Device witness sequence

The first physical witness uses the following finite sequence:

```text
BindCarrier
-> Calibrate
-> StartSession
-> Hold
-> Align
-> TargetSelect
-> Forward
-> Scale
-> Reacquire
-> StopSession
-> SealSession
-> Evaluate
-> SealCapability
```

The rendered object vocabulary remains the v3 vocabulary: `CenterMarker`, `HorizonRing`, `PatchSurface`, `AttractorMarker`, `TangentArrow`, `DirectionFan`, `ScalePortal` and `TraceTrail`.

## 10. Exit state

The software-side physical carrier bridge is complete when:

- the physical frame schema validates,
- OpenXR and WebXR adapters emit the same canonical carrier surface,
- session frame ordering is monotonic and digest-chained,
- interaction events bind to the same session lineage,
- measurement classes remain explicit,
- a device trace can be transformed deterministically into a `PhysicalCarrierWitness`,
- the witness can be merged into a `PhysicalCapabilityEnvelope`,
- the complete dry-run transport is replayable.

The remaining device operation is the population of these already-bound measurement channels by a concrete headset session.
