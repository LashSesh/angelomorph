# GRFPS Device Run Card

## Session identity

- Carrier instance: ____________________
- XR runtime: _________________________
- Runtime version: ____________________
- Reference space: ____________________
- Genome digest: ______________________
- GRFPS release digest: _______________
- Calibration ref: ____________________

## Sequence

`BindCarrier -> Calibrate -> StartSession -> Hold -> Align -> TargetSelect -> Forward -> Scale -> Reacquire -> StopSession -> SealSession -> Evaluate -> SealCapability`

## Required files

1. `telemetry.jsonl`
2. `session.json`
3. `physical-witness.json`
4. `physical-capability.json`
5. calibration evidence referenced from the session
6. optional external display-latency evidence

## Core measurements

- tracking fraction
- view traceability
- registration error mean / p95 / max
- application frame time mean / p95 / max
- interaction roundtrip
- display latency evidence class and value

## Release binding

A successful run records the physical witness digest and the resulting physical capability digest into the carrier profile referenced by the Perceptual Genome package.
