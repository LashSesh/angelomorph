# GRFPS Reference Kernel R28–R31

## Release state

This stage binds the slow-loop genome lineage to the continuous carrier interface and the XR presentation contract.

```text
R28  Sedimentation Engine
R29  Real-time Carrier Interface
R30  XR Carrier Software Prototype
R31  Capability Envelope / Physical Witness Gate
```

The software vertical is sealed as `0.5.0-rc1`. The physical carrier witness is represented as an explicit acquisition state and becomes the final measurement input for a device-specific capability envelope.

## R28 — Sedimentation Engine

The slow loop consumes sealed run bundles and evaluation bundles. Candidate genes are generated from witnessed runtime structure, compiled into a shadow genome, evaluated against the reference world, and promoted through a lineage witness.

The reference transition is:

```text
reference-navigation.pgen.json  v1.1.0
          |
          | COLLECT -> EVALUATE -> PROPOSE -> SHADOW -> RECOMPILE -> SEDIMENT
          v
reference-xr.pgen.json          v1.2.0
```

The sedimented genome adds two typed capabilities:

- `render.xr-second-layer`: CenterMarker, HorizonRing, PatchSurface, AttractorMarker, TangentArrow, DirectionFan, ScalePortal and TraceTrail, together with TargetSelect, Align, Forward, Hold and Scale interactions.
- `phase.realtime-carrier`: a continuous carrier phase profile with monotonic frame clock, deterministic interpolation, stale classification and tracking-state lineage.

The lineage node carries parent digest, child digest, conformance bundle, evaluation reference and migration map. The W24 shadow run remains a passing blind witness and replays exactly.

## R29 — Real-time Carrier Interface

The carrier contract implements the GRFPS tuple

```text
CI = (Pose, Frames, Clock, Input, Display, Sensors,
      Occlusion, Calibration, Latency, Capabilities)
```

The reference simulator emits 180 deterministic frames at 90 Hz per scenario. Each frame carries:

- pose and tracking state;
- `FW <-> FM <-> FH <-> FD` framegraph transforms;
- frame clock and drift;
- display and input latency;
- occlusion regions and field of view;
- calibration uncertainty and registration error;
- capability declaration;
- content digest.

The conformance suite executes five carrier profiles:

```text
nominal
tracking_loss
clock_drift
occlusion
latency_spike
```

Tracking loss includes a typed reacquisition interval. Clock drift remains explicit in the frame record. Occlusion and latency are propagated as view-relevant carrier state. The full carrier suite has exact simulated replay identity.

## R30 — XR Carrier Software Prototype

The XR prototype consumes a sealed HumanView and the carrier contract. Its canonical scene vocabulary is:

```text
CenterMarker
HorizonRing
PatchSurface
AttractorMarker
TangentArrow / DirectionFan
ScalePortal
TraceTrail
```

Its canonical interaction vocabulary is:

```text
TargetSelect
Align
Forward
Hold
Scale
```

The standalone browser prototype renders the phase-horizon scene, structural surface, attractor, tangent direction, scale transition and trace path. It also reports browser XR capability when exposed by the runtime.

The software witness records:

```text
FrameRegistrationError
DisplayLatency
ViewTraceability
InteractionRoundtrip
```

The current prototype report is software-sealed. The device-specific headset witness is an explicit external acquisition record.

## R31 — Capability Envelope

The reference envelope has the form

```text
Cap = (
  domains,
  scales,
  latency,
  accuracy,
  coverage,
  robustness,
  interaction,
  resourceEnvelope
)
```

The current envelope is scoped to the deterministic synthetic reference carrier. It binds:

- the W24 target, arrival and boundary metrics;
- micro/meso/macro scale coverage;
- nominal carrier latency;
- tracking-loss, clock-drift, occlusion and latency-spike profiles;
- interaction roundtrip;
- reference frame-rate and frame-count resources.

A physical instance produces its device envelope by supplying the hardware witness template with measured registration, latency, traceability, interaction, tracking and occlusion data.

## Cumulative normal form

```text
Perceptual Genome
 -> Ophan Field
 -> Coherence / Dependency Quotient
 -> GraphInfogenome / Gluing / Nerve
 -> Mirror / Reflection Region / Phase Horizon
 -> Scale Lattice / Gyrosphere
 -> Attractor / Axis / Tangent Compass
 -> HumanView
 -> Sedimentation Lineage
 -> Carrier Interface
 -> XR View
 -> Capability Envelope
```

This is the complete v3 software handoff surface. Device measurement specializes the carrier contract into a concrete physical capability profile.
