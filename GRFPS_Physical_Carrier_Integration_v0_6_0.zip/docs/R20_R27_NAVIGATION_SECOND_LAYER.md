# GRFPS R20–R27 — Multiscale Navigation and Desktop Second Layer

**Reference Kernel:** v0.4.0  
**Normative parent:** GRFPS v3.0.0  
**Cumulative stage:** R00–R27

## Vertical

```text
R20 Scale Lattice
  -> R21 Gyrosphere
  -> R22 Axis Engine
  -> R23 Tangent Compass
  -> R24 Attractor Runtime
  -> R25 Density Renderer
  -> R26 Desktop Second Layer
  -> R27 Blind Integration Witness
```

The vertical turns the R12–R19 reflective operational map into a navigable multiscale field. A position is carried by a mesoscopic chart cell while observation resolution may migrate across the scale lattice. The axis engine derives continuation classes from the active attractor potential. The tangent compass exposes horizontal continuation and vertical scale action in the same proposal.

## R20 — Scale lattice

The reference genome declares `micro -> meso -> macro` quotient edges. Runtime exposes the inverse direction as a typed lift. Cartographic patches are bound as mesoscopic cells, each local patch receives provenance-bound micro children, and the certified reflective region forms a macro cell. Every parent with children emits a `CrossScaleWitness` for `Q(L(x)) ~ x`.

## R21 — Gyrosphere

Meso cells become oriented gyrocells. A normalized lifted quaternion, visible orientation matrix, six-sector coverage report, scale pose, attractor epoch and holonomy references form one `GyroState`.

## R22–R23 — Axis and compass

The attractor potential assigns each mesoscopic cell a continuation value. Axis discovery compares admissible atlas neighbors. Equal best continuations emit a `DirectionFan`; sufficient separation emits an `AxisLock`. The compass returns:

```text
(direction_or_fan, scale_action, expected_progress, uncertainty)
```

The W24 reference world intentionally begins with a mesoscopic tie. The scale action is `LIFT micro`. Fine-scale signal breaks the tie and produces a locked continuation vector.

## R24 — Attractor runtime

A structural attractor is encoded as an ordered predicate ratchet. The W24 profile contracts the patch set by cycle rank, boundary cut count, fine-scale signal and member count until one terminal high-signal dyad remains. Navigation then minimizes topological potential to the bound target class.

## R25–R26 — Density and view

`PerceptualDensityField` converts certified local structural density into LOD classes. `HumanView` projects machine-bound patch surfaces, seams, attractor marker, center marker, tangent arrow or direction fan, horizon and scale action. Every visible object carries a machine reference and provenance list. The reference compositor emits deterministic SVG and HTML desktop views.

## R27 — W24 Blind Integration Witness

The runtime receives `w24-observable-world.json`; the evaluator receives the sealed ground-truth file only after the observable run is complete. The witness checks target identification, arrival, scale-mediated axis disambiguation, navigation regret, scale regret, reflection-region IoU, complete view provenance and replay identity.

The expected reference trajectory is:

```text
FAN@meso -> LIFT micro -> LOCK -> ADVANCE -> ADVANCE -> ADVANCE -> ARRIVAL
```

The movement path has three mesoscopic advances, equal to the sealed shortest-path witness.

## Handoff

R27 seals the first visible end-to-end Perceptual-OS witness. The next cumulative vertical is R28–R31: sedimentation lineage, real-time carrier interface, XR prototype and capability release.
