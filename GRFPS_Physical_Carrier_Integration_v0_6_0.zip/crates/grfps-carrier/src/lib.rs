use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PoseState {
    pub position_m: [f64; 3],
    pub orientation_xyzw: [f64; 4],
    pub tracking: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct CarrierFrame {
    pub carrier_id: String,
    pub scenario: String,
    pub frame_index: u64,
    pub clock_ns: u64,
    pub pose: PoseState,
    pub digest: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct CarrierSuiteSummary {
    pub carrier_id: String,
    pub all_traceable: bool,
    pub replay_class: String,
    pub digest: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PhysicalHeadPose {
    pub position_m: [f64; 3],
    pub orientation_xyzw: [f64; 4],
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PhysicalCarrierFrame {
    pub frame_index: u64,
    pub monotonic_time_ns: u64,
    pub predicted_display_time_ns: i64,
    pub predicted_display_period_ns: i64,
    pub session_state: String,
    pub should_render: bool,
    pub tracking_state: String,
    pub reference_space: String,
    pub head_pose: PhysicalHeadPose,
    pub views: Vec<serde_json::Value>,
    pub registration_error_m: Option<f64>,
    pub application_frame_ms: Option<f64>,
    pub provenance_ref: String,
    pub digest: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PhysicalCarrierWitness {
    pub witness_class: String,
    pub session_ref: String,
    pub metrics: serde_json::Value,
    pub checks: serde_json::Value,
    pub status: String,
    pub digest: String,
}
