pub fn normalize_quaternion(q: [f64;4]) -> [f64;4] { let n=q.iter().map(|x|x*x).sum::<f64>().sqrt(); if n<=1e-15 {[1.0,0.0,0.0,0.0]} else {[q[0]/n,q[1]/n,q[2]/n,q[3]/n]} }
#[cfg(test)] mod tests { use super::*; #[test] fn normalizes() { assert_eq!(normalize_quaternion([2.0,0.0,0.0,0.0]), [1.0,0.0,0.0,0.0]); } }
