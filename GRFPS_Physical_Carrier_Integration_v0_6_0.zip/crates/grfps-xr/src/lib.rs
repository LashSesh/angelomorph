use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct XRPrototypeReport {
    pub prototype_class: String,
    pub software_status: String,
    pub physical_headset_witness: String,
    pub digest: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct CapabilityEnvelope {
    pub envelope_class: String,
    pub domains: Vec<String>,
    pub scales: Vec<String>,
    pub software_reference_status: String,
    pub physical_capability_status: String,
    pub digest: String,
}
