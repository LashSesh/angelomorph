use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct CandidateGene {
    pub candidate_id: String,
    pub family: String,
    pub parent_genome_ref: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SedimentationRecord {
    pub parent: String,
    pub child: String,
    pub status: String,
    pub digest: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct GenomeLineageNode {
    pub genome_ref: String,
    pub version: String,
    pub parents: Vec<String>,
    pub status: String,
    pub digest: String,
}
