use grfps_canon::digest_record;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CrossScaleWitness {
    pub parent_ref: String,
    pub children: Vec<String>,
    pub recovered_parent_refs: Vec<String>,
    pub error: f64,
    pub status: String,
    pub digest: String,
}

pub fn roundtrip_witness(parent: &str, children: &[String], recovered: &[String]) -> serde_json::Result<CrossScaleWitness> {
    let ok = recovered == [parent.to_string()];
    let mut w = CrossScaleWitness { parent_ref: parent.into(), children: children.to_vec(), recovered_parent_refs: recovered.to_vec(), error: if ok {0.0} else {1.0}, status: if ok {"PASS".into()} else {"FAIL".into()}, digest: String::new() };
    w.digest = digest_record("GRFPS.CrossScaleWitness", "1.0.0", &w, &[])?;
    Ok(w)
}

#[cfg(test)] mod tests { use super::*; #[test] fn exact_roundtrip() { assert_eq!(roundtrip_witness("p", &["c".into()], &["p".into()]).unwrap().status, "PASS"); } }
