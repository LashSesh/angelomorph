use grfps_canon::digest_record;
use serde::{Deserialize, Serialize};
use serde_json::Value;
#[derive(Debug, Clone, Serialize, Deserialize)] pub struct ViewObject { pub kind:String, pub machine_ref:String, pub geometry:Value, pub provenance:Vec<String>, pub digest:String }
pub fn build_object(kind:&str,machine_ref:&str,geometry:Value,provenance:Vec<String>) -> serde_json::Result<ViewObject> { let mut v=ViewObject{kind:kind.into(),machine_ref:machine_ref.into(),geometry,provenance,digest:String::new()}; v.digest=digest_record("GRFPS.ViewObject","1.0.0",&v,&[machine_ref.into()])?; Ok(v) }
pub fn provenance_complete(objects:&[ViewObject])->bool { objects.iter().all(|o| !o.machine_ref.is_empty() && !o.provenance.is_empty()) }
#[cfg(test)] mod tests { use super::*; #[test] fn provenance() { let o=build_object("TangentArrow","m",serde_json::json!({}),vec!["p".into()]).unwrap(); assert!(provenance_complete(&[o])); } }
