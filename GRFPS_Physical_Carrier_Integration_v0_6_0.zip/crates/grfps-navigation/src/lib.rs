use grfps_canon::digest_record;
use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AxisLock { pub axis_class: Option<String>, pub margin: f64, pub attractor_epoch: u64, pub confidence: f64, pub status: String, pub direction: Option<[f64;3]>, pub next_ref: Option<String>, pub digest: String }
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NavigationProposal { pub target_epoch: u64, pub axis_ref: String, pub direction_or_fan: Value, pub scale_action: Value, pub expected_progress: f64, pub uncertainty: f64, pub validity: String, pub digest: String }
pub fn proposal(axis: &AxisLock, direction: Value, scale: Value, progress: f64) -> serde_json::Result<NavigationProposal> { let mut p=NavigationProposal{target_epoch:axis.attractor_epoch,axis_ref:axis.digest.clone(),direction_or_fan:direction,scale_action:scale,expected_progress:progress,uncertainty:1.0-axis.confidence,validity:"SEALED".into(),digest:String::new()}; p.digest=digest_record("GRFPS.NavigationProposal","1.0.0",&p,&[axis.digest.clone()])?; Ok(p) }
#[cfg(test)] mod tests { use super::*; #[test] fn digest_bound() { let a=AxisLock{axis_class:Some("a->b".into()),margin:1.0,attractor_epoch:0,confidence:1.0,status:"LOCKED".into(),direction:Some([1.0,0.0,0.0]),next_ref:Some("b".into()),digest:"a".repeat(64)}; assert!(!proposal(&a,serde_json::json!({"kind":"VECTOR"}),serde_json::json!({"action":"HOLD"}),1.0).unwrap().digest.is_empty()); } }
