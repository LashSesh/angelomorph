#include "grfps_openxr_capture.hpp"

#include <iomanip>
#include <sstream>
#include <vector>

namespace {
void write_vec3(std::ostringstream& o, const XrVector3f& v) {
    o << '[' << v.x << ',' << v.y << ',' << v.z << ']';
}
void write_quat(std::ostringstream& o, const XrQuaternionf& q) {
    o << '[' << q.x << ',' << q.y << ',' << q.z << ',' << q.w << ']';
}
void write_pose(std::ostringstream& o, const XrPosef& p) {
    o << "{\"position_m\":"; write_vec3(o, p.position);
    o << ",\"orientation_xyzw\":"; write_quat(o, p.orientation); o << '}';
}
const char* tracking_state(XrSpaceLocationFlags flags) {
    const bool p = (flags & XR_SPACE_LOCATION_POSITION_VALID_BIT) != 0;
    const bool q = (flags & XR_SPACE_LOCATION_ORIENTATION_VALID_BIT) != 0;
    return (p && q) ? "TRACKED" : ((p || q) ? "PARTIAL" : "UNAVAILABLE");
}
}

namespace grfps {
std::string capture_openxr_frame_json(
    const CaptureContext& ctx,
    XrSession session,
    const XrFrameState& frame_state,
    uint64_t frame_index,
    uint64_t monotonic_time_ns,
    double application_frame_ms,
    const char* provenance_ref) {

    XrSpaceLocation head{XR_TYPE_SPACE_LOCATION};
    const XrResult locate_space = xrLocateSpace(ctx.view_space, ctx.base_space, frame_state.predictedDisplayTime, &head);

    XrViewLocateInfo li{XR_TYPE_VIEW_LOCATE_INFO};
    li.viewConfigurationType = ctx.view_configuration;
    li.displayTime = frame_state.predictedDisplayTime;
    li.space = ctx.base_space;

    XrViewState vs{XR_TYPE_VIEW_STATE};
    uint32_t count = 0;
    XrResult locate_views = xrLocateViews(session, &li, &vs, 0, &count, nullptr);
    std::vector<XrView> views(count, XrView{XR_TYPE_VIEW});
    if (XR_SUCCEEDED(locate_views) && count > 0) {
        locate_views = xrLocateViews(session, &li, &vs, count, &count, views.data());
    }

    std::ostringstream o;
    o << std::setprecision(9);
    o << "{\"record_kind\":\"frame\"";
    o << ",\"frame_index\":" << frame_index;
    o << ",\"monotonic_time_ns\":" << monotonic_time_ns;
    o << ",\"predicted_display_time_ns\":" << static_cast<int64_t>(frame_state.predictedDisplayTime);
    o << ",\"predicted_display_period_ns\":" << static_cast<int64_t>(frame_state.predictedDisplayPeriod);
    o << ",\"session_state\":\"OPENXR_ACTIVE\"";
    o << ",\"should_render\":" << (frame_state.shouldRender == XR_TRUE ? "true" : "false");
    o << ",\"tracking_state\":\"" << (XR_SUCCEEDED(locate_space) ? tracking_state(head.locationFlags) : "UNAVAILABLE") << "\"";
    o << ",\"reference_space\":\"" << (ctx.reference_space_name ? ctx.reference_space_name : "LOCAL") << "\"";
    o << ",\"head_pose\":";
    if (XR_SUCCEEDED(locate_space)) write_pose(o, head.pose); else o << "{\"position_m\":[0,0,0],\"orientation_xyzw\":[0,0,0,1]}";
    o << ",\"views\":[";
    if (XR_SUCCEEDED(locate_views)) {
        for (uint32_t i = 0; i < count; ++i) {
            if (i) o << ',';
            o << "{\"index\":" << i << ",\"pose\":"; write_pose(o, views[i].pose);
            o << ",\"fov\":{\"angle_left\":" << views[i].fov.angleLeft
              << ",\"angle_right\":" << views[i].fov.angleRight
              << ",\"angle_up\":" << views[i].fov.angleUp
              << ",\"angle_down\":" << views[i].fov.angleDown << "}}";
        }
    }
    o << ']';
    o << ",\"registration_error_m\":null";
    o << ",\"application_frame_ms\":" << application_frame_ms;
    o << ",\"provenance_ref\":\"" << (provenance_ref ? provenance_ref : "") << "\"";
    o << ",\"source_api\":\"OpenXR\"";
    o << ",\"capture_status\":{\"xrLocateSpace\":" << static_cast<int>(locate_space)
      << ",\"xrLocateViews\":" << static_cast<int>(locate_views) << "}";
    o << '}';
    return o.str();
}
} // namespace grfps
