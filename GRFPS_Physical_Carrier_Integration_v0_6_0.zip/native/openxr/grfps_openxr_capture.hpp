#pragma once

#include <openxr/openxr.h>
#include <string>

namespace grfps {

struct CaptureContext {
    const char* session_id;
    const char* carrier_id;
    const char* runtime_name;
    const char* reference_space_name;
    XrViewConfigurationType view_configuration;
    XrSpace view_space;
    XrSpace base_space;
};

// The host OpenXR application owns instance/session/frame lifecycle.
// Call after xrWaitFrame and before xrEndFrame using frameState.predictedDisplayTime.
std::string capture_openxr_frame_json(
    const CaptureContext& ctx,
    XrSession session,
    const XrFrameState& frame_state,
    uint64_t frame_index,
    uint64_t monotonic_time_ns,
    double application_frame_ms,
    const char* provenance_ref);

} // namespace grfps
