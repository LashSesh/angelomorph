# GRFPS OpenXR host bridge

The bridge is embedded in an existing OpenXR host application. The host owns loader, instance, system, session, graphics binding, swapchains and the frame lifecycle. GRFPS receives the carrier state as an observation stream.

## Binding point

For each frame the host performs its regular OpenXR frame synchronization, then calls `grfps::capture_openxr_frame_json(...)` with the `XrFrameState` returned by `xrWaitFrame`. The bridge evaluates the view space against the selected base reference space with `xrLocateSpace` and evaluates display views for the predicted display time with `xrLocateViews`.

Each returned JSON object is one `GRFPS.PhysicalCarrierFrame` input. Write one object per line to a session trace. `scripts/record_physical_session.py` canonicalizes the trace, binds the digest chain and produces a sealed session bundle.

## Carrier identity

A deployment binds:

- runtime name and runtime version,
- headset/carrier model,
- chosen reference-space class,
- calibration record,
- GRFPS Genome/Run digests,
- OpenXR view configuration,
- session and trace identifiers.

The physical witness then measures registration, frame cadence, traceability and interaction behavior on that concrete carrier instance.
