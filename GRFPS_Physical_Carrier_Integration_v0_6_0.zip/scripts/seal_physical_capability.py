#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'python'))

from grfps_refkernel.physical import PhysicalCarrierEvaluator, save_json


def main() -> int:
    ap = argparse.ArgumentParser(description='Bind physical witness to GRFPS capability envelope')
    ap.add_argument('--witness', required=True)
    ap.add_argument('--reference', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()
    witness = json.loads(Path(args.witness).read_text(encoding='utf-8'))
    reference = json.loads(Path(args.reference).read_text(encoding='utf-8'))
    envelope = PhysicalCarrierEvaluator.capability_envelope(witness=witness, simulated_reference=reference)
    save_json(args.output, envelope)
    print(envelope['status'], envelope['digest'])
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
