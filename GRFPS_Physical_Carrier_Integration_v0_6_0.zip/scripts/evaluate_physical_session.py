#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'python'))

from grfps_refkernel.physical import PhysicalCarrierEvaluator, PhysicalCarrierPolicy, save_json


def main() -> int:
    ap = argparse.ArgumentParser(description='Evaluate a sealed GRFPS physical carrier session')
    ap.add_argument('--session', required=True)
    ap.add_argument('--output', required=True)
    ap.add_argument('--require-external-display-latency', action='store_true')
    args = ap.parse_args()
    session = json.loads(Path(args.session).read_text(encoding='utf-8'))
    policy = PhysicalCarrierPolicy(require_external_display_latency=args.require_external_display_latency)
    witness = PhysicalCarrierEvaluator.evaluate(session, policy)
    save_json(args.output, witness)
    print(witness['status'], witness['digest'])
    return 0 if witness['status'] == 'MEASURED_PASS' else 2


if __name__ == '__main__':
    raise SystemExit(main())
