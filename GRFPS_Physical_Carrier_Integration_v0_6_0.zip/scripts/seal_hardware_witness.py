from __future__ import annotations
import json, sys
from pathlib import Path
from jsonschema import Draft202012Validator
from grfps_refkernel.canon import digest_record

ROOT=Path(__file__).resolve().parents[1]

def load(p): return json.loads(Path(p).read_text())
def write(p,x): Path(p).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')

def main(path):
    witness=load(path)
    Draft202012Validator(load(ROOT/'schemas/hardware-witness.schema.json')).validate(witness)
    if witness['status'] not in ('MEASURED','PASS'):
        raise SystemExit('hardware witness status must be MEASURED or PASS')
    req=('FrameRegistrationError_m','DisplayLatency_ms','ViewTraceability','InteractionRoundtrip','tracking_loss_events','occlusion_cases')
    missing=[k for k in req if witness['measurements'].get(k) is None]
    if missing: raise SystemExit('missing measured fields: '+', '.join(missing))
    base=load(ROOT/'conformance/capability-envelope.simulated.json')
    payload={
      'envelope_class':'PHYSICAL_INSTANCE_CAPABILITY',
      'carrier_model':witness['carrier_model'],
      'runtime':witness['runtime'],
      'session':witness['session'],
      'reference_envelope_ref':base['digest'],
      'domains':base['domains'],'scales':base['scales'],
      'latency':{'DisplayLatency_ms':witness['measurements']['DisplayLatency_ms']},
      'accuracy':base['accuracy'],
      'coverage':{'ViewTraceability':witness['measurements']['ViewTraceability']},
      'robustness':{'tracking_loss_events':witness['measurements']['tracking_loss_events'],'occlusion_cases':witness['measurements']['occlusion_cases']},
      'interaction':{'InteractionRoundtrip':witness['measurements']['InteractionRoundtrip']},
      'registration':{'FrameRegistrationError_m':witness['measurements']['FrameRegistrationError_m']},
      'resourceEnvelope':base['resourceEnvelope'],
      'status':'MEASURED'
    }
    payload['digest']=digest_record('GRFPS.PhysicalCapabilityEnvelope','1.0.0',payload,(base['digest'],))
    out=ROOT/'conformance/capability-envelope.physical.json';write(out,payload);print(out)
if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('usage: seal_hardware_witness.py <measured-witness.json>')
    main(sys.argv[1])
