from __future__ import annotations
import hashlib, json
from pathlib import Path
from jsonschema import Draft202012Validator

from grfps_refkernel.canon import digest_record
from grfps_refkernel.operator import OperatorRegistry
from grfps_refkernel.genome import GenomeCompiler
from grfps_refkernel.sedimentation import SedimentationEngine
from grfps_refkernel.integration import BlindPerceptualOSHarness
from grfps_refkernel.carrier import CarrierSimulator
from grfps_refkernel.xr import XRPrototypeBuilder, build_capability_envelope

ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_json(p,obj): Path(p).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def validate(name, records):
    v=Draft202012Validator(load(ROOT/'schemas'/name))
    for r in records: v.validate(r)

def main():
    parent_exit=load(ROOT/'conformance/r20-r27-exit.json')
    parent_release=load(ROOT/'conformance/r00-r27-release.json')
    schema=load(ROOT/'schemas/perceptual-genome.schema.json')
    reg=OperatorRegistry.r00_r31_registry()
    parent_source=load(ROOT/'genomes/reference-navigation.pgen.json')
    parent_genome,_=GenomeCompiler(reg,schema).compile(parent_source)
    parent_run=load(ROOT/'examples/navigation-run-bundle.json')
    parent_eval=load(ROOT/'conformance/blind-witness-report.json')

    # R28: slow-loop candidate generation, shadow evaluation and lineage sedimentation.
    sed_engine=SedimentationEngine()
    candidates=sed_engine.propose(parent_genome,[parent_run],[parent_eval])
    shadow_source, delta=sed_engine.build_shadow(parent_genome,candidates)
    child_genome,child_compile=GenomeCompiler(reg,schema).compile(shadow_source)
    xr_genome_path=ROOT/'genomes/reference-xr.pgen.json'; write_json(xr_genome_path,shadow_source)
    world=load(ROOT/'examples/w24-observable-world.json'); gt=load(ROOT/'conformance/w24-ground-truth.sealed.json')
    harness=BlindPerceptualOSHarness(root=ROOT)
    shadow_run=harness.execute_observable(world,xr_genome_path)
    shadow_run_2=harness.execute_observable(world,xr_genome_path)
    shadow_eval=harness.evaluate(shadow_run,gt)
    shadow_replay_equal=(shadow_run['digest']==shadow_run_2['digest'] and shadow_run['replay_manifest']['expected_digests']==shadow_run_2['replay_manifest']['expected_digests'])
    sediment_conformance={'compile':True,'blind':shadow_eval['status']=='PASS','replay':shadow_replay_equal,'parent_semantics_mapped':True}
    sed_bundle=sed_engine.sediment(parent_genome=parent_genome,candidate_genes=candidates,compiled_shadow=child_genome,shadow_evaluation=shadow_eval,conformance=sediment_conformance,run_refs=[parent_run['digest'],shadow_run['digest']])
    validate('sedimentation-record.schema.json',[sed_bundle['sedimentation_record']]); validate('genome-lineage-node.schema.json',[sed_bundle['lineage_node']])
    write_json(ROOT/'examples/sedimentation-run-bundle.json',sed_bundle)
    write_json(ROOT/'conformance/genome-lineage-node.json',sed_bundle['lineage_node'])
    write_json(ROOT/'conformance/sedimentation-record.json',sed_bundle['sedimentation_record'])
    write_json(ROOT/'examples/xr-shadow-navigation-run.json',shadow_run)
    write_json(ROOT/'conformance/xr-shadow-blind-witness.json',shadow_eval)

    # R29: closed software carrier contract with deterministic fault suite.
    sim=CarrierSimulator(); carrier=sim.run_suite(); carrier2=sim.run_suite(); carrier_replay_equal=carrier['digest']==carrier2['digest']
    validate('carrier-suite.schema.json',[carrier['summary']])
    for scenario in carrier['scenarios'].values():
        validate('carrier-frame.schema.json',[scenario['frames'][0],scenario['frames'][-1]])
    write_json(ROOT/'examples/carrier-simulation-bundle.json',carrier)
    write_json(ROOT/'conformance/carrier-suite-report.json',carrier['summary'])

    # R30: carrier-bound XR software witness. Physical measurements are a separate acquisition witness.
    xr_gene=next(g for g in child_genome['render_grammar'] if g['id']=='render.xr-second-layer')
    interactions={a:True for a in ('TargetSelect','Align','Forward','Hold','Scale')}
    interaction_receipts=[]
    for i,a in enumerate(interactions):
        r={'action':a,'sequence':i,'input_digest':digest_record('GRFPS.XRInput','1.0.0',{'action':a,'sequence':i}),'state':'ACKNOWLEDGED'}
        r['digest']=digest_record('GRFPS.XRInteractionReceipt','1.0.0',r,(shadow_run['human_view']['digest'],))
        interaction_receipts.append(r)
    write_json(ROOT/'examples/xr-interaction-roundtrip.json',{'receipts':interaction_receipts,'all_roundtrip':all(interactions.values())})
    xr_report=XRPrototypeBuilder.prototype_report(human_view=shadow_run['human_view'],carrier_suite=carrier,interaction_roundtrip=interactions,render_objects=xr_gene['params']['objects'])
    validate('xr-prototype-report.schema.json',[xr_report])
    xr_html=XRPrototypeBuilder.write_html(shadow_run['human_view'],carrier,xr_report,ROOT/'examples/xr-carrier-prototype.html')
    write_json(ROOT/'conformance/xr-prototype-report.json',xr_report)
    hardware_template={
        'carrier_model':'FILL_ON_DEVICE','runtime':'OpenXR/WebXR adapter profile','session':{'session_id':'','started_at':'','duration_s':0},
        'measurements':{'FrameRegistrationError_m':None,'DisplayLatency_ms':None,'ViewTraceability':None,'InteractionRoundtrip':None,'tracking_loss_events':None,'occlusion_cases':None},
        'status':'PENDING'
    }
    write_json(ROOT/'examples/hardware-witness-template.json',hardware_template)

    # R31: seal the capability envelope that is actually measured in this environment.
    cap=build_capability_envelope(blind_report=shadow_eval,carrier_suite=carrier,xr_report=xr_report,scales=[s['id'] for s in child_genome['scale_lattice']['scales']])
    validate('capability-envelope.schema.json',[cap])
    write_json(ROOT/'conformance/capability-envelope.simulated.json',cap)

    reg_snapshot=reg.snapshot(); write_json(ROOT/'registry/release-registry.json',reg_snapshot)
    stage={
      'reference_kernel_version':'0.5.0-rc1','grfps_version':'3.0.0','parent_exit_digest':parent_exit['exit_digest'],
      'R28':{'name':'Sedimentation Engine','digest':sed_bundle['digest'],'candidate_count':len(candidates),'parent_genome':parent_genome['digest'],'child_genome':child_genome['digest'],'child_version':child_genome['version'],'shadow_blind_status':shadow_eval['status'],'shadow_replay_equal':shadow_replay_equal,'lineage_ref':sed_bundle['lineage_node']['digest'],'status':'SEALED' if sed_bundle['status']=='SEDIMENTED' else 'HOLD'},
      'R29':{'name':'Real-time Carrier Interface','digest':carrier['digest'],'carrier_id':carrier['summary']['carrier_id'],'scenarios':[r['scenario'] for r in carrier['summary']['scenario_reports']],'frame_count_per_scenario':sim.config.frame_count,'carrier_replay_equal':carrier_replay_equal,'all_traceable':carrier['summary']['all_traceable'],'status':'SEALED' if carrier_replay_equal and carrier['summary']['all_traceable'] else 'HOLD'},
      'R30':{'name':'XR Prototype','digest':xr_report['digest'],'software_status':xr_report['software_status'],'prototype_html_sha256':sha(xr_html),'physical_headset_witness':xr_report['physical_headset_witness'],'status':'SOFTWARE_SEALED' if xr_report['software_status']=='SEALED' else 'HOLD'},
      'R31':{'name':'Capability Release','digest':cap['digest'],'envelope_class':cap['envelope_class'],'software_reference_status':cap['software_reference_status'],'physical_capability_status':cap['physical_capability_status'],'status':'SIMULATED_ENVELOPE_SEALED'},
      'operator_registry_digest':reg_snapshot['digest'],'schema_validation':'PASS','software_vertical_status':'SEALED','physical_vertical_status':'PENDING_EXTERNAL_HARDWARE','release_class':'REFERENCE_RELEASE_CANDIDATE'
    }
    stage['exit_digest']=digest_record('GRFPS.R28-R31.Exit','0.5.0-rc1',stage,(parent_exit['exit_digest'],sed_bundle['digest'],carrier['digest'],xr_report['digest'],cap['digest']))
    write_json(ROOT/'conformance/r28-r31-exit.json',stage)
    release={'release':'GRFPS Reference Kernel R00-R31 v0.5.0-rc1','parent':parent_release,'release_stage':stage,'genome_lineage_node':sed_bundle['lineage_node'],'capability_envelope_ref':cap['digest'],'physical_hardware_gate':'PENDING_EXTERNAL_HARDWARE','files':{
        'xr_genome_sha256':sha(xr_genome_path),'sedimentation_sha256':sha(ROOT/'conformance/sedimentation-record.json'),'carrier_bundle_sha256':sha(ROOT/'examples/carrier-simulation-bundle.json'),'xr_html_sha256':sha(xr_html),'xr_report_sha256':sha(ROOT/'conformance/xr-prototype-report.json'),'capability_sha256':sha(ROOT/'conformance/capability-envelope.simulated.json'),'registry_sha256':sha(ROOT/'registry/release-registry.json'),'schema_manifest_sha256':sha(ROOT/'schemas/record-lock-manifest-r28-r31.json')
    }}
    release['digest']=digest_record('GRFPS.R00-R31.ReleaseCandidate','0.5.0-rc1',release,(stage['exit_digest'],))
    write_json(ROOT/'conformance/r00-r31-release.json',release)
    print(json.dumps(stage,indent=2,sort_keys=True))

if __name__=='__main__': main()
