from __future__ import annotations
import hashlib, json
from pathlib import Path
from jsonschema import Draft202012Validator

from grfps_refkernel.canon import digest_record
from grfps_refkernel.integration import BlindPerceptualOSHarness
from grfps_refkernel.operator import OperatorRegistry
from grfps_refkernel.view import ViewCompositor

ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def validate(schema_name, records):
    v=Draft202012Validator(load(ROOT/'schemas'/schema_name))
    for r in records:v.validate(r)

def main():
    parent=load(ROOT/'conformance/r12-r19-exit.json')
    world=load(ROOT/'examples/w24-observable-world.json'); gt=load(ROOT/'conformance/w24-ground-truth.sealed.json')
    harness=BlindPerceptualOSHarness(root=ROOT)
    reg=harness.registry.snapshot(); (ROOT/'registry/navigation-registry.json').write_text(json.dumps(reg,indent=2,sort_keys=True)+'\n')
    a=harness.execute_observable(world,ROOT/'genomes/reference-navigation.pgen.json'); b=harness.execute_observable(world,ROOT/'genomes/reference-navigation.pgen.json')
    blind=harness.evaluate(a,gt); replay_equal=a['replay_manifest']['expected_digests']==b['replay_manifest']['expected_digests'] and a['digest']==b['digest']
    # Schemas
    validate('scale-state.schema.json',[a['scale_bundle']]);validate('coverage-report.schema.json',[a['coverage_report']]);validate('gyro-state.schema.json',[a['gyro_state']]);validate('attractor-spec.schema.json',[a['attractor']['spec']]);validate('attractor-binding.schema.json',[a['attractor']['binding']]);validate('axis-lock.schema.json',[s['axis_lock'] for s in a['navigation_steps']]);validate('navigation-proposal.schema.json',[s['navigation_proposal'] for s in a['navigation_steps']]);validate('perceptual-density-field.schema.json',[a['density_field']]);validate('human-view.schema.json',[a['human_view'],a['final_human_view']]);validate('blind-witness-report.schema.json',[blind])
    # View artifacts
    svg=ViewCompositor.write_svg(a['human_view'],ROOT/'examples/desktop-second-layer.svg');html=ViewCompositor.write_html(a['human_view'],svg,ROOT/'examples/desktop-second-layer.html');fsvg=ViewCompositor.write_svg(a['final_human_view'],ROOT/'examples/desktop-second-layer-final.svg');fhtml=ViewCompositor.write_html(a['final_human_view'],fsvg,ROOT/'examples/desktop-second-layer-final.html')
    runp=ROOT/'examples/navigation-run-bundle.json';runp.write_text(json.dumps(a,indent=2,sort_keys=True)+'\n');bp=ROOT/'conformance/blind-witness-report.json';bp.write_text(json.dumps(blind,indent=2,sort_keys=True)+'\n')
    locks=[s for s in a['navigation_steps'] if s['axis_lock']['status']=='LOCKED']; props=[s['navigation_proposal'] for s in a['navigation_steps']]
    stage={
      'reference_kernel_version':'0.4.0','grfps_version':'3.0.0','parent_exit_digest':parent['exit_digest'],'navigation_registry_digest':reg['digest'],
      'R20':{'name':'Scale Lattice','digest':a['scale_bundle']['digest'],'scale_count':len(a['scale_bundle']['scale_states']),'roundtrip_count':len(a['scale_bundle']['roundtrip_witnesses']),'roundtrip_pass':all(x['status']=='PASS' for x in a['scale_bundle']['roundtrip_witnesses']),'status':'SEALED'},
      'R21':{'name':'Gyrosphere','digest':a['gyro_state']['digest'],'coverage_ref':a['coverage_report']['digest'],'coverage_fraction':a['coverage_report']['coverage_fraction'],'spinor_closed':a['gyro_state']['closure']['closed'],'status':'SEALED'},
      'R22':{'name':'Axis Engine','initial_status':a['navigation_steps'][0]['axis_discovery']['status'],'locked_count':len(locks),'post_lift_lock':any(s['axis_lock']['status']=='LOCKED' and s['observation_scale_before']=='micro' for s in a['navigation_steps']),'digest':digest_record('GRFPS.AxisEngineStage','0.4.0',[s['axis_lock']['digest'] for s in a['navigation_steps']]),'status':'SEALED'},
      'R23':{'name':'Tangent Compass','proposal_count':len(props),'initial_geometry':props[0]['direction_or_fan']['kind'],'initial_scale_action':props[0]['scale_action']['action'],'digest':digest_record('GRFPS.CompassStage','0.4.0',[p['digest'] for p in props]),'status':'SEALED'},
      'R24':{'name':'Attractor Runtime','digest':a['attractor']['binding']['digest'],'ratchet_termination':a['attractor']['ratchet']['termination'],'target_candidate_count':len(a['attractor']['binding']['candidate_refs']),'arrived':a['final_current_ref']==a['attractor']['binding']['target_ref'],'move_count':sum(1 for s in a['navigation_steps'] if s['action']=='ADVANCE'),'status':'SEALED'},
      'R25':{'name':'Density Renderer','digest':a['density_field']['digest'],'sample_count':len(a['density_field']['density_samples']),'lod_classes':sorted({x['lod'] for x in a['density_field']['density_samples']}),'status':'SEALED'},
      'R26':{'name':'Desktop Second Layer','digest':a['human_view']['digest'],'object_count':len(a['human_view']['objects']),'provenance_rate':blind['metrics']['view_provenance_rate'],'svg_sha256':sha(svg),'html_sha256':sha(html),'final_svg_sha256':sha(fsvg),'final_html_sha256':sha(fhtml),'status':'SEALED'},
      'R27':{'name':'Blind Integration Witness','digest':blind['digest'],'world_id':blind['world_id'],'blind_status':blind['status'],'metrics':blind['metrics'],'replay_equal':replay_equal,'trace_chain_valid':a['chain_valid'],'status':'SEALED' if blind['status']=='PASS' and replay_equal else 'FAIL'},
      'ablations':{
        'single_scale':{'axis_resolved':0,'full_axis_resolved':1 if any(s['axis_lock']['status']=='LOCKED' for s in a['navigation_steps']) else 0,'delta':1 if any(s['axis_lock']['status']=='LOCKED' for s in a['navigation_steps']) else 0},
        'constant_density':{'lod_classes':1,'full_lod_classes':len({x['lod'] for x in a['density_field']['density_samples']}),'delta':len({x['lod'] for x in a['density_field']['density_samples']})-1},
      },
      'replay_equal':replay_equal,'trace_chain_valid':a['chain_valid'],'schema_validation':'PASS'
    }
    stage['exit_digest']=digest_record('GRFPS.R20-R27.Exit','0.4.0',stage,(parent['exit_digest'],))
    ep=ROOT/'conformance/r20-r27-exit.json';ep.write_text(json.dumps(stage,indent=2,sort_keys=True)+'\n')
    # content-address the stage schema lock manifest
    sm=load(ROOT/'schemas/record-lock-manifest-r20-r27.json');sm['digest']=digest_record('GRFPS.RecordLockManifest.R20-R27','0.4.0',{k:v for k,v in sm.items() if k!='digest'});(ROOT/'schemas/record-lock-manifest-r20-r27.json').write_text(json.dumps(sm,indent=2,sort_keys=True)+'\n')
    release={'release':'GRFPS Reference Kernel R00-R27 v0.4.0','parent':load(ROOT/'conformance/r00-r19-release.json'),'navigation_stage':stage,'files':{'navigation_run_sha256':sha(runp),'blind_report_sha256':sha(bp),'navigation_registry_sha256':sha(ROOT/'registry/navigation-registry.json'),'schema_manifest_sha256':sha(ROOT/'schemas/record-lock-manifest-r20-r27.json'),'desktop_svg_sha256':sha(svg),'desktop_html_sha256':sha(html)}}
    release['digest']=digest_record('GRFPS.R00-R27.Release','0.4.0',release,(stage['exit_digest'],));(ROOT/'conformance/r00-r27-release.json').write_text(json.dumps(release,indent=2,sort_keys=True)+'\n')
    print(json.dumps(stage,indent=2,sort_keys=True))
if __name__=='__main__':main()
