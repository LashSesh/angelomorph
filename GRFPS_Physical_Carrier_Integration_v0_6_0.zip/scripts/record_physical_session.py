#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'python'))

from grfps_refkernel.physical import PhysicalCarrierSession, save_json


def main() -> int:
    ap = argparse.ArgumentParser(description='Record GRFPS physical carrier JSONL telemetry')
    ap.add_argument('--input', required=True, help='JSONL telemetry path')
    ap.add_argument('--output', required=True, help='sealed session JSON path')
    ap.add_argument('--session-id', required=True)
    ap.add_argument('--carrier-id', required=True)
    ap.add_argument('--runtime', required=True)
    ap.add_argument('--reference-space', default='LOCAL')
    ap.add_argument('--external-display-latency-ms', type=float)
    args = ap.parse_args()

    session = PhysicalCarrierSession(args.session_id, args.carrier_id, args.runtime, args.reference_space)
    for raw in Path(args.input).read_text(encoding='utf-8').splitlines():
        if not raw.strip():
            continue
        rec = json.loads(raw)
        kind = rec.pop('record_kind', 'frame')
        if kind == 'frame':
            session.append_frame(rec)
        elif kind == 'event':
            session.append_event(rec)
        else:
            raise ValueError(f'unknown record_kind {kind!r}')
    if args.external_display_latency_ms is not None:
        session.bind_external_measurement(
            'DisplayLatency_ms',
            args.external_display_latency_ms,
            unit='ms',
            method='external-instrument',
        )
    sealed = session.seal()
    save_json(args.output, sealed)
    print(sealed['digest'])
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
