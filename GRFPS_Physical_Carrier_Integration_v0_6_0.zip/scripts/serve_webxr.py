#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse, os

ap = argparse.ArgumentParser(description='Serve GRFPS WebXR probe on localhost')
ap.add_argument('--port', type=int, default=8000)
args = ap.parse_args()
root = Path(__file__).resolve().parents[1] / 'native' / 'webxr'
os.chdir(root)
print(f'GRFPS WebXR probe: http://localhost:{args.port}/grfps_webxr_probe.html')
ThreadingHTTPServer(('127.0.0.1', args.port), SimpleHTTPRequestHandler).serve_forever()
