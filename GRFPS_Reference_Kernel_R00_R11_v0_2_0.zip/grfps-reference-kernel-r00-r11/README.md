# GRFPS Reference Kernel — R00–R11

**Version:** 0.2.0  
**Normative parent:** GRFPS v3.0.0 — Generative Rotor-Fiber Perceptual Substrate  
**Stage:** Machine Floor + Adaptive Ophan Field

This repository materializes the cumulative GRFPS reference vertical from Identity Lock through the first adaptive perceptual-organ runtime.

```text
R00 Identity Lock
R01 Schema Lock
R02 Kernel Skeleton
R03 Empty Run
R04 Genome AST
R05 Genome Compiler
R06 Ophan Template
R07 Wing Runtime
R08 Multi-Ophan Bank
R09 Coherence Graph
R10 Scheduler
R11 Dependency Quotient
```

## Runtime normal form

```text
PerceptualGenome
  -> OphanTemplates
  -> MultiOphanBank
  -> DirectedExposures
  -> CoherenceGraph
  -> DependencyQuotient
  -> SchedulerDecision
```

The active machine state remains the canonical 12-part surface:

```text
Binding | CausalField | PerceptualGenome | OphanField
SyntheticPercept | InfogeneticMap | ReflectionShell | Gyrosphere
Navigator | EffectPort | HumanView | Ledger
```

with `Lineage` as the slow-time surface.

## Repository layout

- `python/grfps_refkernel/` — executable semantic reference and conformance runtime.
- `crates/` — Rust-oriented target workspace, including `grfps-ophan` and `grfps-coherence`.
- `schemas/` — parent schema lock plus the R06–R11 extension schemas.
- `registry/` — sealed core registry and cumulative adaptive registry.
- `genomes/` — minimal kernel genome and three-Ophan adaptive reference genome.
- `examples/` — sealed empty run plus adaptive Ophan-field run bundle.
- `conformance/` — parent exit, adaptive exit and cumulative release manifest.
- `docs/` — stage specifications and binding records.
- `tests/` — cumulative stage conformance suite.

## Execute conformance

```bash
./run_conformance.sh
```

The suite rebuilds both cumulative stage bundles and executes the full Python reference test set.

## Canonical handoff

`conformance/r06-r11-exit.json` is the parent artifact for R12.

The next vertical is:

```text
GraphWindow Scanner -> GraphResonites -> GraphInfogenome
-> Gluing Engine -> Nerve Complex -> Mirror Engine
-> Reflection Region -> Phase Horizon / Rolling Atlas
```
