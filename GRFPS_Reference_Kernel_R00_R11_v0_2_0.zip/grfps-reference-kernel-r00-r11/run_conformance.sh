#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export PYTHONPATH="$ROOT/python"
python3 "$ROOT/scripts/build_conformance.py" > "$ROOT/conformance/r00-r05-build-log.txt"
python3 "$ROOT/scripts/build_r06_r11_conformance.py" > "$ROOT/conformance/r06-r11-build-log.txt"
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest "$ROOT/tests" -q | tee "$ROOT/conformance/test-log.txt"
