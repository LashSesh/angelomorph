from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .canon import digest_record
from .types import OperatorSpec


@dataclass(frozen=True)
class RegistryEntry:
    spec: OperatorSpec
    digest: str

    def to_dict(self) -> dict:
        return {"digest": self.digest, **self.spec.payload()}


class OperatorRegistry:
    def __init__(self, specs: Iterable[OperatorSpec] = ()):
        self._by_digest: dict[str, RegistryEntry] = {}
        self._by_name: dict[tuple[str, str], RegistryEntry] = {}
        for spec in specs:
            self.register(spec)

    @staticmethod
    def digest_spec(spec: OperatorSpec) -> str:
        return digest_record("GRFPS.OperatorSpec", spec.version, spec.payload())

    def register(self, spec: OperatorSpec) -> RegistryEntry:
        digest = self.digest_spec(spec)
        entry = RegistryEntry(spec=spec, digest=digest)
        key = (spec.operator_id, spec.version)
        existing = self._by_name.get(key)
        if existing and existing.digest != digest:
            raise ValueError(f"operator identity collision for {key}")
        self._by_digest[digest] = entry
        self._by_name[key] = entry
        return entry

    def resolve_digest(self, digest: str) -> RegistryEntry:
        try:
            return self._by_digest[digest]
        except KeyError as exc:
            raise KeyError(f"unresolved operator digest: {digest}") from exc

    def resolve_name(self, operator_id: str, version: str) -> RegistryEntry:
        return self._by_name[(operator_id, version)]

    def snapshot(self) -> dict:
        entries = [entry.to_dict() for _, entry in sorted(self._by_digest.items())]
        digest = digest_record("GRFPS.OperatorRegistry", "1.0.0", entries)
        return {"entries": entries, "digest": digest}

    @classmethod
    def core_registry(cls) -> "OperatorRegistry":
        from .types import DeterminismClass

        rows = [
            ("constitution.bindRun", "Constitution", "RunInput", "RunDescriptor", "constitution"),
            ("constitution.bindCenter", "Constitution", "CenterInput", "CenterBinding", "constitution"),
            ("constitution.bindWorld", "Constitution", "WorldInput", "WorldBinding", "constitution"),
            ("constitution.canon", "Constitution", "AnyCanonicalizable", "CanonicalRecord", "constitution"),
            ("constitution.digest", "Constitution", "CanonicalRecord", "Digest", "constitution"),
            ("constitution.seal", "Constitution", "KernelState", "SealedRun", "constitution"),
            ("genome.parseGenome", "Genome", "GenomePackage", "GenomeAst", "genome"),
            ("genome.resolveGenes", "Genome", "GenomeAst", "ResolvedGenome", "genome"),
            ("genome.typeGenome", "Genome", "ResolvedGenome", "TypedGenome", "genome"),
            ("genome.canonicalizeGenome", "Genome", "TypedGenome", "CanonicalGenome", "genome"),
            ("genome.linkGenome", "Genome", "CanonicalGenome", "LinkedGenome", "genome"),
            ("genome.planGenome", "Genome", "LinkedGenome", "CompilePlan", "genome"),
            ("genome.sealGenome", "Genome", "CompilePlan", "CompileManifest", "genome"),
            ("ledger.appendTrace", "Ledger", "Transition", "TraceSegment", "ledger"),
            ("ledger.checkpoint", "Ledger", "RuntimeState", "Checkpoint", "ledger"),
            ("ledger.replay", "Ledger", "ReplayManifest", "ReplayResult", "ledger"),
        ]
        specs = [
            OperatorSpec(
                operator_id=op,
                version="1.0.0",
                family=family,
                domain=domain,
                codomain=codomain,
                determinism=DeterminismClass.DETERMINISTIC,
                capability_namespace=cap,
                witness_products=("TraceWitness",),
                residue_classes=("TypedResidual",),
                trace_fields=("input_digest", "pre_digest", "post_digest"),
            )
            for op, family, domain, codomain, cap in rows
        ]
        return cls(specs)
    @classmethod
    def r00_r11_registry(cls) -> "OperatorRegistry":
        from .types import DeterminismClass

        base = [entry.spec for entry in cls.core_registry()._by_digest.values()]
        rows = [
            ("ophan.compileOphan", "Ophan", "OphanGene", "OphanSpec", "ophan"),
            ("ophan.spawnOphan", "Ophan", "OphanSpec", "OphanState", "ophan"),
            ("ophan.calibrateOphan", "Ophan", "OphanState", "OphanState", "ophan"),
            ("ophan.activateOphan", "Ophan", "OphanState", "OphanState", "ophan"),
            ("ophan.expose", "Ophan", "OphanState", "ExposureState", "ophan"),
            ("ophan.retireOphan", "Ophan", "OphanState", "OphanState", "ophan"),
            ("coherence.buildOperatorGraph", "Coherence", "OphanBank", "CoherenceGraph", "coherence"),
            ("coherence.updateCoherence", "Coherence", "CoherenceGraph", "CoherenceGraph", "coherence"),
            ("coherence.quotientDependencies", "Coherence", "ResponseSet", "DependencyProfile", "coherence"),
            ("coherence.scoreCandidate", "Coherence", "ScheduleCandidate", "ScoredCandidate", "scheduler"),
            ("coherence.allocateBudget", "Coherence", "ScoredCandidateSet", "SchedulerDecision", "scheduler"),
            ("coherence.reconfigureGraph", "Coherence", "SchedulerDecision", "OphanBank", "scheduler"),
        ]
        extra = [
            OperatorSpec(
                operator_id=op,
                version="1.0.0",
                family=family,
                domain=domain,
                codomain=codomain,
                determinism=DeterminismClass.DETERMINISTIC,
                capability_namespace=cap,
                witness_products=("OphanWitness", "TraceWitness") if family == "Ophan" else ("CoherenceWitness", "TraceWitness"),
                residue_classes=("TypedResidual",),
                trace_fields=("input_digest", "pre_digest", "post_digest"),
                budget_class="perceptual-runtime",
            )
            for op, family, domain, codomain, cap in rows
        ]
        return cls([*base, *extra])

