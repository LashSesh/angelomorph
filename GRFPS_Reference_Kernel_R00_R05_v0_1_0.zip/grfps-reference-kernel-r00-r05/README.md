# GRFPS Reference Kernel — R00–R05

**Version:** 0.1.0  
**Normative parent:** GRFPS v3.0.0 — Generative Rotor-Fiber Perceptual Substrate  
**Stage:** Reference Kernel / Maschinenboden

This repository materializes the first executable vertical of the GRFPS Perceptual Operating Substrate. It binds the v3 identity surface, locks canonical record families, provides a content-addressed operator registry, emits append-only trace/replay artifacts, executes a sealed empty reference run, parses and normalizes a Perceptual Genome AST, and compiles that genome into a deterministic `GenomeCompileManifest` plus `PerceptualProgram`.

## R00–R05 normal form

```text
IdentityLock
  -> SchemaBundle
  -> KernelSkeleton
  -> EmptyRun/Seal/Replay
  -> GenomeAST/NormalForm
  -> GenomeCompiler/CompileManifest/PerceptualProgram
```

The active runtime surface is the canonical 12-part state:

```text
Binding | CausalField | PerceptualGenome | OphanField
SyntheticPercept | InfogeneticMap | ReflectionShell | Gyrosphere
Navigator | EffectPort | HumanView | Ledger
```

with `Lineage` as the thirteenth slow-time surface.

## Repository layout

- `python/grfps_refkernel/` — executable semantic reference used for conformance.
- `crates/` — Rust-oriented target workspace for the same R00–R05 contracts.
- `schemas/` — locked JSON Schemas and record-family manifest.
- `registry/` — content-addressed core operator registry.
- `genomes/` — minimal canonical Perceptual Genome package.
- `examples/` — sealed empty run and synthetic world records.
- `conformance/` — Identity Lock and R00–R05 Exit Digest.
- `tests/` — stage conformance suite.

## Execute conformance

```bash
./run_conformance.sh
```

The run emits the stage digest bundle and executes ten conformance tests.

## Stage output

`conformance/r00-r05-exit.json` is the canonical exit artifact for this phase. Its `exit_digest` is the parent reference for R06.

## Next vertical

R06–R11 materializes the adaptive Ophan field:

```text
OphanTemplate -> WingRuntime -> MultiOphanBank
-> CoherenceGraph -> Scheduler -> DependencyQuotient
```
