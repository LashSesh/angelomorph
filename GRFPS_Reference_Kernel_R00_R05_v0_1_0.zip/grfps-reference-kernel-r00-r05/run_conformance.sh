#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export PYTHONPATH="$ROOT/python"
python3 "$ROOT/scripts/build_conformance.py"
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest "$ROOT/tests" -q
