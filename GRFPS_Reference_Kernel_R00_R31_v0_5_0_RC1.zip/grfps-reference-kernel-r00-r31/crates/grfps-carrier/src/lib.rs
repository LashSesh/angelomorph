use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PoseState {
    pub position_m: [f64; 3],
    pub orientation_xyzw: [f64; 4],
    pub tracking: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct CarrierFrame {
    pub carrier_id: String,
    pub scenario: String,
    pub frame_index: u64,
    pub clock_ns: u64,
    pub pose: PoseState,
    pub digest: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct CarrierSuiteSummary {
    pub carrier_id: String,
    pub all_traceable: bool,
    pub replay_class: String,
    pub digest: String,
}
