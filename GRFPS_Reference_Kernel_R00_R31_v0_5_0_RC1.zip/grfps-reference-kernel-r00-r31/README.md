# GRFPS Reference Kernel — R00–R31

**Version:** 0.5.0-rc1  
**Normative parent:** GRFPS v3.0.0 — Generative Rotor-Fiber Perceptual Substrate  
**Stage:** Perceptual-OS reference vertical through lineage, continuous carrier simulation and XR software prototype

```text
R00–R05  Machine Floor + Perceptual Genome Compiler
R06–R11  Adaptive Ophan Field
R12–R19  Graph-Infogenetic Cartography + Reflection Region
R20–R27  Scale Lattice + Gyrosphere + Axis/Compass + Attractor + Second Layer + Blind Witness
R28       Sedimentation Engine + Genome Lineage
R29       Real-time Carrier Interface
R30       XR Carrier Software Prototype
R31       Simulated Capability Envelope + Physical Witness Gate
```

## Executable normal form

```text
PerceptualGenome
 -> Adaptive Ophan Field
 -> GraphInfogenome / Gluing / Nerve
 -> Mirror / Reflection Region / Phase Horizon
 -> Multiscale Lattice / Gyrosphere
 -> Attractor Potential / Axis / Tangent Compass
 -> HumanView
 -> Sedimentation Lineage
 -> Continuous Carrier Frames
 -> XR Carrier View
 -> Capability Envelope
```

## Conformance

```bash
./run_conformance.sh
```

The software reference suite contains 39 Python tests plus deterministic stage builders. R28 sediments a passing W24 runtime into Genome v1.2.0. R29 executes nominal, tracking-loss, clock-drift, occlusion and latency-spike carrier streams. R30 materializes the XR scene and interaction contract. R31 seals the measured synthetic capability envelope.

## Physical carrier handoff

`examples/hardware-witness-template.json` is the acquisition contract for a real headset/runtime. A measured witness can be sealed with:

```bash
PYTHONPATH=python python scripts/seal_hardware_witness.py examples/hardware-witness.measured.json
```

The resulting device envelope specializes the reference carrier contract to the measured physical instance.

## Canonical artifacts

- `conformance/r28-r31-exit.json`
- `conformance/r00-r31-release.json`
- `conformance/sedimentation-record.json`
- `conformance/carrier-suite-report.json`
- `conformance/xr-prototype-report.json`
- `conformance/capability-envelope.simulated.json`
- `examples/xr-carrier-prototype.html`
