from __future__ import annotations
from copy import deepcopy
from typing import Any
from .canon import digest_record


class MirrorEngine:
    """Constraint contraction over a finite reference candidate fiber."""
    def __init__(self, candidates: list[dict[str,Any]]):
        self._initial=sorted(deepcopy(candidates),key=lambda x:x['id'])
        self._active=deepcopy(self._initial)
        self._constraints=[]
        self._parent=None

    @staticmethod
    def _matches(candidate: dict[str,Any], constraint: dict[str,Any]) -> bool:
        key=constraint['feature']; expected=constraint['value']; tol=float(constraint.get('tolerance',0.0))
        actual=candidate.get('features',{}).get(key)
        if isinstance(expected,(int,float)) and isinstance(actual,(int,float)):
            return abs(float(actual)-float(expected))<=tol
        return actual==expected

    def contract(self, constraints: list[dict[str,Any]], *, model_epoch: int, genome_ref: str, nerve_ref: str, harmonic_ref: str|None=None, horizon_ref: str|None=None, scale_context: str='meso') -> dict[str,Any]:
        before=len(self._active)
        for c in constraints:
            self._active=[x for x in self._active if self._matches(x,c)]
            self._constraints.append(deepcopy(c))
        after=len(self._active)
        marginal=(before-after)/max(1,before)
        candidate_class=[x['id'] for x in self._active]
        alternative_candidates=[x['id'] for x in self._initial if x['id'] not in set(candidate_class)]
        payload={'candidate_class':candidate_class,'alternative_candidates':alternative_candidates,'model_epoch':model_epoch,'evidence_constraints':deepcopy(self._constraints),'axis_locks':[],'harmonic_ref':harmonic_ref,'nerve_ref':nerve_ref,'horizon_ref':horizon_ref,'residuals':[] if candidate_class else ['EMPTY_CANDIDATE_FIBER'],'scale_context':scale_context,'genome_ref':genome_ref,'marginal_gain':marginal,'identifiability':1.0/max(1,len(candidate_class)),'parent_digest':self._parent}
        payload['evidence_digest']=digest_record('GRFPS.MirrorEvidence','1.0.0',payload['evidence_constraints'])
        payload['digest']=digest_record('GRFPS.MirrorState','1.0.0',payload,(() if self._parent is None else (self._parent,)))
        self._parent=payload['digest']
        return payload
