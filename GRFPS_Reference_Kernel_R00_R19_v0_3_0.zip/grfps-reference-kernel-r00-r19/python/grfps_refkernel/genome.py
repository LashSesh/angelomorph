from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .canon import canonical_json, digest_record
from .operator import OperatorRegistry


class GenomeCompileError(ValueError):
    pass


GENE_ARRAY_FIELDS = (
    "observables",
    "relations",
    "ophan_templates",
    "phase_profiles",
    "attractor_programs",
    "boundary_programs",
    "render_grammar",
    "evolution_programs",
)


class GenomeCompiler:
    def __init__(self, registry: OperatorRegistry, schema: dict[str, Any] | None = None):
        self.registry = registry
        self.schema = schema
        self.validator = Draft202012Validator(schema) if schema else None

    def parse(self, source: str | Path | dict[str, Any]) -> dict[str, Any]:
        if isinstance(source, dict):
            ast = deepcopy(source)
        else:
            path = Path(source)
            ast = json.loads(path.read_text(encoding="utf-8"))
        if self.validator:
            errors = sorted(self.validator.iter_errors(ast), key=lambda e: list(e.path))
            if errors:
                raise GenomeCompileError("; ".join(e.message for e in errors))
        return ast

    def normalize(self, ast: dict[str, Any]) -> dict[str, Any]:
        genome = deepcopy(ast)
        genome.pop("digest", None)
        for field in GENE_ARRAY_FIELDS:
            items = genome.get(field, [])
            if isinstance(items, list):
                genome[field] = sorted(items, key=lambda g: canonical_json({"id": g.get("id", ""), "body": g}))
        if isinstance(genome.get("lineage"), list):
            genome["lineage"] = list(dict.fromkeys(genome["lineage"]))
        lattice = genome.get("scale_lattice")
        if isinstance(lattice, dict):
            if isinstance(lattice.get("scales"), list):
                lattice["scales"] = sorted(lattice["scales"], key=lambda s: (s.get("rank", 0), s.get("id", "")))
            if isinstance(lattice.get("transitions"), list):
                lattice["transitions"] = sorted(lattice["transitions"], key=canonical_json)
        return json.loads(canonical_json(genome))

    def resolve(self, genome: dict[str, Any]) -> list[dict[str, Any]]:
        resolved: list[dict[str, Any]] = []
        for field in ("observables", "relations", "ophan_templates", "phase_profiles", "attractor_programs", "boundary_programs", "render_grammar", "evolution_programs"):
            for gene in genome.get(field, []):
                ref = gene.get("operator_ref")
                refs = gene.get("operator_refs", [])
                all_refs = ([ref] if ref else []) + list(refs)
                for op_digest in all_refs:
                    try:
                        entry = self.registry.resolve_digest(op_digest)
                    except KeyError as exc:
                        raise GenomeCompileError(str(exc)) from exc
                    resolved.append({
                        "gene_id": gene["id"],
                        "gene_family": field,
                        "operator_digest": op_digest,
                        "operator_id": entry.spec.operator_id,
                        "operator_version": entry.spec.version,
                        "domain": entry.spec.domain,
                        "codomain": entry.spec.codomain,
                    })
        return sorted(resolved, key=lambda x: (x["gene_family"], x["gene_id"], x["operator_digest"]))

    def type_check(self, genome: dict[str, Any], resolved: list[dict[str, Any]]) -> dict[str, Any]:
        issues: list[dict[str, str]] = []
        by_gene = {r["gene_id"]: r for r in resolved}
        scales = {s["id"] for s in genome.get("scale_lattice", {}).get("scales", [])}
        phases = {p["id"] for p in genome.get("phase_profiles", [])}
        for gene in genome.get("observables", []):
            r = by_gene.get(gene["id"])
            if r:
                if gene.get("input_type") != r["domain"]:
                    issues.append({"gene_id": gene["id"], "field": "input_type", "expected": r["domain"]})
                if gene.get("output_type") != r["codomain"]:
                    issues.append({"gene_id": gene["id"], "field": "output_type", "expected": r["codomain"]})
            for sid in gene.get("scale_scope", []):
                if sid not in scales:
                    issues.append({"gene_id": gene["id"], "field": "scale_scope", "expected": sid})
            for pid in gene.get("phase_scope", []):
                if pid not in phases:
                    issues.append({"gene_id": gene["id"], "field": "phase_scope", "expected": pid})
        return {"ok": not issues, "issues": issues}

    def plan(self, genome: dict[str, Any], resolved: list[dict[str, Any]]) -> dict[str, Any]:
        ordered_gene_ids = []
        for field in GENE_ARRAY_FIELDS:
            ordered_gene_ids.extend(g["id"] for g in genome.get(field, []))
        return {
            "gene_order": ordered_gene_ids,
            "operator_order": [r["operator_digest"] for r in resolved],
            "scales": [s["id"] for s in genome.get("scale_lattice", {}).get("scales", [])],
            "budget_profile": genome.get("budgets", {}),
            "conformance": genome.get("conformance", {}),
        }

    def compile(self, source: str | Path | dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
        ast = self.parse(source)
        canonical = self.normalize(ast)
        resolved = self.resolve(canonical)
        type_report = self.type_check(canonical, resolved)
        if not type_report["ok"]:
            raise GenomeCompileError(f"type report: {type_report['issues']}")
        scheduler_plan = self.plan(canonical, resolved)
        genome_digest = digest_record("GRFPS.PerceptualGenome", canonical["version"], canonical, canonical.get("lineage", []))
        canonical_record = deepcopy(canonical)
        canonical_record["digest"] = genome_digest
        manifest_payload = {
            "genome_ref": genome_digest,
            "resolved_refs": resolved,
            "type_report": type_report,
            "linked_operators": sorted({r["operator_digest"] for r in resolved}),
            "scheduler_plan": scheduler_plan,
            "registry_digest": self.registry.snapshot()["digest"],
        }
        manifest = deepcopy(manifest_payload)
        manifest["digest"] = digest_record("GRFPS.GenomeCompileManifest", "1.0.0", manifest_payload, (genome_digest,))
        program_payload = {
            "genome_ref": genome_digest,
            "compile_manifest_ref": manifest["digest"],
            "operator_dag": scheduler_plan["operator_order"],
            "gene_order": scheduler_plan["gene_order"],
            "scale_lattice": canonical.get("scale_lattice", {}),
            "attractor_programs": canonical.get("attractor_programs", []),
            "boundary_programs": canonical.get("boundary_programs", []),
            "render_grammar": canonical.get("render_grammar", []),
        }
        program = deepcopy(program_payload)
        program["digest"] = digest_record("GRFPS.PerceptualProgram", "1.0.0", program_payload, (manifest["digest"],))
        return canonical_record, {"manifest": manifest, "program": program}
