from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from enum import Enum
from math import cos, sin, tau
from typing import Any, Iterable

from .canon import canonical_json, digest_record
from .ledger import Ledger
from .operator import OperatorRegistry


class OphanLifecycle(str, Enum):
    TEMPLATE = "TEMPLATE"
    INSTANTIATED = "INSTANTIATED"
    CALIBRATED = "CALIBRATED"
    ACTIVE = "ACTIVE"
    QUIESCENT = "QUIESCENT"
    RETIRED = "RETIRED"


_ALLOWED_TRANSITIONS: dict[OphanLifecycle, tuple[OphanLifecycle, ...]] = {
    OphanLifecycle.TEMPLATE: (OphanLifecycle.INSTANTIATED,),
    OphanLifecycle.INSTANTIATED: (OphanLifecycle.CALIBRATED,),
    OphanLifecycle.CALIBRATED: (OphanLifecycle.ACTIVE,),
    OphanLifecycle.ACTIVE: (OphanLifecycle.QUIESCENT, OphanLifecycle.RETIRED),
    OphanLifecycle.QUIESCENT: (OphanLifecycle.ACTIVE, OphanLifecycle.RETIRED),
    OphanLifecycle.RETIRED: (),
}


@dataclass(frozen=True)
class OphanTemplate:
    gene_id: str
    genome_ref: str
    lineage_ref: str
    aperture: dict[str, Any]
    rotor_profile: dict[str, Any]
    projection_profile: dict[str, Any]
    operator_graph: tuple[dict[str, Any], ...]
    scheduler_features: dict[str, float]
    closure_contract: dict[str, Any]
    budgets: dict[str, Any]
    witness_contract: dict[str, Any]
    digest: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "gene_id": self.gene_id,
            "genome_ref": self.genome_ref,
            "lineage_ref": self.lineage_ref,
            "aperture": deepcopy(self.aperture),
            "rotor_profile": deepcopy(self.rotor_profile),
            "projection_profile": deepcopy(self.projection_profile),
            "operator_graph": [deepcopy(x) for x in self.operator_graph],
            "scheduler_features": deepcopy(self.scheduler_features),
            "closure_contract": deepcopy(self.closure_contract),
            "budgets": deepcopy(self.budgets),
            "witness_contract": deepcopy(self.witness_contract),
            "digest": self.digest,
        }


class OphanTemplateCompiler:
    def __init__(self, registry: OperatorRegistry):
        self.registry = registry

    def compile_gene(self, gene: dict[str, Any], *, genome_ref: str, lineage_ref: str | None = None) -> OphanTemplate:
        op_graph: list[dict[str, Any]] = []
        for idx, op_digest in enumerate(gene.get("operator_refs", [])):
            entry = self.registry.resolve_digest(op_digest)
            op_graph.append(
                {
                    "index": idx,
                    "operator_digest": op_digest,
                    "operator_id": entry.spec.operator_id,
                    "operator_version": entry.spec.version,
                    "domain": entry.spec.domain,
                    "codomain": entry.spec.codomain,
                }
            )
        payload = {
            "gene_id": gene["id"],
            "genome_ref": genome_ref,
            "lineage_ref": lineage_ref or genome_ref,
            "aperture": deepcopy(gene.get("aperture", {})),
            "rotor_profile": deepcopy(gene.get("rotor_profile", {})),
            "projection_profile": deepcopy(gene.get("projection_profile", {})),
            "operator_graph": op_graph,
            "scheduler_features": _coerce_features(gene.get("scheduler_features", {})),
            "closure_contract": deepcopy(gene.get("closure_contract", {})),
            "budgets": deepcopy(gene.get("budgets", {})),
            "witness_contract": {
                "requires": ["GenomeWitness", "CenterBindingWitness", "TraceWitness"],
                "emits": ["OphanTemplateWitness", "OphanWitness", "ExposureWitness"],
            },
        }
        digest = digest_record("GRFPS.OphanTemplate", "1.0.0", payload, (genome_ref,))
        return OphanTemplate(digest=digest, **payload)

    def compile_all(self, genome: dict[str, Any]) -> tuple[OphanTemplate, ...]:
        genome_ref = genome["digest"]
        lineage_ref = genome.get("lineage", [])[-1] if genome.get("lineage") else genome_ref
        templates = [
            self.compile_gene(g, genome_ref=genome_ref, lineage_ref=lineage_ref)
            for g in genome.get("ophan_templates", [])
        ]
        return tuple(sorted(templates, key=lambda x: (x.gene_id, x.digest)))


def _coerce_features(features: dict[str, Any]) -> dict[str, float]:
    keys = ("information_gain", "coverage_gain", "boundary_gain", "target_gain", "cost", "risk")
    return {k: float(features.get(k, 0.0)) for k in keys}


def _normalize_axis(axis: Iterable[float] | None) -> tuple[float, float, float]:
    vals = tuple(float(x) for x in (axis or (1.0, 0.0, 0.0)))
    if len(vals) != 3:
        raise ValueError("axis must have exactly 3 components")
    n2 = sum(x * x for x in vals)
    if n2 <= 0.0:
        return (1.0, 0.0, 0.0)
    n = n2 ** 0.5
    return tuple(x / n for x in vals)  # type: ignore[return-value]


def _default_orientation(axis: tuple[float, float, float], phase: float) -> dict[str, Any]:
    angle = tau * phase
    return {
        "axis": list(axis),
        "phase_angle": angle,
        "ring_tangent": [-sin(angle), cos(angle), 0.0],
    }


def instantiate_ophan(
    template: OphanTemplate,
    *,
    center_binding: str,
    context: dict[str, Any],
    instance_nonce: str = "0",
) -> dict[str, Any]:
    rotor = template.rotor_profile
    phase = float(rotor.get("phase_origin", 0.0))
    axis = _normalize_axis(context.get("axis"))
    payload = {
        "template_ref": template.digest,
        "gene_id": template.gene_id,
        "genome_ref": template.genome_ref,
        "lineage_ref": template.lineage_ref,
        "center_binding": center_binding,
        "context": deepcopy(context),
        "instance_nonce": instance_nonce,
        "lifecycle": OphanLifecycle.INSTANTIATED.value,
        "rotor_state": {
            "phase": phase,
            "cycle_index": 0,
            "period": float(rotor.get("period", 1.0)),
            "carrier": rotor.get("carrier", "S1"),
            "axis": list(axis),
            "orientation": _default_orientation(axis, phase),
        },
        "calibration": None,
        "evidence_refs": [],
        "residue_refs": [],
        "exposure_count": 0,
        "marginal_gain_history": [],
    }
    instance_id = digest_record("GRFPS.OphanInstanceId", "1.0.0", payload, (template.digest, center_binding))
    payload["id"] = instance_id
    payload["state_digest"] = digest_record("GRFPS.OphanState", "1.0.0", payload, (template.digest,))
    return payload


def transition_ophan(state: dict[str, Any], target: OphanLifecycle) -> dict[str, Any]:
    current = OphanLifecycle(state["lifecycle"])
    if target not in _ALLOWED_TRANSITIONS[current]:
        raise ValueError(f"invalid ophan lifecycle transition: {current.value}->{target.value}")
    out = deepcopy(state)
    out["lifecycle"] = target.value
    out["state_digest"] = digest_record("GRFPS.OphanState", "1.0.0", {k: v for k, v in out.items() if k != "state_digest"}, (state["state_digest"],))
    return out


def calibrate_ophan(state: dict[str, Any], template: OphanTemplate, calibration: dict[str, Any] | None = None) -> dict[str, Any]:
    if state["lifecycle"] != OphanLifecycle.INSTANTIATED.value:
        raise ValueError("ophan must be INSTANTIATED before calibration")
    out = deepcopy(state)
    cal = {
        "status": "CALIBRATED",
        "aperture": deepcopy(template.aperture),
        "projection_profile": deepcopy(template.projection_profile),
        "phase_tolerance": float((calibration or {}).get("phase_tolerance", 1e-9)),
        "orientation_tolerance": float((calibration or {}).get("orientation_tolerance", 1e-9)),
        "calibration_ref": digest_record(
            "GRFPS.OphanCalibration",
            "1.0.0",
            {"instance_ref": state["id"], "template_ref": template.digest, "calibration": calibration or {}},
            (state["state_digest"],),
        ),
    }
    out["calibration"] = cal
    return transition_ophan(out, OphanLifecycle.CALIBRATED)


def activate_ophan(state: dict[str, Any]) -> dict[str, Any]:
    current = OphanLifecycle(state["lifecycle"])
    if current not in (OphanLifecycle.CALIBRATED, OphanLifecycle.QUIESCENT):
        raise ValueError("ophan must be CALIBRATED or QUIESCENT before activation")
    return transition_ophan(state, OphanLifecycle.ACTIVE)


def quiesce_ophan(state: dict[str, Any]) -> dict[str, Any]:
    return transition_ophan(state, OphanLifecycle.QUIESCENT)


def retire_ophan(state: dict[str, Any]) -> dict[str, Any]:
    current = OphanLifecycle(state["lifecycle"])
    if current not in (OphanLifecycle.ACTIVE, OphanLifecycle.QUIESCENT):
        raise ValueError("ophan must be ACTIVE or QUIESCENT before retirement")
    return transition_ophan(state, OphanLifecycle.RETIRED)


def expose_ophan(
    state: dict[str, Any],
    template: OphanTemplate,
    *,
    world_payload: dict[str, Any],
    event_index: int,
    ledger: Ledger | None = None,
    phase_step: float = 0.25,
) -> tuple[dict[str, Any], dict[str, Any]]:
    if state["lifecycle"] != OphanLifecycle.ACTIVE.value:
        raise ValueError("only ACTIVE ophanim can expose")
    pre = state["state_digest"]
    out = deepcopy(state)
    rotor = out["rotor_state"]
    phase = float(rotor["phase"]) % 1.0
    axis = _normalize_axis(rotor.get("axis"))
    sector_count = int(template.aperture.get("sectors", 8) or 8)
    sector = int(phase * sector_count) % sector_count
    orientation = _default_orientation(axis, phase)
    projected = _project_payload(world_payload, template.projection_profile, phase, axis)
    exposure_payload = {
        "ophan_ref": out["id"],
        "template_ref": template.digest,
        "phase": phase,
        "axis": list(axis),
        "sector": sector,
        "sheet": int(rotor.get("cycle_index", 0)) % 2,
        "orientation": orientation,
        "payload": projected,
        "witnesses": ["OphanWitness", "ExposureWitness", "TraceWitness"],
        "event_index": event_index,
    }
    exposure = deepcopy(exposure_payload)
    exposure["digest"] = digest_record("GRFPS.ExposureState", "1.0.0", exposure_payload, (pre, template.digest))
    out["evidence_refs"] = list(out.get("evidence_refs", [])) + [exposure["digest"]]
    out["exposure_count"] = int(out.get("exposure_count", 0)) + 1
    next_phase = phase + phase_step
    cycle_inc = int(next_phase // 1.0)
    rotor["phase"] = next_phase % 1.0
    rotor["cycle_index"] = int(rotor.get("cycle_index", 0)) + cycle_inc
    rotor["orientation"] = _default_orientation(axis, rotor["phase"])
    out["state_digest"] = digest_record("GRFPS.OphanState", "1.0.0", {k: v for k, v in out.items() if k != "state_digest"}, (pre, exposure["digest"]))
    if ledger is not None:
        ledger.append(
            operator="ophan.expose",
            input_digest=exposure["digest"],
            pre_digest=pre,
            post_digest=out["state_digest"],
            witnesses=("OphanWitness", "ExposureWitness"),
            clocks={"event": event_index},
        )
    return out, exposure


def _project_payload(world_payload: dict[str, Any], projection_profile: dict[str, Any], phase: float, axis: tuple[float, float, float]) -> dict[str, Any]:
    numeric = world_payload.get("channels", {})
    if not isinstance(numeric, dict):
        numeric = {}
    channel_values = {k: float(v) for k, v in sorted(numeric.items()) if isinstance(v, (int, float))}
    # A deterministic harmonic projection. The world remains an adapter payload; the
    # runtime only exposes a phase-conditioned view of declared numeric channels.
    modulation = 0.5 + 0.5 * cos(tau * phase)
    weights = projection_profile.get("channel_weights", {})
    projected = {
        k: float(format(v * modulation * float(weights.get(k, 1.0)), ".17g"))
        for k, v in channel_values.items()
    }
    return {
        "projection_kind": projection_profile.get("kind", "canonical-projection"),
        "phase_modulation": float(format(modulation, ".17g")),
        "axis": list(axis),
        "channels": projected,
        "source_digest": digest_record("GRFPS.WorldPayload", "1.0.0", world_payload),
    }


class OphanBank:
    def __init__(self, *, max_active: int, max_total: int | None = None):
        if max_active <= 0:
            raise ValueError("max_active must be positive")
        self.max_active = max_active
        self.max_total = max_total if max_total is not None else max_active * 4
        self._states: dict[str, dict[str, Any]] = {}
        self._template_index: dict[str, list[str]] = {}
        self._history: list[dict[str, Any]] = []

    @property
    def states(self) -> tuple[dict[str, Any], ...]:
        return tuple(deepcopy(self._states[k]) for k in sorted(self._states))

    @property
    def active(self) -> tuple[dict[str, Any], ...]:
        return tuple(s for s in self.states if s["lifecycle"] == OphanLifecycle.ACTIVE.value)

    @property
    def history(self) -> tuple[dict[str, Any], ...]:
        return tuple(deepcopy(self._history))

    def add(self, state: dict[str, Any]) -> None:
        if len(self._states) >= self.max_total and state["id"] not in self._states:
            raise RuntimeError("ophan bank total budget exceeded")
        if state["lifecycle"] == OphanLifecycle.ACTIVE.value and state["id"] not in self._states and len(self.active) >= self.max_active:
            raise RuntimeError("ophan bank active budget exceeded")
        self._states[state["id"]] = deepcopy(state)
        self._template_index.setdefault(state["template_ref"], [])
        if state["id"] not in self._template_index[state["template_ref"]]:
            self._template_index[state["template_ref"]].append(state["id"])
            self._template_index[state["template_ref"]].sort()
        self._record("ADD", state["id"])

    def update(self, state: dict[str, Any]) -> None:
        if state["id"] not in self._states:
            raise KeyError(state["id"])
        old = self._states[state["id"]]
        if old["lifecycle"] != OphanLifecycle.ACTIVE.value and state["lifecycle"] == OphanLifecycle.ACTIVE.value:
            if len(self.active) >= self.max_active:
                raise RuntimeError("ophan bank active budget exceeded")
        self._states[state["id"]] = deepcopy(state)
        self._record("UPDATE", state["id"])

    def reusable(self, template: OphanTemplate, context: dict[str, Any]) -> dict[str, Any] | None:
        context_key = canonical_json(context)
        for oid in self._template_index.get(template.digest, []):
            state = self._states[oid]
            if canonical_json(state.get("context", {})) == context_key and state["lifecycle"] in {
                OphanLifecycle.ACTIVE.value,
                OphanLifecycle.QUIESCENT.value,
            }:
                return deepcopy(state)
        return None

    def spawn_or_reuse(
        self,
        template: OphanTemplate,
        *,
        center_binding: str,
        context: dict[str, Any],
        nonce: str,
    ) -> tuple[dict[str, Any], str]:
        reusable = self.reusable(template, context)
        if reusable is not None:
            if reusable["lifecycle"] == OphanLifecycle.QUIESCENT.value:
                reusable = activate_ophan(reusable)
                self.update(reusable)
            self._record("REUSE", reusable["id"])
            return reusable, "REUSE"
        if len(self.active) >= self.max_active:
            raise RuntimeError("ophan bank active budget exceeded")
        state = instantiate_ophan(template, center_binding=center_binding, context=context, instance_nonce=nonce)
        state = calibrate_ophan(state, template)
        state = activate_ophan(state)
        self.add(state)
        self._record("SPAWN", state["id"])
        return deepcopy(state), "SPAWN"

    def quiesce(self, ophan_id: str) -> dict[str, Any]:
        state = quiesce_ophan(self._states[ophan_id])
        self.update(state)
        return deepcopy(state)

    def retire(self, ophan_id: str) -> dict[str, Any]:
        state = retire_ophan(self._states[ophan_id])
        self.update(state)
        return deepcopy(state)

    def snapshot(self) -> dict[str, Any]:
        payload = {
            "max_active": self.max_active,
            "max_total": self.max_total,
            "states": list(self.states),
            "history": list(self.history),
        }
        payload["digest"] = digest_record("GRFPS.OphanBank", "1.0.0", payload)
        return payload

    def _record(self, event: str, ophan_id: str) -> None:
        payload = {"index": len(self._history), "event": event, "ophan_ref": ophan_id}
        payload["digest"] = digest_record("GRFPS.OphanBankEvent", "1.0.0", payload)
        self._history.append(payload)
