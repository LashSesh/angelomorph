from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, asdict
from typing import Any

from .canon import canonical_json, digest_record


@dataclass(frozen=True)
class SchedulerWeights:
    information_gain: float = 1.0
    coverage_gain: float = 1.0
    boundary_gain: float = 1.0
    target_gain: float = 1.0
    cost: float = 1.0
    risk: float = 1.0
    redundancy: float = 1.0


class PerceptualScheduler:
    def __init__(self, weights: SchedulerWeights | None = None):
        self.weights = weights or SchedulerWeights()

    def score(self, candidate: dict[str, Any]) -> float:
        w = self.weights
        f = candidate.get("features", {})
        score = (
            w.information_gain * float(f.get("information_gain", 0.0))
            + w.coverage_gain * float(f.get("coverage_gain", 0.0))
            + w.boundary_gain * float(f.get("boundary_gain", 0.0))
            + w.target_gain * float(f.get("target_gain", 0.0))
            - w.cost * float(f.get("cost", 0.0))
            - w.risk * float(f.get("risk", 0.0))
            - w.redundancy * float(f.get("redundancy", 0.0))
        )
        return float(format(score, ".17g"))

    def rank(self, candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
        ranked: list[dict[str, Any]] = []
        for c in candidates:
            item = deepcopy(c)
            item["score"] = self.score(item)
            tie_payload = {k: v for k, v in item.items() if k != "score"}
            item["tie_break_digest"] = digest_record("GRFPS.SchedulerCandidate", "1.0.0", tie_payload)
            ranked.append(item)
        ranked.sort(key=lambda x: (-x["score"], x["tie_break_digest"], canonical_json(x)))
        return ranked

    def select(
        self,
        candidates: list[dict[str, Any]],
        *,
        budget: dict[str, float] | None = None,
        limit: int = 1,
    ) -> dict[str, Any]:
        budget = deepcopy(budget or {})
        remaining_cost = float(budget.get("cost", float("inf")))
        remaining_risk = float(budget.get("risk", float("inf")))
        ranked = self.rank(candidates)
        selected: list[dict[str, Any]] = []
        held: list[dict[str, Any]] = []
        for item in ranked:
            f = item.get("features", {})
            cost = float(f.get("cost", 0.0))
            risk = float(f.get("risk", 0.0))
            if len(selected) >= limit or cost > remaining_cost or risk > remaining_risk:
                held.append(item)
                continue
            selected.append(item)
            remaining_cost -= cost
            remaining_risk -= risk
        payload = {
            "weights": asdict(self.weights),
            "ranked": ranked,
            "selected": selected,
            "held": held,
            "remaining_budget": {"cost": remaining_cost, "risk": remaining_risk},
            "limit": limit,
        }
        payload["digest"] = digest_record("GRFPS.SchedulerDecision", "1.0.0", payload)
        return payload


def candidate_from_template(
    template: dict[str, Any],
    *,
    action: str,
    redundancy: float = 0.0,
    context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    features = deepcopy(template.get("scheduler_features", {}))
    features.setdefault("cost", float(template.get("budgets", {}).get("cost", template.get("budgets", {}).get("steps", 0.0))))
    features.setdefault("risk", float(template.get("budgets", {}).get("risk", 0.0)))
    features["redundancy"] = float(redundancy)
    return {
        "candidate_id": digest_record(
            "GRFPS.OphanScheduleCandidate",
            "1.0.0",
            {"template_ref": template["digest"], "action": action, "context": context or {}},
            (template["digest"],),
        ),
        "template_ref": template["digest"],
        "action": action,
        "context": deepcopy(context or {}),
        "features": features,
    }
