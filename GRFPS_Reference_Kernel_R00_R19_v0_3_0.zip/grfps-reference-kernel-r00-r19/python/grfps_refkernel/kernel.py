from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import uuid

from .canon import digest_record
from .genome import GenomeCompiler
from .identity import IdentityLock
from .ledger import Ledger
from .operator import OperatorRegistry
from .synthworld import SyntheticWorldAdapter
from .types import PulseStatus


@dataclass
class ReferenceKernel:
    identity: IdentityLock
    registry: OperatorRegistry
    compiler: GenomeCompiler

    @classmethod
    def build(cls, identity: IdentityLock, genome_schema: dict[str, Any] | None = None) -> "ReferenceKernel":
        registry = OperatorRegistry.core_registry()
        return cls(identity=identity, registry=registry, compiler=GenomeCompiler(registry, genome_schema))

    def empty_run(
        self,
        *,
        genome: dict[str, Any],
        world: SyntheticWorldAdapter,
        run_id: str = "run-empty-reference-0001",
        seed: int = 0,
    ) -> dict[str, Any]:
        world_binding = world.bind()
        run_descriptor_payload = {
            "run_id": run_id,
            "version": self.identity.reference_kernel_version,
            "identity_digest": self.identity.digest,
            "domain": "synthetic-kernel",
            "models": ["GRFPS-v3"],
            "tolerances": {"canonical": "exact"},
            "budgets": {"kernel_steps": 16},
            "policies": {"mode": "empty-run"},
            "seeds": {"primary": seed},
            "clocks": {"event": 0, "epoch": 0, "lineage": 0},
            "adapters": [world_binding["adapter"]],
            "conformance": ["C00", "C01", "C02", "C15"],
        }
        run_descriptor = deepcopy(run_descriptor_payload)
        run_descriptor["digest"] = digest_record("GRFPS.RunDescriptor", "1.0.0", run_descriptor_payload, (self.identity.digest,))
        ledger = Ledger(run_descriptor["digest"])

        state = {
            "Binding": {"run_ref": run_descriptor["digest"], "world": world_binding},
            "CausalField": {},
            "PerceptualGenome": {},
            "OphanField": {},
            "SyntheticPercept": {},
            "InfogeneticMap": {},
            "ReflectionShell": {},
            "Gyrosphere": {},
            "Navigator": {},
            "EffectPort": {},
            "HumanView": {},
            "Ledger": {"trace_head": None},
            "status": PulseStatus.ADVANCE.value,
            "update_index": 0,
        }
        pre = digest_record("GRFPS.RuntimeState", "1.0.0", state)
        ledger.append(
            operator="constitution.bindRun",
            input_digest=run_descriptor["digest"],
            pre_digest=pre,
            post_digest=pre,
            witnesses=("IdentityWitness",),
            clocks={"event": 0},
        )

        canonical_genome, compiled = self.compiler.compile(genome)
        state["PerceptualGenome"] = {
            "genome_ref": canonical_genome["digest"],
            "compile_manifest_ref": compiled["manifest"]["digest"],
            "perceptual_program_ref": compiled["program"]["digest"],
        }
        state["update_index"] = 1
        post_compile = digest_record("GRFPS.RuntimeState", "1.0.0", state)
        ledger.append(
            operator="genome.sealGenome",
            input_digest=canonical_genome["digest"],
            pre_digest=pre,
            post_digest=post_compile,
            witnesses=("GenomeWitness",),
            clocks={"event": 1},
        )

        state["status"] = PulseStatus.STOP.value
        state["update_index"] = 2
        state["Ledger"]["trace_head"] = ledger.head
        pre_seal = digest_record("GRFPS.RuntimeState", "1.0.0", state)
        seal_payload = {
            "run_ref": run_descriptor["digest"],
            "state_digest": pre_seal,
            "identity_digest": self.identity.digest,
            "genome_ref": canonical_genome["digest"],
            "compile_manifest_ref": compiled["manifest"]["digest"],
            "registry_ref": self.registry.snapshot()["digest"],
            "status": PulseStatus.STOP.value,
        }
        seal_payload["digest"] = digest_record("GRFPS.SealedRun", "1.0.0", seal_payload, (ledger.head or "",))
        ledger.append(
            operator="constitution.seal",
            input_digest=seal_payload["digest"],
            pre_digest=pre_seal,
            post_digest=seal_payload["digest"],
            witnesses=("SealWitness",),
            clocks={"event": 2},
        )
        state["Ledger"]["trace_head"] = ledger.head
        checkpoint = ledger.checkpoint(state, 2)
        expected = {
            "identity": self.identity.digest,
            "genome": canonical_genome["digest"],
            "compile_manifest": compiled["manifest"]["digest"],
            "program": compiled["program"]["digest"],
            "sealed_run": seal_payload["digest"],
            "checkpoint": checkpoint["digest"],
            "trace_head": ledger.head or "",
        }
        replay_manifest = ledger.to_manifest(
            run_descriptor["digest"],
            input_sequence=[{"kind": "GenomePackage", "digest": canonical_genome["digest"]}],
            expected_digests=expected,
        )
        return {
            "identity_lock": self.identity.to_dict(),
            "run_descriptor": run_descriptor,
            "world_binding": world_binding,
            "registry": self.registry.snapshot(),
            "genome": canonical_genome,
            "compile_manifest": compiled["manifest"],
            "perceptual_program": compiled["program"],
            "runtime_state": state,
            "sealed_run": seal_payload,
            "trace": [s.to_dict() for s in ledger.segments],
            "checkpoints": list(ledger.checkpoints),
            "replay_manifest": replay_manifest,
            "chain_valid": ledger.verify_chain(),
        }

    def replay_empty_run(self, bundle: dict[str, Any], genome: dict[str, Any], world: SyntheticWorldAdapter) -> dict[str, Any]:
        run = bundle["run_descriptor"]
        replayed = self.empty_run(
            genome=genome,
            world=world,
            run_id=run["run_id"],
            seed=run["seeds"]["primary"],
        )
        keys = ("identity", "genome", "compile_manifest", "program", "sealed_run", "checkpoint", "trace_head")
        expected = bundle["replay_manifest"]["expected_digests"]
        actual = replayed["replay_manifest"]["expected_digests"]
        return {
            "equal": all(expected[k] == actual[k] for k in keys),
            "expected": expected,
            "actual": actual,
            "replayed_manifest": replayed["replay_manifest"],
        }
