from __future__ import annotations

from copy import deepcopy
from math import sqrt
from typing import Any

from .canon import digest_record


def _dot(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def _norm(a: list[float]) -> float:
    return sqrt(max(_dot(a, a), 0.0))


def cosine_similarity(a: list[float], b: list[float]) -> float:
    if len(a) != len(b):
        raise ValueError("vectors must have the same length")
    na, nb = _norm(a), _norm(b)
    if na == 0.0 and nb == 0.0:
        return 1.0
    if na == 0.0 or nb == 0.0:
        return 0.0
    return max(-1.0, min(1.0, _dot(a, b) / (na * nb)))


def matrix_rank(matrix: list[list[float]], tol: float = 1e-10) -> int:
    if not matrix:
        return 0
    ncols = len(matrix[0])
    if any(len(row) != ncols for row in matrix):
        raise ValueError("ragged matrix")
    a = [list(map(float, row)) for row in matrix]
    m, n = len(a), ncols
    rank = 0
    col = 0
    while rank < m and col < n:
        pivot = max(range(rank, m), key=lambda r: abs(a[r][col]))
        if abs(a[pivot][col]) <= tol:
            col += 1
            continue
        a[rank], a[pivot] = a[pivot], a[rank]
        pivot_val = a[rank][col]
        a[rank] = [x / pivot_val for x in a[rank]]
        for r in range(m):
            if r == rank:
                continue
            factor = a[r][col]
            if abs(factor) <= tol:
                continue
            a[r] = [x - factor * y for x, y in zip(a[r], a[rank])]
        rank += 1
        col += 1
    return rank


class DependencyQuotient:
    def __init__(self, similarity_threshold: float = 0.985, rank_tolerance: float = 1e-10):
        if not 0.0 <= similarity_threshold <= 1.0:
            raise ValueError("similarity_threshold must lie in [0,1]")
        self.similarity_threshold = similarity_threshold
        self.rank_tolerance = rank_tolerance

    def analyze(self, response_vectors: dict[str, list[float]]) -> dict[str, Any]:
        ids = sorted(response_vectors)
        vectors = {k: [float(x) for x in response_vectors[k]] for k in ids}
        if vectors:
            lengths = {len(v) for v in vectors.values()}
            if len(lengths) != 1:
                raise ValueError("all response vectors must have equal dimensionality")
        sim: dict[str, dict[str, float]] = {i: {} for i in ids}
        for i in ids:
            for j in ids:
                sim[i][j] = float(format(cosine_similarity(vectors[i], vectors[j]), ".17g"))
        clusters = self._clusters(ids, sim)
        representatives = [min(c) for c in clusters]
        effective_rank = matrix_rank([vectors[i] for i in ids], self.rank_tolerance)
        redundancy: dict[str, float] = {}
        adjusted_weight: dict[str, float] = {}
        for cluster in clusters:
            size = len(cluster)
            for member in cluster:
                if size == 1:
                    redundancy[member] = 0.0
                    adjusted_weight[member] = 1.0
                else:
                    other = [abs(sim[member][x]) for x in cluster if x != member]
                    redundancy[member] = float(format(sum(other) / len(other), ".17g"))
                    adjusted_weight[member] = float(format(1.0 / size, ".17g"))
        payload = {
            "items": ids,
            "similarity_threshold": self.similarity_threshold,
            "similarity": sim,
            "clusters": clusters,
            "representatives": representatives,
            "effective_rank": effective_rank,
            "redundancy": redundancy,
            "adjusted_weight": adjusted_weight,
            "residuals": [],
        }
        payload["digest"] = digest_record("GRFPS.DependencyProfile", "1.0.0", payload)
        return payload

    def _clusters(self, ids: list[str], sim: dict[str, dict[str, float]]) -> list[list[str]]:
        remaining = set(ids)
        clusters: list[list[str]] = []
        while remaining:
            seed = min(remaining)
            component = {seed}
            frontier = [seed]
            remaining.remove(seed)
            while frontier:
                node = frontier.pop()
                linked = sorted(
                    x for x in list(remaining)
                    if abs(sim[node][x]) >= self.similarity_threshold
                )
                for x in linked:
                    remaining.remove(x)
                    component.add(x)
                    frontier.append(x)
            clusters.append(sorted(component))
        return sorted(clusters, key=lambda c: c[0])

    def quotient_evidence(self, evidence: list[dict[str, Any]], vector_field: str = "vector") -> dict[str, Any]:
        vectors = {e["source_ref"]: list(e[vector_field]) for e in evidence}
        profile = self.analyze(vectors)
        retained = []
        for e in sorted(evidence, key=lambda x: x["source_ref"]):
            x = deepcopy(e)
            x["dependency_weight"] = profile["adjusted_weight"][e["source_ref"]]
            retained.append(x)
        return {"profile": profile, "evidence": retained}
