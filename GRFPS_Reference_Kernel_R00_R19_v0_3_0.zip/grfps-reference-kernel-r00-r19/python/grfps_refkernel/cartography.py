from __future__ import annotations
from copy import deepcopy
from typing import Any
from .canon import digest_record
from .graphmap import GraphWindowScanner, GraphResoniteBuilder, GraphInfogenome, GluingEngine, NerveComplexBuilder
from .mirror import MirrorEngine
from .reflection import ReflectionShell
from .horizon import PhaseHorizonEngine
from .ledger import Ledger


class CartographicRuntime:
    """Executable semantic reference for GRFPS R12-R19."""
    def __init__(self, *, radius: int=1, glue_threshold: float=1.0):
        self.scanner=GraphWindowScanner(radius)
        self.resonites=GraphResoniteBuilder()
        self.infogenome=GraphInfogenome()
        self.glue=GluingEngine(glue_threshold)
        self.nerve=NerveComplexBuilder()
        self.reflection=ReflectionShell(glue_threshold)
        self.horizon=PhaseHorizonEngine()

    @staticmethod
    def density(patches: list[dict[str,Any]], glue_certificate: dict[str,Any]) -> dict[str,float]:
        degree={p['patch_id']:0 for p in patches}
        for e in glue_certificate['overlap_graph']:
            if e['compatibility']>=1.0:
                degree[e['source']]+=1; degree[e['target']]+=1
        maxd=max(degree.values(),default=1) or 1
        return {k:(1.0+v)/(1.0+maxd) for k,v in degree.items()}

    def run(self, *, evidence_graph: dict[str,Any], origin: dict[str,Any], candidate_models: list[dict[str,Any]], mirror_constraints: list[dict[str,Any]], genome_ref: str, model_epoch: int=0, scale: str='meso', ledger: Ledger|None=None, event_index: int=0) -> dict[str,Any]:
        windows=self.scanner.decompose(evidence_graph,origin=origin,scale=scale)
        resonites=[self.resonites.emit(w) for w in windows]
        gi=self.infogenome.build(resonites)
        patches=[self.glue.patch(w,r,time_index=event_index) for w,r in zip(windows,resonites)]
        glued=self.glue.glue(patches,windows,resonites)
        nerve=self.nerve.build(glued['patches'],glued['certificate']['seams'])
        mirror_engine=MirrorEngine(candidate_models)
        mirror=mirror_engine.contract(mirror_constraints,model_epoch=model_epoch,genome_ref=genome_ref,nerve_ref=nerve['digest'])
        dens=self.density(patches,glued['certificate'])
        reflection=self.reflection.build(patches=patches,glue_certificate=glued['certificate'],density_by_patch=dens)
        hz=self.horizon.build(patches=patches,glue_certificate=glued['certificate'],reflection_state=reflection,mirror_state=mirror,scale=scale)
        stage_items=[
            ('infogenetic.decomposeWindow',digest_record('GRFPS.EvidenceGraph','1.0.0',evidence_graph),digest_record('GRFPS.GraphWindowSet','1.0.0',[x['digest'] for x in windows]),('GraphWitness',)),
            ('infogenetic.emitGraphResonite',digest_record('GRFPS.GraphWindowSet','1.0.0',[x['digest'] for x in windows]),digest_record('GRFPS.GraphResoniteSet','1.0.0',[x['digest'] for x in resonites]),('GraphWitness',)),
            ('infogenetic.updateGraphInfogenome',digest_record('GRFPS.GraphResoniteSet','1.0.0',[x['digest'] for x in resonites]),gi['digest'],('GraphWitness','ProvenanceWitness')),
            ('infogenetic.gluePatches',gi['digest'],glued['certificate']['digest'],('GlueWitness',)),
            ('infogenetic.buildNerve',glued['certificate']['digest'],nerve['digest'],('GlueWitness','NerveWitness')),
            ('mirror.updateMirror',nerve['digest'],mirror['digest'],('MirrorWitness',)),
            ('reflection.buildReflection',mirror['digest'],reflection['digest'],('BoundaryWitness','ReflectionWitness')),
            ('navigation.buildHorizon',reflection['digest'],hz['digest'],('HorizonWitness','AtlasWitness')),
        ]
        if ledger is not None:
            pre=ledger.head or stage_items[0][1]
            for idx,(op,inp,out,wits) in enumerate(stage_items):
                ledger.append(operator=op,input_digest=inp,pre_digest=pre,post_digest=out,witnesses=wits,clocks={'event':event_index+idx})
                pre=out
        payload={'graph_windows':windows,'graph_resonites':resonites,'graph_infogenome':gi,'patches':patches,'gluing_certificate':glued['certificate'],'glued_complex':glued['complex'],'nerve_state':nerve,'density_by_patch':dens,'mirror_state':mirror,'reflection_state':reflection,'horizon_state':hz['horizon'],'horizon_chart':hz['horizon_chart'],'atlas_state':hz['atlas']}
        payload['digest']=digest_record('GRFPS.CartographicCycle','1.0.0',payload)
        return payload
