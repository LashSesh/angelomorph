from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from typing import Any, Iterable


def _normalize(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _normalize(value[k]) for k in sorted(value)}
    if isinstance(value, list):
        return [_normalize(v) for v in value]
    if isinstance(value, tuple):
        return [_normalize(v) for v in value]
    if isinstance(value, float):
        if value == 0.0:
            return 0.0
        if value != value or value in (float("inf"), float("-inf")):
            raise ValueError("non-finite float in canonical payload")
        return float(format(value, ".17g"))
    return value


def canonical_json(value: Any) -> str:
    normalized = _normalize(value)
    return json.dumps(
        normalized,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def canonical_bytes(value: Any) -> bytes:
    return canonical_json(value).encode("utf-8")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def digest_record(
    record_type: str,
    version: str,
    payload: Any,
    parent_digests: Iterable[str] = (),
) -> str:
    envelope = {
        "type": record_type,
        "version": version,
        "payload": deepcopy(payload),
        "parents": sorted(parent_digests),
    }
    return sha256_hex(canonical_bytes(envelope))


def with_digest(record_type: str, version: str, payload: dict[str, Any], parents: Iterable[str] = ()) -> dict[str, Any]:
    out = deepcopy(payload)
    out["digest"] = digest_record(record_type, version, payload, parents)
    return out
