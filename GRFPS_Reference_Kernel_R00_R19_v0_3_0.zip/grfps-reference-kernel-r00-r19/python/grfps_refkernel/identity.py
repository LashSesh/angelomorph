from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib

from .canon import digest_record

RUNTIME_SURFACES = (
    "Binding",
    "CausalField",
    "PerceptualGenome",
    "OphanField",
    "SyntheticPercept",
    "InfogeneticMap",
    "ReflectionShell",
    "Gyrosphere",
    "Navigator",
    "EffectPort",
    "HumanView",
    "Ledger",
)
LINEAGE_SURFACE = "Lineage"
BOUNDARY_PORTS = (
    "Bind",
    "Observe",
    "Target",
    "Probe",
    "Propose",
    "Authorize",
    "Receipt",
    "View",
    "Replay",
    "LoadGenome",
    "Compile",
    "Sediment",
)


@dataclass(frozen=True)
class IdentityLock:
    grfps_version: str
    reference_kernel_version: str
    spec_pdf_sha256: str
    spec_tex_sha256: str
    runtime_surfaces: tuple[str, ...] = RUNTIME_SURFACES
    lineage_surface: str = LINEAGE_SURFACE
    boundary_ports: tuple[str, ...] = BOUNDARY_PORTS

    @property
    def surface_digest(self) -> str:
        return digest_record("GRFPS.IdentitySurface", self.grfps_version, {
            "runtime_surfaces": list(self.runtime_surfaces),
            "lineage_surface": self.lineage_surface,
            "boundary_ports": list(self.boundary_ports),
        })

    @property
    def digest(self) -> str:
        payload = asdict(self)
        payload["surface_digest"] = self.surface_digest
        return digest_record("GRFPS.IdentityLock", self.reference_kernel_version, payload)

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["runtime_surfaces"] = list(self.runtime_surfaces)
        payload["boundary_ports"] = list(self.boundary_ports)
        payload["surface_digest"] = self.surface_digest
        payload["digest"] = self.digest
        return payload


def file_sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()
