from __future__ import annotations

from dataclasses import dataclass, asdict
from enum import Enum
from typing import Any


class PulseStatus(str, Enum):
    ADVANCE = "ADVANCE"
    PROBE = "PROBE"
    HOLD = "HOLD"
    REANCHOR = "REANCHOR"
    REACQUIRE = "REACQUIRE"
    RESIDUALIZE = "RESIDUALIZE"
    ACT = "ACT"
    STOP = "STOP"
    FAIL = "FAIL"


class DeterminismClass(str, Enum):
    DETERMINISTIC = "DETERMINISTIC"
    SEEDED = "SEEDED"
    QUOTIENTED = "QUOTIENTED"


class Facticity(str, Enum):
    SPECIFIED = "Specified"
    POSSIBLE = "Possible"
    SIMULATED = "Simulated"
    SELECTED = "Selected"
    ATTEMPTED = "Attempted"
    OBSERVED = "Observed"
    ACTUALIZED = "Actualized"
    UNKNOWN = "Unknown"


@dataclass(frozen=True)
class OperatorSpec:
    operator_id: str
    version: str
    family: str
    domain: str
    codomain: str
    determinism: DeterminismClass
    capability_namespace: str
    preconditions: tuple[str, ...] = ()
    postconditions: tuple[str, ...] = ()
    witness_products: tuple[str, ...] = ()
    residue_classes: tuple[str, ...] = ()
    trace_fields: tuple[str, ...] = ()
    budget_class: str = "kernel"

    def payload(self) -> dict[str, Any]:
        d = asdict(self)
        d["determinism"] = self.determinism.value
        return d
