from __future__ import annotations
from copy import deepcopy
from typing import Any
from .canon import digest_record


class PhaseHorizonEngine:
    def build(self, *, patches: list[dict[str,Any]], glue_certificate: dict[str,Any], reflection_state: dict[str,Any], mirror_state: dict[str,Any], previous_atlas: dict[str,Any]|None=None, scale: str='meso') -> dict[str,Any]:
        region=set(reflection_state['region']['member_patches'])
        by_id={p['patch_id']:p for p in patches}
        current=[]; counter=[]; open_items=[]
        # Current: certified seams internal to the reflective region.
        for e in glue_certificate['overlap_graph']:
            item={'source':e['source'],'target':e['target'],'seam_ref':e['seam_ref'],'compatibility':e['compatibility']}
            if e['source'] in region and e['target'] in region and e['compatibility']>=1.0: current.append(item)
            elif e['compatibility']<1.0: counter.append({**item,'reason':'SEAM_ALTERNATIVE'})
        # Open: cut edges of region patches that point to evidence outside each local window.
        for pid in sorted(region):
            p=by_id[pid]
            # patch itself stores only member set; external openness is represented by absent neighboring members
            open_items.append({'patch_ref':pid,'direction':'boundary-expansion','scope':p['scale'],'origin':deepcopy(p['origin'])})
        for cid in mirror_state.get('alternative_candidates',[]):
            counter.append({'candidate_ref':cid,'reason':'MIRROR_COUNTERFACTUAL'})
        chart={'center':'center://run','scope':'reflection-region','scale':scale,'phase_rays':[{'kind':'current','ref':x.get('seam_ref')} for x in current],'projection_cones':[{'kind':'open','patch_ref':x['patch_ref']} for x in open_items],'reachability':{'current_count':len(current),'counterfactual_count':len(counter),'open_count':len(open_items)},'boundary':reflection_state['boundary_ref'],'assumptions':['canonical-local-evidence','sealed-glue'],'trace':[]}
        chart['digest']=digest_record('GRFPS.HorizonChart','1.0.0',chart)
        horizon={'current':sorted(current,key=lambda x:(x['source'],x['target'])),'counterfactual':sorted(counter,key=lambda x:str(x)),'open':open_items,'assumptions':chart['assumptions'],'reachability':chart['reachability'],'validity':'SEALED','chart_ref':chart['digest']}
        horizon['digest']=digest_record('GRFPS.HorizonState','1.0.0',horizon,(reflection_state['digest'],mirror_state['digest']))
        charts=[{'patch_ref':p['patch_id'],'scale':p['scale'],'members':p['members'],'digest':p['digest']} for p in sorted(patches,key=lambda x:x['patch_id'])]
        transitions=[{'source':e['source'],'target':e['target'],'seam_ref':e['seam_ref']} for e in sorted(glue_certificate['overlap_graph'],key=lambda x:(x['source'],x['target'])) if e['compatibility']>=1.0]
        lineage=[] if previous_atlas is None else [previous_atlas['digest']]
        atlas={'charts':charts,'transitions':transitions,'seams':[x['seam_ref'] for x in transitions],'holonomies':[],'worldline':[reflection_state['region_ref']],'compression':{'chart_count':len(charts),'transition_count':len(transitions),'region_fraction':len(region)/max(1,len(charts))},'lineage':lineage,'horizon_ref':horizon['digest']}
        atlas['digest']=digest_record('GRFPS.AtlasState','1.0.0',atlas,lineage)
        return {'horizon':horizon,'horizon_chart':chart,'atlas':atlas,'digest':digest_record('GRFPS.HorizonAtlasBundle','1.0.0',{'horizon':horizon['digest'],'atlas':atlas['digest']})}
