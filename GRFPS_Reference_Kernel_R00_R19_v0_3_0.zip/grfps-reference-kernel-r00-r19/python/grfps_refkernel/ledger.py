from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any

from .canon import digest_record


@dataclass(frozen=True)
class TraceSegment:
    run_ref: str
    parent_digest: str | None
    input_digest: str
    operator: str
    pre_digest: str
    post_digest: str
    witnesses: tuple[str, ...]
    residues: tuple[str, ...]
    clocks: dict[str, Any]
    determinism: str
    digest: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_ref": self.run_ref,
            "parent_digest": self.parent_digest,
            "input_digest": self.input_digest,
            "operator": self.operator,
            "pre_digest": self.pre_digest,
            "post_digest": self.post_digest,
            "witnesses": list(self.witnesses),
            "residues": list(self.residues),
            "clocks": deepcopy(self.clocks),
            "determinism": self.determinism,
            "digest": self.digest,
        }


class Ledger:
    def __init__(self, run_ref: str):
        self.run_ref = run_ref
        self._segments: list[TraceSegment] = []
        self._checkpoints: list[dict[str, Any]] = []

    @property
    def head(self) -> str | None:
        return self._segments[-1].digest if self._segments else None

    @property
    def segments(self) -> tuple[TraceSegment, ...]:
        return tuple(self._segments)

    @property
    def checkpoints(self) -> tuple[dict[str, Any], ...]:
        return tuple(deepcopy(self._checkpoints))

    def append(
        self,
        *,
        operator: str,
        input_digest: str,
        pre_digest: str,
        post_digest: str,
        witnesses: tuple[str, ...] = (),
        residues: tuple[str, ...] = (),
        clocks: dict[str, Any] | None = None,
        determinism: str = "DETERMINISTIC",
    ) -> TraceSegment:
        payload = {
            "run_ref": self.run_ref,
            "parent_digest": self.head,
            "input_digest": input_digest,
            "operator": operator,
            "pre_digest": pre_digest,
            "post_digest": post_digest,
            "witnesses": list(witnesses),
            "residues": list(residues),
            "clocks": deepcopy(clocks or {}),
            "determinism": determinism,
        }
        digest = digest_record(
            "GRFPS.TraceSegment",
            "1.0.0",
            payload,
            (() if self.head is None else (self.head,)),
        )
        segment = TraceSegment(digest=digest, **payload)
        self._segments.append(segment)
        return segment

    def checkpoint(self, state_payload: dict[str, Any], update_index: int) -> dict[str, Any]:
        payload = {
            "run_ref": self.run_ref,
            "update_index": update_index,
            "trace_head": self.head,
            "state_digest": digest_record("GRFPS.RuntimeState", "1.0.0", state_payload),
        }
        payload["digest"] = digest_record(
            "GRFPS.Checkpoint",
            "1.0.0",
            payload,
            (() if self.head is None else (self.head,)),
        )
        self._checkpoints.append(deepcopy(payload))
        return payload

    def verify_chain(self) -> bool:
        parent: str | None = None
        for segment in self._segments:
            if segment.parent_digest != parent:
                return False
            payload = segment.to_dict()
            digest = payload.pop("digest")
            expected = digest_record(
                "GRFPS.TraceSegment",
                "1.0.0",
                payload,
                (() if parent is None else (parent,)),
            )
            if digest != expected:
                return False
            parent = digest
        return True

    def to_manifest(self, run_descriptor_ref: str, input_sequence: list[dict[str, Any]], expected_digests: dict[str, str]) -> dict[str, Any]:
        payload = {
            "run_descriptor_ref": run_descriptor_ref,
            "input_sequence": deepcopy(input_sequence),
            "checkpoints": list(self.checkpoints),
            "trace_head": self.head,
            "expected_digests": deepcopy(expected_digests),
            "tolerance_profile": "exact-canonical-v1",
            "result": "SEALED",
        }
        payload["digest"] = digest_record("GRFPS.ReplayManifest", "1.0.0", payload)
        return payload
