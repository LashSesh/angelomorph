from __future__ import annotations

from copy import deepcopy
from typing import Any

from .canon import digest_record
from .coherence import CoherenceGraph
from .dependency import DependencyQuotient
from .ledger import Ledger
from .ophan import OphanBank, OphanTemplateCompiler, expose_ophan
from .scheduler import PerceptualScheduler, SchedulerWeights, candidate_from_template


class AdaptiveOphanField:
    """Executable semantic reference for GRFPS R06-R11."""

    def __init__(
        self,
        *,
        registry,
        genome: dict[str, Any],
        center_binding: str,
        max_active: int | None = None,
        scheduler_weights: SchedulerWeights | None = None,
        dependency_threshold: float = 0.985,
    ):
        self.registry = registry
        self.genome = deepcopy(genome)
        self.center_binding = center_binding
        self.templates = OphanTemplateCompiler(registry).compile_all(genome)
        active_budget = int(max_active or genome.get("budgets", {}).get("active_ophanim", max(1, len(self.templates))))
        self.bank = OphanBank(max_active=active_budget)
        self.graph = CoherenceGraph()
        self.dependency = DependencyQuotient(similarity_threshold=dependency_threshold)
        self.scheduler = PerceptualScheduler(scheduler_weights)
        self.event_index = 0

    def template_records(self) -> list[dict[str, Any]]:
        return [t.to_dict() for t in self.templates]

    def initial_spawn(self, contexts: list[dict[str, Any]] | None = None, ledger: Ledger | None = None) -> list[dict[str, Any]]:
        contexts = contexts or [{} for _ in self.templates]
        if len(contexts) < len(self.templates):
            contexts = contexts + [{} for _ in range(len(self.templates) - len(contexts))]
        states = []
        for idx, (template, context) in enumerate(zip(self.templates, contexts)):
            if len(self.bank.active) >= self.bank.max_active:
                break
            pre_bank = self.bank.snapshot()["digest"]
            if ledger is not None:
                ledger.append(
                    operator="ophan.compileOphan",
                    input_digest=self.genome["digest"],
                    pre_digest=self.genome["digest"],
                    post_digest=template.digest,
                    witnesses=("OphanTemplateWitness",),
                    clocks={"event": self.event_index},
                )
                self.event_index += 1
            state, mode = self.bank.spawn_or_reuse(
                template,
                center_binding=self.center_binding,
                context=context,
                nonce=f"initial-{idx}",
            )
            states.append(state)
            if ledger is not None:
                ledger.append(
                    operator="ophan.spawnOphan" if mode == "SPAWN" else "ophan.activateOphan",
                    input_digest=template.digest,
                    pre_digest=pre_bank,
                    post_digest=self.bank.snapshot()["digest"],
                    witnesses=("OphanWitness", "BudgetWitness"),
                    clocks={"event": self.event_index},
                )
                self.event_index += 1
        return states

    def expose_all(self, world_payload: dict[str, Any], ledger: Ledger | None = None) -> list[dict[str, Any]]:
        exposures: list[dict[str, Any]] = []
        template_by_ref = {t.digest: t for t in self.templates}
        for state in self.bank.active:
            template = template_by_ref[state["template_ref"]]
            updated, exposure = expose_ophan(
                state,
                template,
                world_payload=world_payload,
                event_index=self.event_index,
                ledger=ledger,
            )
            self.bank.update(updated)
            exposures.append(exposure)
            self.event_index += 1
        return exposures

    @staticmethod
    def response_vectors(exposures: list[dict[str, Any]]) -> dict[str, list[float]]:
        out: dict[str, list[float]] = {}
        for e in exposures:
            channels = e["payload"].get("channels", {})
            vector = [float(channels[k]) for k in sorted(channels)]
            vector.append(float(e["payload"].get("phase_modulation", 0.0)))
            out[e["ophan_ref"]] = vector
        return out

    def update_graph(self, exposures: list[dict[str, Any]], ledger: Ledger | None = None) -> dict[str, Any]:
        vectors = self.response_vectors(exposures)
        by_id = {s["id"]: s for s in self.bank.states}
        for ophan_id, vector in vectors.items():
            self.graph.upsert_node(by_id[ophan_id], response_vector=vector)
        pre_graph = digest_record("GRFPS.CoherenceGraph", "1.0.0", {"nodes": [], "edges": [], "history": []})
        profile = self.graph.auto_connect(dependency=self.dependency)
        graph_snapshot = self.graph.snapshot()
        if ledger is not None:
            exposure_digest = digest_record("GRFPS.ExposureSet", "1.0.0", [e["digest"] for e in exposures])
            ledger.append(operator="coherence.buildOperatorGraph", input_digest=exposure_digest, pre_digest=pre_graph, post_digest=graph_snapshot["digest"], witnesses=("CoherenceWitness",), clocks={"event": self.event_index})
            self.event_index += 1
            ledger.append(operator="coherence.updateCoherence", input_digest=graph_snapshot["digest"], pre_digest=graph_snapshot["digest"], post_digest=graph_snapshot["digest"], witnesses=("CoherenceWitness",), clocks={"event": self.event_index})
            self.event_index += 1
            ledger.append(operator="coherence.quotientDependencies", input_digest=graph_snapshot["digest"], pre_digest=graph_snapshot["digest"], post_digest=profile["digest"], witnesses=("DependencyWitness",), clocks={"event": self.event_index})
            self.event_index += 1
        return {"graph": graph_snapshot, "dependency": profile}

    def schedule(self, dependency_profile: dict[str, Any], *, budget: dict[str, float] | None = None, limit: int = 1, ledger: Ledger | None = None) -> dict[str, Any]:
        templates = self.template_records()
        candidates: list[dict[str, Any]] = []
        mean_redundancy = 0.0
        if dependency_profile.get("redundancy"):
            vals = list(dependency_profile["redundancy"].values())
            mean_redundancy = sum(vals) / len(vals)
        for template in templates:
            candidates.append(candidate_from_template(template, action="REUSE_OR_SPAWN", redundancy=mean_redundancy))
        decision = self.scheduler.select(candidates, budget=budget, limit=limit)
        if ledger is not None:
            candidates_digest = digest_record("GRFPS.SchedulerCandidateSet", "1.0.0", candidates, (dependency_profile["digest"],))
            ranked_digest = digest_record("GRFPS.ScoredCandidateSet", "1.0.0", decision["ranked"], (candidates_digest,))
            ledger.append(operator="coherence.scoreCandidate", input_digest=candidates_digest, pre_digest=dependency_profile["digest"], post_digest=ranked_digest, witnesses=("SchedulerWitness",), clocks={"event": self.event_index})
            self.event_index += 1
            ledger.append(operator="coherence.allocateBudget", input_digest=ranked_digest, pre_digest=ranked_digest, post_digest=decision["digest"], witnesses=("BudgetWitness", "SchedulerWitness"), clocks={"event": self.event_index})
            self.event_index += 1
        return decision

    def run_cycle(
        self,
        *,
        world_payload: dict[str, Any],
        ledger: Ledger | None = None,
        budget: dict[str, float] | None = None,
    ) -> dict[str, Any]:
        if not self.bank.active:
            self.initial_spawn(ledger=ledger)
        exposures = self.expose_all(world_payload, ledger=ledger)
        graph_update = self.update_graph(exposures, ledger=ledger)
        schedule = self.schedule(graph_update["dependency"], budget=budget, limit=max(1, min(1, self.bank.max_active)), ledger=ledger)
        payload = {
            "templates": self.template_records(),
            "bank": self.bank.snapshot(),
            "exposures": exposures,
            "coherence_graph": graph_update["graph"],
            "dependency_profile": graph_update["dependency"],
            "scheduler_decision": schedule,
        }
        payload["digest"] = digest_record("GRFPS.AdaptiveOphanFieldCycle", "1.0.0", payload)
        return payload
