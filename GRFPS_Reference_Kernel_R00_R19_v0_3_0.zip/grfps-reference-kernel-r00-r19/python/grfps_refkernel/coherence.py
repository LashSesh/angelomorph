from __future__ import annotations

from copy import deepcopy
from math import cos, pi
from typing import Any

from .canon import digest_record
from .dependency import DependencyQuotient


class CoherenceGraph:
    def __init__(self):
        self._nodes: dict[str, dict[str, Any]] = {}
        self._edges: dict[tuple[str, str, str], dict[str, Any]] = {}
        self._history: list[dict[str, Any]] = []

    @property
    def nodes(self) -> tuple[dict[str, Any], ...]:
        return tuple(deepcopy(self._nodes[k]) for k in sorted(self._nodes))

    @property
    def edges(self) -> tuple[dict[str, Any], ...]:
        return tuple(deepcopy(self._edges[k]) for k in sorted(self._edges))

    @property
    def history(self) -> tuple[dict[str, Any], ...]:
        return tuple(deepcopy(self._history))

    def upsert_node(
        self,
        ophan_state: dict[str, Any],
        *,
        response_vector: list[float],
        confidence: float = 1.0,
        resource_state: dict[str, Any] | None = None,
        stability_vector: dict[str, float] | None = None,
    ) -> dict[str, Any]:
        node_payload = {
            "operator_ref": ophan_state["id"],
            "template_ref": ophan_state["template_ref"],
            "local_state": ophan_state["lifecycle"],
            "phase": float(ophan_state["rotor_state"]["phase"]),
            "response_vector": [float(x) for x in response_vector],
            "confidence": float(confidence),
            "coherence": 0.0,
            "stability_vector": deepcopy(stability_vector or {
                "local": 1.0,
                "seam": 0.0,
                "scale": 1.0,
                "history": 1.0,
                "target": 0.0,
            }),
            "resource_state": deepcopy(resource_state or {}),
            "state_digest": ophan_state["state_digest"],
        }
        node = deepcopy(node_payload)
        node["digest"] = digest_record("GRFPS.CoherenceNode", "1.0.0", node_payload, (ophan_state["state_digest"],))
        self._nodes[ophan_state["id"]] = node
        self._record("NODE_UPSERT", node["digest"])
        return deepcopy(node)

    def connect(
        self,
        source: str,
        target: str,
        *,
        relation_type: str = "response-compatibility",
        weight: float = 1.0,
        dependency: float | None = None,
        seam_ref: str | None = None,
    ) -> dict[str, Any]:
        if source not in self._nodes or target not in self._nodes:
            raise KeyError("source and target must exist")
        if source == target:
            raise ValueError("coherence edge requires distinct nodes")
        a, b = sorted((source, target))
        payload = {
            "source": a,
            "target": b,
            "weight": float(weight),
            "relation_type": relation_type,
            "dependency": dependency,
            "seam_ref": seam_ref,
        }
        edge = deepcopy(payload)
        edge["digest"] = digest_record("GRFPS.CoherenceEdge", "1.0.0", payload, (self._nodes[a]["digest"], self._nodes[b]["digest"]))
        self._edges[(a, b, relation_type)] = edge
        self._record("EDGE_UPSERT", edge["digest"])
        return deepcopy(edge)

    def auto_connect(self, *, dependency: DependencyQuotient | None = None, min_weight: float = 0.0) -> dict[str, Any]:
        ids = sorted(self._nodes)
        dq = dependency or DependencyQuotient()
        vectors = {i: self._nodes[i]["response_vector"] for i in ids}
        profile = dq.analyze(vectors)
        for x, source in enumerate(ids):
            for target in ids[x + 1:]:
                dep = abs(profile["similarity"][source][target])
                # Compatibility combines response similarity and cyclic phase alignment.
                phase_delta = abs(float(self._nodes[source]["phase"]) - float(self._nodes[target]["phase"])) % 1.0
                phase_alignment = 0.5 + 0.5 * cos(2.0 * pi * phase_delta)
                weight = max(0.0, min(1.0, dep * phase_alignment))
                if weight >= min_weight:
                    self.connect(source, target, weight=weight, dependency=dep)
        self.update_coherence()
        return profile

    def update_coherence(self) -> dict[str, float]:
        values: dict[str, float] = {}
        for node_id in sorted(self._nodes):
            incident = [e for e in self._edges.values() if node_id in (e["source"], e["target"])]
            if not incident:
                value = 0.0
            else:
                value = sum(float(e["weight"]) for e in incident) / len(incident)
            value = float(format(value, ".17g"))
            self._nodes[node_id]["coherence"] = value
            values[node_id] = value
        field = float(format(sum(values.values()) / len(values), ".17g")) if values else 0.0
        self._record("COHERENCE_UPDATE", digest_record("GRFPS.CoherenceField", "1.0.0", {"nodes": values, "field": field}))
        return {**values, "__field__": field}

    def snapshot(self) -> dict[str, Any]:
        payload = {
            "nodes": list(self.nodes),
            "edges": list(self.edges),
            "history": list(self.history),
        }
        payload["digest"] = digest_record("GRFPS.CoherenceGraph", "1.0.0", payload)
        return payload

    def _record(self, event: str, subject: str) -> None:
        payload = {"index": len(self._history), "event": event, "subject": subject}
        payload["digest"] = digest_record("GRFPS.CoherenceGraphEvent", "1.0.0", payload)
        self._history.append(payload)
