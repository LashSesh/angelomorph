from __future__ import annotations
from collections import deque
from copy import deepcopy
from typing import Any
from .canon import digest_record


class ReflectionShell:
    def __init__(self, compatibility_threshold: float=1.0): self.compatibility_threshold=compatibility_threshold

    @staticmethod
    def _largest_connected(vertices: list[str], edges: list[dict[str,Any]]) -> list[str]:
        adj={v:set() for v in vertices}
        for e in edges:
            if e.get('compatibility',0.0)>=1.0:
                adj[e['source']].add(e['target']); adj[e['target']].add(e['source'])
        seen=set(); comps=[]
        for v in sorted(vertices):
            if v in seen: continue
            q=deque([v]); seen.add(v); c=[]
            while q:
                x=q.popleft(); c.append(x)
                for y in sorted(adj[x]):
                    if y not in seen: seen.add(y); q.append(y)
            comps.append(sorted(c))
        return max(comps,key=lambda c:(len(c),tuple(c))) if comps else []

    def build(self, *, patches: list[dict[str,Any]], glue_certificate: dict[str,Any], density_by_patch: dict[str,float]|None=None, previous_region: dict[str,Any]|None=None) -> dict[str,Any]:
        density_by_patch=density_by_patch or {p['patch_id']:1.0 for p in patches}
        vertices=[p['patch_id'] for p in patches]
        region=self._largest_connected(vertices,glue_certificate['overlap_graph'])
        outside=sorted(set(vertices)-set(region)); order=sorted(vertices)
        r_diag=[1 if v in region else -1 for v in order]
        plus=[1 if x==1 else 0 for x in r_diag]; minus=[1 if x==-1 else 0 for x in r_diag]
        boundary=[]
        for e in glue_certificate['overlap_graph']:
            a,b=e['source'],e['target']
            if (a in region) ^ (b in region): boundary.append(deepcopy(e))
        measure=len(region); density=sum(density_by_patch.get(x,0.0) for x in region)/max(1,len(region))
        lineage=[] if previous_region is None else [previous_region['digest']]
        reg={'region_id':digest_record('GRFPS.ReflectionRegionId','1.0.0',{'members':region,'lineage':lineage}),'member_patches':region,'closure_witnesses':['GlueWitness','ReplayWitness','PathWitness','ReflectionWitness'],'measure':measure,'density':density,'lineage':lineage,'open_patches':outside}
        reg['digest']=digest_record('GRFPS.BoundaryRegion','1.0.0',reg,lineage)
        bnd={'region_ref':reg['digest'],'boundary_edges':boundary,'open_patches':outside,'renewed_from':previous_region['digest'] if previous_region else None,'status':'SEALED'}
        bnd['digest']=digest_record('GRFPS.BoundaryState','1.0.0',bnd,(reg['digest'],))
        state={'reflection_operator':{'basis':order,'diagonal':r_diag,'self_adjoint':True,'involutive':True},'plus_projector':{'diagonal':plus},'minus_projector':{'diagonal':minus},'region_ref':reg['digest'],'boundary_ref':bnd['digest'],'witness_refs':['R*=R','R^2=I','Bplus+Bminus=I','BplusBminus=0'],'region':reg,'boundary':bnd}
        state['digest']=digest_record('GRFPS.ReflectionState','1.0.0',state,(reg['digest'],bnd['digest']))
        return state
