from __future__ import annotations

from collections import deque
from copy import deepcopy
from itertools import combinations, permutations
from math import isclose
from typing import Any

from .canon import digest_record


def _node_map(graph: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(n['id']): deepcopy(n) for n in graph.get('nodes', [])}


def _edges(graph: dict[str, Any]) -> list[tuple[str, str, str]]:
    out=[]
    for e in graph.get('edges', []):
        a,b=str(e['source']),str(e['target'])
        if a>b: a,b=b,a
        out.append((a,b,str(e.get('type','edge'))))
    return sorted(set(out))


def _adj(nodes: list[str], edges: list[tuple[str,str,str]]) -> dict[str,set[str]]:
    a={n:set() for n in nodes}
    for u,v,_ in edges:
        if u in a and v in a:
            a[u].add(v); a[v].add(u)
    return a


def _connected_components(nodes: list[str], edges: list[tuple[str,str,str]]) -> list[list[str]]:
    a=_adj(nodes,edges); seen=set(); comps=[]
    for n in sorted(nodes):
        if n in seen: continue
        q=[n]; seen.add(n); comp=[]
        while q:
            x=q.pop(); comp.append(x)
            for y in sorted(a[x]):
                if y not in seen: seen.add(y); q.append(y)
        comps.append(sorted(comp))
    return comps


def _bipartite(nodes: list[str], edges: list[tuple[str,str,str]]) -> bool:
    a=_adj(nodes,edges); color={}
    for start in sorted(nodes):
        if start in color: continue
        color[start]=0; q=deque([start])
        while q:
            u=q.popleft()
            for v in a[u]:
                if v not in color: color[v]=1-color[u]; q.append(v)
                elif color[v]==color[u]: return False
    return True


def _trace_powers(nodes: list[str], edges: list[tuple[str,str,str]], powers=(2,3,4)) -> list[int]:
    n=len(nodes); idx={v:i for i,v in enumerate(nodes)}
    A=[[0]*n for _ in range(n)]
    for u,v,_ in edges:
        if u in idx and v in idx:
            i,j=idx[u],idx[v]; A[i][j]=A[j][i]=1
    def mul(X,Y):
        return [[sum(X[i][k]*Y[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
    cur=[row[:] for row in A]; ans=[]
    for p in range(1,max(powers)+1):
        if p in powers: ans.append(sum(cur[i][i] for i in range(n)))
        cur=mul(cur,A)
    return ans


def _charpoly_coeffs(nodes: list[str], edges: list[tuple[str,str,str]]) -> list[int]:
    # Faddeev-LeVerrier, exact integer arithmetic for an undirected 0/1 adjacency matrix.
    n=len(nodes); idx={v:i for i,v in enumerate(nodes)}
    A=[[0]*n for _ in range(n)]
    for u,v,_ in edges:
        if u in idx and v in idx:
            i,j=idx[u],idx[v]; A[i][j]=A[j][i]=1
    I=[[1 if i==j else 0 for j in range(n)] for i in range(n)]
    def mul(X,Y): return [[sum(X[i][k]*Y[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
    B=[row[:] for row in I]; coeff=[]
    for k in range(1,n+1):
        AB=mul(A,B); tr=sum(AB[i][i] for i in range(n)); c=-(tr//k)
        coeff.append(int(c)); B=[[AB[i][j] + (c if i==j else 0) for j in range(n)] for i in range(n)]
    return [1,*coeff]


def canonical_graph(graph: dict[str, Any], brute_force_limit: int=8) -> dict[str, Any]:
    nm=_node_map(graph); nodes=sorted(nm); edges=_edges(graph)
    n=len(nodes)
    labels={k:str(nm[k].get('label',nm[k].get('type','node'))) for k in nodes}
    if n > brute_force_limit:
        order=sorted(nodes,key=lambda x:(labels[x],x))
        perms=[tuple(order)]
    else:
        # Permute only within equal-label blocks to keep typed identities conservative.
        blocks=[]
        for label in sorted(set(labels.values())):
            blocks.append([x for x in nodes if labels[x]==label])
        perblock=[list(permutations(b)) for b in blocks]
        perms=[()]
        for pb in perblock:
            perms=[a+b for a in perms for b in pb]
    edge_set={(u,v,t) for u,v,t in edges}
    best=None; best_payload=None; autos=0
    source_signature=None
    for perm in perms:
        pos={old:i for i,old in enumerate(perm)}
        mapped=[]
        for u,v,t in edges:
            a,b=sorted((pos[u],pos[v])); mapped.append((a,b,t))
        payload=(tuple(labels[x] for x in perm),tuple(sorted(mapped)))
        if source_signature is None:
            source_signature=payload
        if best is None or payload<best:
            best=payload; best_payload=payload
    # Automorphism count: relabelings with same canonical encoding as the identity encoding after label sort.
    canonical=best_payload
    for perm in perms:
        pos={old:i for i,old in enumerate(perm)}
        mapped=[]
        for u,v,t in edges:
            a,b=sorted((pos[u],pos[v])); mapped.append((a,b,t))
        payload=(tuple(labels[x] for x in perm),tuple(sorted(mapped)))
        if payload==canonical: autos+=1
    out={
        'n':n,
        'labels':list(canonical[0]) if canonical else [],
        'edges':[{'source':a,'target':b,'type':t} for a,b,t in (canonical[1] if canonical else ())],
        'stabilizer_size':autos,
        'orbit_size': max(1, len(perms)//max(1,autos)),
    }
    out['digest']=digest_record('GRFPS.CanonicalGraph','1.0.0',{k:v for k,v in out.items() if k!='digest'})
    return out


class GraphWindowScanner:
    def __init__(self, radius: int=1):
        if radius < 0: raise ValueError('radius must be nonnegative')
        self.radius=radius

    def decompose(self, graph: dict[str, Any], *, origin: dict[str,Any], scale: str='meso') -> list[dict[str,Any]]:
        nm=_node_map(graph); edges=_edges(graph); a=_adj(sorted(nm),edges)
        windows=[]; seen=set()
        for seed in sorted(nm):
            dist={seed:0}; q=deque([seed])
            while q:
                u=q.popleft()
                if dist[u]>=self.radius: continue
                for v in sorted(a[u]):
                    if v not in dist: dist[v]=dist[u]+1; q.append(v)
            members=tuple(sorted(dist))
            if members in seen: continue
            seen.add(members)
            internal=[e for e in edges if e[0] in members and e[1] in members]
            cut=[e for e in edges if (e[0] in members) ^ (e[1] in members)]
            sub={'nodes':[nm[x] for x in members], 'edges':[{'source':u,'target':v,'type':t} for u,v,t in internal]}
            can=canonical_graph(sub)
            payload={
                'origin':deepcopy(origin), 'scale':scale, 'seed':seed,
                'members':list(members), 'canonical_graph':can,
                'boundary':{'cut_edges':[{'source':u,'target':v,'type':t} for u,v,t in cut], 'boundary_nodes':sorted({u if u in members else v for u,v,_ in cut})},
            }
            payload['window_id']=digest_record('GRFPS.GraphWindowId','1.0.0',payload)
            payload['digest']=digest_record('GRFPS.GraphWindowRecord','1.0.0',payload)
            windows.append(payload)
        return sorted(windows,key=lambda x:x['window_id'])


class GraphResoniteBuilder:
    def fingerprint(self, window: dict[str,Any]) -> dict[str,Any]:
        can=window['canonical_graph']; nodes=[str(i) for i in range(can['n'])]
        edges=[(str(e['source']),str(e['target']),e.get('type','edge')) for e in can['edges']]
        deg=[0]*can['n']
        for e in can['edges']: deg[e['source']]+=1; deg[e['target']]+=1
        comps=_connected_components(nodes,edges)
        props={
            'degree_sequence':sorted(deg,reverse=True),
            'components':len(comps),
            'cycle_rank':len(edges)-len(nodes)+len(comps),
            'bipartite':_bipartite(nodes,edges),
        }
        return {
            'canon':can['digest'], 'orbit_size':can['orbit_size'], 'stabilizer_size':can['stabilizer_size'],
            'spectrum':{'characteristic_polynomial':_charpoly_coeffs(nodes,edges)},
            'trace_powers':_trace_powers(nodes,edges), 'properties':props,
            'boundary':deepcopy(window['boundary']),
        }

    def emit(self, window: dict[str,Any]) -> dict[str,Any]:
        fp=self.fingerprint(window)
        payload={
            'origin':deepcopy(window['origin']), 'window_ref':window['digest'], 'scale':window['scale'],
            **fp,
            'gates':{'canonical_graph':True,'multi_signature':True,'provenance':True},
            'residues':[],
        }
        payload['digest']=digest_record('GRFPS.GraphResoniteRecord','1.0.0',payload,(window['digest'],))
        return payload


class GraphInfogenome:
    def build(self, resonites: list[dict[str,Any]]) -> dict[str,Any]:
        members=sorted([r['digest'] for r in resonites])
        provenance=[{'resonite_ref':r['digest'],'origin':deepcopy(r['origin']),'window_ref':r['window_ref']} for r in sorted(resonites,key=lambda x:x['digest'])]
        nf=digest_record('GRFPS.GraphInfogenomeNormalForm','1.0.0',members)
        payload={'members':members,'provenance_graph':provenance,'normal_form':nf}
        payload['digest']=digest_record('GRFPS.GraphInfogenomeRecord','1.0.0',payload,members)
        return payload


class GluingEngine:
    def __init__(self, threshold: float=1.0): self.threshold=threshold

    @staticmethod
    def patch(window: dict[str,Any], resonite: dict[str,Any], *, time_index: int=0) -> dict[str,Any]:
        payload={'patch_id':window['window_id'],'members':window['members'],'fingerprint_ref':resonite['digest'],'origin':deepcopy(window['origin']),'gate':True,'scale':window['scale'],'time':time_index,'window_ref':window['digest']}
        payload['digest']=digest_record('GRFPS.Patch','1.0.0',payload,(window['digest'],resonite['digest']))
        return payload

    @staticmethod
    def compatibility(a: dict[str,Any], b: dict[str,Any]) -> tuple[float,list[str]]:
        overlap=sorted(set(a['members']) & set(b['members']))
        if not overlap: return 0.0, overlap
        # Shared member identity comes from the same provenance-bound evidence graph in this reference profile.
        score=1.0 if a['origin']==b['origin'] and a['scale']==b['scale'] else 0.5
        return score, overlap

    def glue(self, patches: list[dict[str,Any]], windows: list[dict[str,Any]], resonites: list[dict[str,Any]]) -> dict[str,Any]:
        seams=[]; overlap_edges=[]; residues=[]
        for a,b in combinations(sorted(patches,key=lambda x:x['patch_id']),2):
            score,overlap=self.compatibility(a,b)
            if overlap:
                seam={'charts':[a['patch_id'],b['patch_id']],'overlap':overlap,'transition':'identity-on-shared-members','compatibility':score,'tolerance':1.0-self.threshold,'witnesses':['OverlapWitness','ProvenanceWitness'],'residues':[] if score>=self.threshold else ['SEAM_CONFLICT']}
                seam['digest']=digest_record('GRFPS.SeamWitness','1.0.0',seam,(a['digest'],b['digest']))
                seams.append(seam); overlap_edges.append({'source':a['patch_id'],'target':b['patch_id'],'compatibility':score,'seam_ref':seam['digest']})
                if score<self.threshold: residues.append({'class':'SEAM_CONFLICT','seam_ref':seam['digest']})
        matrix=[]; ordered=sorted(patches,key=lambda x:x['patch_id'])
        for a in ordered:
            row=[]
            for b in ordered:
                if a['patch_id']==b['patch_id']: row.append(1.0)
                else: row.append(self.compatibility(a,b)[0])
            matrix.append(row)
        replay_digest=digest_record('GRFPS.GlueReplay','1.0.0',{'patches':[p['digest'] for p in ordered],'seams':[s['digest'] for s in seams]})
        cert={'overlap_graph':overlap_edges,'compatibility_matrix':matrix,'seams':seams,'residues':residues,'replay_digest':replay_digest,'status':'SEALED' if not residues else 'RESIDUAL'}
        cert['digest']=digest_record('GRFPS.GluingCertificate','1.0.0',cert,[p['digest'] for p in ordered])
        member_nodes=sorted({m for p in ordered for m in p['members']})
        complex_payload={'patches':[p['patch_id'] for p in ordered],'member_nodes':member_nodes,'seams':[s['digest'] for s in seams],'glue_certificate_ref':cert['digest']}
        complex_payload['digest']=digest_record('GRFPS.GluedPatchComplex','1.0.0',complex_payload)
        return {'patches':ordered,'certificate':cert,'complex':complex_payload}


class NerveComplexBuilder:
    def build(self, patches: list[dict[str,Any]], seams: list[dict[str,Any]]) -> dict[str,Any]:
        vertices=[p['patch_id'] for p in sorted(patches,key=lambda x:x['patch_id'])]
        seam_by_pair={tuple(sorted(s['charts'])):s for s in seams if s['compatibility']>=1.0}
        simplices=[]; higher=[]; holonomy=[]
        for v in vertices: simplices.append([v])
        for pair,s in sorted(seam_by_pair.items()): simplices.append(list(pair))
        pmap={p['patch_id']:p for p in patches}
        for tri in combinations(vertices,3):
            pairs=list(combinations(tri,2))
            common=set(pmap[tri[0]]['members']) & set(pmap[tri[1]]['members']) & set(pmap[tri[2]]['members'])
            if common and all(tuple(sorted(x)) in seam_by_pair for x in pairs):
                simp=list(tri); simplices.append(simp)
                hw={'simplex':simp,'common_overlap':sorted(common),'seam_refs':[seam_by_pair[tuple(sorted(x))]['digest'] for x in pairs],'transition_product':'identity'}
                hw['digest']=digest_record('GRFPS.HigherWitness','1.0.0',hw)
                higher.append(hw)
                h={'cycle':simp+[simp[0]],'transport':'identity','closure_error':0.0,'higher_witness_ref':hw['digest']}
                h['digest']=digest_record('GRFPS.HolonomyWitness','1.0.0',h)
                holonomy.append(h)
        payload={'vertices':vertices,'simplices':sorted(simplices,key=lambda x:(len(x),x)),'higher_witnesses':higher,'seams':[s['digest'] for s in seams],'holonomy_refs':[h['digest'] for h in holonomy]}
        payload['digest']=digest_record('GRFPS.NerveState','1.0.0',payload)
        return payload
