from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

from .canon import digest_record


@dataclass(frozen=True)
class SyntheticWorldSpec:
    world_id: str
    world_type: str
    clock: str
    scales: tuple[str, ...]
    attractors: tuple[str, ...]
    boundary_topology: str
    sealed_ground_truth_digest: str

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["scales"] = list(self.scales)
        payload["attractors"] = list(self.attractors)
        payload["digest"] = digest_record("GRFPS.SyntheticWorldSpec", "1.0.0", payload)
        return payload


class SyntheticWorldAdapter:
    def __init__(self, spec: SyntheticWorldSpec):
        self.spec = spec

    def bind(self) -> dict[str, Any]:
        return {
            "adapter": "SyntheticWorldAdapter/v1",
            "world_ref": self.spec.to_dict()["digest"],
            "world_frame": "world://synthetic/root",
            "machine_frame": "machine://grfps/root",
            "human_frame": "human://reference/root",
            "clock": self.spec.clock,
            "aperture": {"kind": "kernel-empty", "budget": 0},
            "calibration": {"status": "canonical"},
            "uncertainty": {"model": "exact-kernel"},
        }
