import json
from pathlib import Path

from grfps_refkernel.adaptive import AdaptiveOphanField
from grfps_refkernel.genome import GenomeCompiler
from grfps_refkernel.operator import OperatorRegistry

ROOT = Path(__file__).resolve().parents[1]


def _run():
    schema = json.loads((ROOT / 'schemas/perceptual-genome.schema.json').read_text())
    genome = json.loads((ROOT / 'genomes/reference-ophan-field.pgen.json').read_text())
    core = OperatorRegistry.core_registry()
    canonical, _ = GenomeCompiler(core, schema).compile(genome)
    field = AdaptiveOphanField(registry=core, genome=canonical, center_binding='f'*64, max_active=3)
    field.initial_spawn([{'axis':[1,0,0]},{'axis':[0,1,0]},{'axis':[0,0,1]}])
    return field.run_cycle(world_payload={'channels': {'alpha': 1.0, 'beta': 2.0}}, budget={'cost':4.0,'risk':1.0})


def test_r06_r11_full_cycle_is_deterministic_and_nontrivial():
    a = _run()
    b = _run()
    assert a['digest'] == b['digest']
    assert len(a['templates']) == 3
    assert len(a['bank']['states']) == 3
    assert len(a['exposures']) == 3
    assert len(a['coherence_graph']['nodes']) == 3
    assert a['dependency_profile']['effective_rank'] >= 2
    assert len(a['scheduler_decision']['selected']) == 1
