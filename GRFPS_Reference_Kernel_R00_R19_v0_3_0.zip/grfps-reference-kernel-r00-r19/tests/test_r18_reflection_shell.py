from grfps_refkernel.reflection import ReflectionShell

def test_r18_self_adjoint_involution_and_projectors():
    ps=[{'patch_id':x} for x in 'abc']
    cert={'overlap_graph':[{'source':'a','target':'b','compatibility':1.0},{'source':'b','target':'c','compatibility':1.0}]}
    r=ReflectionShell().build(patches=ps,glue_certificate=cert,density_by_patch={'a':1,'b':1,'c':1})
    diag=r['reflection_operator']['diagonal']; bp=r['plus_projector']['diagonal']; bm=r['minus_projector']['diagonal']
    assert all(x*x==1 for x in diag)
    assert all(x+y==1 for x,y in zip(bp,bm))
    assert all(x*y==0 for x,y in zip(bp,bm))
    assert r['region']['measure']==3
