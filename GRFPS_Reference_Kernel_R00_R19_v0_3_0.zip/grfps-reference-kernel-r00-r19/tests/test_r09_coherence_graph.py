from grfps_refkernel.coherence import CoherenceGraph


def _state(oid, phase):
    return {
        'id': oid,
        'template_ref': 't-' + oid,
        'lifecycle': 'ACTIVE',
        'rotor_state': {'phase': phase},
        'state_digest': oid * 64 if len(oid)==1 else ('a'*64),
    }


def test_r09_graph_builds_edges_and_history():
    g = CoherenceGraph()
    g.upsert_node(_state('a', 0.0), response_vector=[1.0, 0.0])
    g.upsert_node(_state('b', 0.0), response_vector=[1.0, 0.0])
    g.upsert_node(_state('c', 0.25), response_vector=[0.0, 1.0])
    profile = g.auto_connect(min_weight=0.0)
    snap = g.snapshot()
    assert len(snap['nodes']) == 3
    assert len(snap['edges']) == 3
    assert profile['effective_rank'] == 2
    assert '__field__' not in snap
    assert snap['digest']
