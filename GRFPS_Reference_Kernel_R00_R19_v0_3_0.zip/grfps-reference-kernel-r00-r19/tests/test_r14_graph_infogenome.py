from grfps_refkernel.graphmap import GraphWindowScanner, GraphResoniteBuilder, GraphInfogenome

def test_r14_normal_form_is_member_order_invariant():
    g={'nodes':[{'id':x,'label':'n'} for x in 'abc'],'edges':[{'source':'a','target':'b'},{'source':'b','target':'c'}]}
    ws=GraphWindowScanner(1).decompose(g,origin={'source':'s'},scale='meso')
    rs=[GraphResoniteBuilder().emit(w) for w in ws]
    a=GraphInfogenome().build(rs); b=GraphInfogenome().build(list(reversed(rs)))
    assert a['digest']==b['digest']
    assert len(a['provenance_graph'])==len(rs)
