from grfps_refkernel.graphmap import GraphWindowScanner

def graph():
    return {'nodes':[{'id':'c','label':'x'},{'id':'a','label':'x'},{'id':'b','label':'x'},{'id':'d','label':'x'}], 'edges':[{'source':'a','target':'b'},{'source':'b','target':'c'},{'source':'c','target':'d'}]}

def test_r12_decomposition_is_order_stable():
    s=GraphWindowScanner(radius=1)
    a=s.decompose(graph(),origin={'source':'w0'},scale='meso')
    g=graph(); g['nodes']=list(reversed(g['nodes'])); g['edges']=list(reversed(g['edges']))
    b=s.decompose(g,origin={'source':'w0'},scale='meso')
    assert [x['digest'] for x in a]==[x['digest'] for x in b]
    assert len(a)==4
