import json
from copy import deepcopy
from pathlib import Path

from grfps_refkernel.genome import GenomeCompiler
from grfps_refkernel.operator import OperatorRegistry

ROOT = Path(__file__).resolve().parents[1]


def compiler():
    schema = json.loads((ROOT / "schemas/perceptual-genome.schema.json").read_text())
    return GenomeCompiler(OperatorRegistry.core_registry(), schema)


def test_r05_compile_manifest_is_deterministic():
    genome = json.loads((ROOT / "genomes/reference-minimal.pgen.json").read_text())
    c = compiler()
    g1, out1 = c.compile(genome)
    g2, out2 = c.compile(deepcopy(genome))
    assert g1["digest"] == g2["digest"]
    assert out1["manifest"]["digest"] == out2["manifest"]["digest"]
    assert out1["program"]["digest"] == out2["program"]["digest"]
    assert out1["manifest"]["type_report"]["ok"]
    assert out1["manifest"]["linked_operators"]


def test_r05_compile_manifest_schema():
    genome = json.loads((ROOT / "genomes/reference-minimal.pgen.json").read_text())
    _, out = compiler().compile(genome)
    schema = json.loads((ROOT / "schemas/compile-manifest.schema.json").read_text())
    from jsonschema import Draft202012Validator
    Draft202012Validator(schema).validate(out["manifest"])
