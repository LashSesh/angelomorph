from grfps_refkernel.horizon import PhaseHorizonEngine

def test_r19_three_way_horizon_and_atlas():
    patches=[{'patch_id':'a','scale':'meso','members':['x'],'origin':{'s':1},'digest':'a'*64},{'patch_id':'b','scale':'meso','members':['x','y'],'origin':{'s':1},'digest':'b'*64}]
    cert={'overlap_graph':[{'source':'a','target':'b','compatibility':1.0,'seam_ref':'s'*64}]}
    reflection={'region':{'member_patches':['a','b']},'boundary_ref':'d'*64,'digest':'r'*64,'region_ref':'q'*64}
    mirror={'candidate_class':['m0'],'digest':'m'*64}
    out=PhaseHorizonEngine().build(patches=patches,glue_certificate=cert,reflection_state=reflection,mirror_state=mirror)
    assert set(out['horizon']) >= {'current','counterfactual','open','digest'}
    assert len(out['horizon']['current'])==1
    assert len(out['atlas']['charts'])==2
