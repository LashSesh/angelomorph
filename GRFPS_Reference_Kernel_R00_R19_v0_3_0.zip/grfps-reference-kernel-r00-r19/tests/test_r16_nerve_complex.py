from grfps_refkernel.graphmap import NerveComplexBuilder

def test_r16_higher_witness_and_holonomy():
    patches=[{'patch_id':'a','members':['x','y']},{'patch_id':'b','members':['x','z']},{'patch_id':'c','members':['x','w']}]
    seams=[]
    for a,b in [('a','b'),('a','c'),('b','c')]: seams.append({'charts':[a,b],'compatibility':1.0,'digest':(a+b)*32})
    n=NerveComplexBuilder().build(patches,seams)
    assert any(len(s)==3 for s in n['simplices'])
    assert len(n['higher_witnesses'])==1
    assert len(n['holonomy_refs'])==1
