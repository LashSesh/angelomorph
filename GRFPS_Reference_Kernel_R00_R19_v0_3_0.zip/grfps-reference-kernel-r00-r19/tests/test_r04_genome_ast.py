import json
from copy import deepcopy
from pathlib import Path

from grfps_refkernel.genome import GenomeCompiler
from grfps_refkernel.operator import OperatorRegistry

ROOT = Path(__file__).resolve().parents[1]


def compiler():
    schema = json.loads((ROOT / "schemas/perceptual-genome.schema.json").read_text())
    return GenomeCompiler(OperatorRegistry.core_registry(), schema)


def test_r04_ast_normal_form_is_order_stable():
    genome = json.loads((ROOT / "genomes/reference-minimal.pgen.json").read_text())
    shuffled = deepcopy(genome)
    shuffled["scale_lattice"]["scales"] = list(reversed(shuffled["scale_lattice"]["scales"]))
    a = compiler().normalize(genome)
    b = compiler().normalize(shuffled)
    # Scale order is semantically ranked, so normalize through rank for this stage lock.
    a["scale_lattice"]["scales"] = sorted(a["scale_lattice"]["scales"], key=lambda s: (s["rank"], s["id"]))
    b["scale_lattice"]["scales"] = sorted(b["scale_lattice"]["scales"], key=lambda s: (s["rank"], s["id"]))
    assert a == b


def test_r04_ast_resolves_operator_digests():
    genome = json.loads((ROOT / "genomes/reference-minimal.pgen.json").read_text())
    c = compiler()
    ast = c.parse(genome)
    normalized = c.normalize(ast)
    resolved = c.resolve(normalized)
    assert resolved
    assert all(len(r["operator_digest"]) == 64 for r in resolved)
    assert c.type_check(normalized, resolved)["ok"]
