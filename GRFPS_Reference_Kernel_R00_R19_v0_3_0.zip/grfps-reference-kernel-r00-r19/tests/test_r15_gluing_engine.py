from grfps_refkernel.graphmap import GraphWindowScanner, GraphResoniteBuilder, GluingEngine

def test_r15_overlap_seams_and_glue_certificate():
    g={'nodes':[{'id':x,'label':'n'} for x in 'abcd'],'edges':[{'source':'a','target':'b'},{'source':'b','target':'c'},{'source':'c','target':'d'}]}
    ws=GraphWindowScanner(1).decompose(g,origin={'source':'s'},scale='meso'); rb=GraphResoniteBuilder(); rs=[rb.emit(w) for w in ws]
    ge=GluingEngine(1.0); ps=[ge.patch(w,r) for w,r in zip(ws,rs)]; out=ge.glue(ps,ws,rs)
    assert out['certificate']['status']=='SEALED'
    assert out['certificate']['seams']
    assert out['complex']['member_nodes']==['a','b','c','d']
