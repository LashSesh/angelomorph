from grfps_refkernel.cartography import CartographicRuntime
from grfps_refkernel.ledger import Ledger

def run():
    graph={'nodes':[{'id':x,'label':'node'} for x in 'abcdef'], 'edges':[{'source':'a','target':'b'},{'source':'b','target':'c'},{'source':'c','target':'a'},{'source':'c','target':'d'},{'source':'d','target':'e'},{'source':'e','target':'f'}]}
    candidates=[{'id':'line','features':{'components':1,'cycle_rank':0}},{'id':'lollipop','features':{'components':1,'cycle_rank':1}},{'id':'split','features':{'components':2,'cycle_rank':1}}]
    constraints=[{'feature':'components','value':1},{'feature':'cycle_rank','value':1}]
    ledger=Ledger('c'*64)
    return CartographicRuntime(radius=1).run(evidence_graph=graph,origin={'source_digest':'1'*64,'window':'world-0'},candidate_models=candidates,mirror_constraints=constraints,genome_ref='g'*64,ledger=ledger), ledger

def test_r12_r19_full_cartographic_vertical_is_deterministic():
    a,la=run(); b,lb=run()
    assert a['digest']==b['digest']
    assert a['mirror_state']['candidate_class']==['lollipop']
    assert a['reflection_state']['reflection_operator']['involutive']
    assert a['horizon_state']['validity']=='SEALED'
    assert a['atlas_state']['charts']
    assert la.verify_chain() and lb.verify_chain()
    assert len(la.segments)==8
