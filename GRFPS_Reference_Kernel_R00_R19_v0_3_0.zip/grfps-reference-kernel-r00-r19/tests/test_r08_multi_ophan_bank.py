import json
from pathlib import Path
import pytest

from grfps_refkernel.genome import GenomeCompiler
from grfps_refkernel.ophan import OphanBank, OphanTemplateCompiler
from grfps_refkernel.operator import OperatorRegistry

ROOT = Path(__file__).resolve().parents[1]


def _templates():
    schema = json.loads((ROOT / 'schemas/perceptual-genome.schema.json').read_text())
    genome = json.loads((ROOT / 'genomes/reference-ophan-field.pgen.json').read_text())
    reg = OperatorRegistry.core_registry()
    canonical, _ = GenomeCompiler(reg, schema).compile(genome)
    return OphanTemplateCompiler(reg).compile_all(canonical)


def test_r08_spawn_reuse_and_active_budget():
    templates = _templates()
    bank = OphanBank(max_active=2)
    a, mode_a = bank.spawn_or_reuse(templates[0], center_binding='a'*64, context={'axis':[1,0,0]}, nonce='0')
    b, mode_b = bank.spawn_or_reuse(templates[1], center_binding='a'*64, context={'axis':[0,1,0]}, nonce='1')
    assert mode_a == mode_b == 'SPAWN'
    a2, mode_reuse = bank.spawn_or_reuse(templates[0], center_binding='a'*64, context={'axis':[1,0,0]}, nonce='2')
    assert mode_reuse == 'REUSE'
    assert a2['id'] == a['id']
    with pytest.raises(RuntimeError):
        bank.spawn_or_reuse(templates[2], center_binding='a'*64, context={'axis':[0,0,1]}, nonce='3')
    assert len(bank.active) == 2
