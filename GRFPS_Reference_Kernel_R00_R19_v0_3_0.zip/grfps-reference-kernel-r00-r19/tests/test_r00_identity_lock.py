import json
from pathlib import Path

from jsonschema import Draft202012Validator

from grfps_refkernel.identity import IdentityLock, RUNTIME_SURFACES, LINEAGE_SURFACE

ROOT = Path(__file__).resolve().parents[1]


def test_r00_identity_lock():
    identity = json.loads((ROOT / "conformance/identity-lock.json").read_text())
    schema = json.loads((ROOT / "schemas/identity-lock.schema.json").read_text())
    Draft202012Validator(schema).validate(identity)
    assert tuple(identity["runtime_surfaces"]) == RUNTIME_SURFACES
    assert identity["lineage_surface"] == LINEAGE_SURFACE
    assert len(identity["runtime_surfaces"]) == 12
    assert len(identity["digest"]) == 64
    assert len(identity["surface_digest"]) == 64
