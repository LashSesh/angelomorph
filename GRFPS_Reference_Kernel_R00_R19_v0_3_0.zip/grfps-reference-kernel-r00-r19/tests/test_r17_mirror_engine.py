from grfps_refkernel.mirror import MirrorEngine

def test_r17_candidate_fiber_contracts_monotonically():
    c=[{'id':'line','features':{'cycle_rank':0,'components':1}},{'id':'cycle','features':{'cycle_rank':1,'components':1}},{'id':'split','features':{'cycle_rank':0,'components':2}}]
    m=MirrorEngine(c)
    a=m.contract([{'feature':'components','value':1}],model_epoch=0,genome_ref='g'*64,nerve_ref='n'*64)
    b=m.contract([{'feature':'cycle_rank','value':1}],model_epoch=0,genome_ref='g'*64,nerve_ref='n'*64)
    assert len(b['candidate_class'])<=len(a['candidate_class'])
    assert b['candidate_class']==['cycle']
    assert b['marginal_gain']>0
