from grfps_refkernel.operator import OperatorRegistry
from grfps_refkernel.ledger import Ledger
from grfps_refkernel.canon import digest_record


def test_r02_registry_is_content_addressed_and_stable():
    a = OperatorRegistry.core_registry().snapshot()
    b = OperatorRegistry.core_registry().snapshot()
    assert a == b
    assert len(a["entries"]) >= 16
    assert len(a["digest"]) == 64


def test_r02_trace_chain_and_checkpoint():
    run_ref = "a" * 64
    ledger = Ledger(run_ref)
    pre = digest_record("State", "1", {"i": 0})
    post = digest_record("State", "1", {"i": 1})
    ledger.append(operator="constitution.canon", input_digest=pre, pre_digest=pre, post_digest=post)
    ledger.append(operator="constitution.digest", input_digest=post, pre_digest=post, post_digest=post)
    cp = ledger.checkpoint({"i": 1}, 1)
    assert ledger.verify_chain()
    assert cp["trace_head"] == ledger.head
    assert len(cp["digest"]) == 64
