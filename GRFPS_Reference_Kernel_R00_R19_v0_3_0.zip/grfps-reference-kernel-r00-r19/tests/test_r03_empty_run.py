import json
from pathlib import Path

from grfps_refkernel.identity import IdentityLock
from grfps_refkernel.kernel import ReferenceKernel
from grfps_refkernel.synthworld import SyntheticWorldAdapter, SyntheticWorldSpec

ROOT = Path(__file__).resolve().parents[1]


def build_kernel_world():
    identity_data = json.loads((ROOT / "conformance/identity-lock.json").read_text())
    identity = IdentityLock(
        grfps_version=identity_data["grfps_version"],
        reference_kernel_version=identity_data["reference_kernel_version"],
        spec_pdf_sha256=identity_data["spec_pdf_sha256"],
        spec_tex_sha256=identity_data["spec_tex_sha256"],
    )
    schema = json.loads((ROOT / "schemas/perceptual-genome.schema.json").read_text())
    kernel = ReferenceKernel.build(identity, schema)
    world = SyntheticWorldAdapter(
        SyntheticWorldSpec(
            "world.kernel.empty", "kernel-empty", "clock://event",
            ("micro", "meso", "macro"), ("attractor.kernel-closure",),
            "point-boundary", "1" * 64,
        )
    )
    return kernel, world


def test_r03_empty_run_seals_and_replays():
    genome = json.loads((ROOT / "genomes/reference-minimal.pgen.json").read_text())
    kernel, world = build_kernel_world()
    bundle = kernel.empty_run(genome=genome, world=world)
    replay = kernel.replay_empty_run(bundle, genome, world)
    assert bundle["chain_valid"]
    assert bundle["runtime_state"]["status"] == "STOP"
    assert bundle["sealed_run"]["status"] == "STOP"
    assert replay["equal"]
