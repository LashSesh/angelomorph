from grfps_refkernel.scheduler import PerceptualScheduler, SchedulerWeights


def test_r10_scheduler_uses_declared_utility_and_budget():
    s = PerceptualScheduler(SchedulerWeights())
    candidates = [
        {'candidate_id':'a','features':{'information_gain':1.0,'coverage_gain':0.0,'boundary_gain':0.0,'target_gain':0.0,'cost':0.2,'risk':0.0,'redundancy':0.0}},
        {'candidate_id':'b','features':{'information_gain':0.8,'coverage_gain':0.8,'boundary_gain':0.0,'target_gain':0.0,'cost':0.2,'risk':0.0,'redundancy':0.0}},
        {'candidate_id':'c','features':{'information_gain':5.0,'coverage_gain':0.0,'boundary_gain':0.0,'target_gain':0.0,'cost':10.0,'risk':0.0,'redundancy':0.0}},
    ]
    decision = s.select(candidates, budget={'cost':1.0,'risk':1.0}, limit=1)
    assert decision['selected'][0]['candidate_id'] == 'b'
    assert decision['digest']
