import json
from pathlib import Path
from jsonschema import Draft202012Validator

from grfps_refkernel.canon import canonical_json, digest_record

ROOT = Path(__file__).resolve().parents[1]


def test_r01_genome_schema_and_canon_roundtrip():
    genome = json.loads((ROOT / "genomes/reference-minimal.pgen.json").read_text())
    schema = json.loads((ROOT / "schemas/perceptual-genome.schema.json").read_text())
    Draft202012Validator(schema).validate(genome)
    canon1 = canonical_json(genome)
    canon2 = canonical_json(json.loads(canon1))
    assert canon1 == canon2
    assert digest_record("GRFPS.PerceptualGenome", genome["version"], json.loads(canon1)) == digest_record(
        "GRFPS.PerceptualGenome", genome["version"], json.loads(canon2)
    )


def test_r01_record_lock_contains_all_runtime_families():
    manifest = json.loads((ROOT / "schemas/record-lock-manifest.json").read_text())
    assert len(manifest["runtime_surfaces"]) == 12
    assert manifest["lineage_surface"] == "Lineage"
    assert "PerceptualGenomeRecord" in manifest["record_families"]
    assert "TraceSegment" in manifest["record_families"]
    assert "ReplayManifest" in manifest["record_families"]
