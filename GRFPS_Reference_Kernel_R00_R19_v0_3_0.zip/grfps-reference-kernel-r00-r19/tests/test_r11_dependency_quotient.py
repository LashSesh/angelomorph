from grfps_refkernel.dependency import DependencyQuotient, matrix_rank


def test_r11_rank_and_redundancy_are_separate():
    vectors = {
        'a': [1.0,0.0,0.0],
        'b': [2.0,0.0,0.0],
        'c': [0.0,1.0,0.0],
    }
    q = DependencyQuotient(similarity_threshold=0.98)
    profile = q.analyze(vectors)
    assert profile['effective_rank'] == 2
    assert ['a','b'] in profile['clusters']
    assert profile['adjusted_weight']['a'] == 0.5
    assert profile['adjusted_weight']['b'] == 0.5
    assert profile['adjusted_weight']['c'] == 1.0
    assert matrix_rank(list(vectors.values())) == 2
