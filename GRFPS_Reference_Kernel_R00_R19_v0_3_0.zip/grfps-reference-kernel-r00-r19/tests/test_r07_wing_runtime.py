import json
from pathlib import Path

from grfps_refkernel.genome import GenomeCompiler
from grfps_refkernel.ophan import OphanLifecycle, OphanTemplateCompiler, activate_ophan, calibrate_ophan, expose_ophan, instantiate_ophan
from grfps_refkernel.operator import OperatorRegistry

ROOT = Path(__file__).resolve().parents[1]


def _template():
    schema = json.loads((ROOT / 'schemas/perceptual-genome.schema.json').read_text())
    genome = json.loads((ROOT / 'genomes/reference-ophan-field.pgen.json').read_text())
    reg = OperatorRegistry.core_registry()
    canonical, _ = GenomeCompiler(reg, schema).compile(genome)
    return OphanTemplateCompiler(reg).compile_all(canonical)[0]


def test_r07_lifecycle_and_exposure_are_deterministic():
    template = _template()
    state = instantiate_ophan(template, center_binding='c' * 64, context={'axis':[1,0,0]}, instance_nonce='n0')
    assert state['lifecycle'] == OphanLifecycle.INSTANTIATED.value
    state = calibrate_ophan(state, template)
    state = activate_ophan(state)
    assert state['lifecycle'] == OphanLifecycle.ACTIVE.value
    world = {'channels': {'alpha': 2.0, 'beta': 3.0}}
    next_state, exposure = expose_ophan(state, template, world_payload=world, event_index=0)
    next_state_2, exposure_2 = expose_ophan(state, template, world_payload=world, event_index=0)
    assert exposure['digest'] == exposure_2['digest']
    assert next_state['state_digest'] == next_state_2['state_digest']
    assert exposure['ophan_ref'] == state['id']
    assert next_state['exposure_count'] == 1
