import json
from pathlib import Path

from grfps_refkernel.genome import GenomeCompiler
from grfps_refkernel.ophan import OphanTemplateCompiler
from grfps_refkernel.operator import OperatorRegistry

ROOT = Path(__file__).resolve().parents[1]


def test_r06_template_compile_is_canonical_and_resolved():
    schema = json.loads((ROOT / 'schemas/perceptual-genome.schema.json').read_text())
    genome = json.loads((ROOT / 'genomes/reference-ophan-field.pgen.json').read_text())
    core = OperatorRegistry.core_registry()
    canonical, _ = GenomeCompiler(core, schema).compile(genome)
    templates = OphanTemplateCompiler(core).compile_all(canonical)
    assert len(templates) == 3
    assert [t.gene_id for t in templates] == sorted(t.gene_id for t in templates)
    assert all(len(t.operator_graph) == 2 for t in templates)
    again = OphanTemplateCompiler(core).compile_all(canonical)
    assert [t.digest for t in templates] == [t.digest for t in again]
