from grfps_refkernel.graphmap import GraphWindowScanner, GraphResoniteBuilder

def test_r13_multisignature_and_provenance():
    g={'nodes':[{'id':str(i),'label':'n'} for i in range(4)],'edges':[{'source':'0','target':'1'},{'source':'1','target':'2'},{'source':'2','target':'0'},{'source':'2','target':'3'}]}
    w=GraphWindowScanner(1).decompose(g,origin={'source':'sealed'},scale='micro')[2]
    r=GraphResoniteBuilder().emit(w)
    assert r['canon']==w['canonical_graph']['digest']
    assert r['spectrum']['characteristic_polynomial'][0]==1
    assert len(r['trace_powers'])==3
    assert r['origin']['source']=='sealed'
