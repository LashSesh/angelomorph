use grfps_canon::digest_record;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use thiserror::Error;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum OphanLifecycle { Template, Instantiated, Calibrated, Active, Quiescent, Retired }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OphanTemplate {
    pub gene_id: String,
    pub genome_ref: String,
    pub lineage_ref: String,
    pub aperture: Value,
    pub rotor_profile: Value,
    pub projection_profile: Value,
    pub operator_graph: Vec<Value>,
    pub scheduler_features: Value,
    pub closure_contract: Value,
    pub budgets: Value,
    pub witness_contract: Value,
    pub digest: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OphanState {
    pub id: String,
    pub template_ref: String,
    pub genome_ref: String,
    pub center_binding: String,
    pub lifecycle: OphanLifecycle,
    pub rotor_state: Value,
    pub calibration: Option<Value>,
    pub evidence_refs: Vec<String>,
    pub residue_refs: Vec<String>,
    pub exposure_count: u64,
    pub state_digest: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExposureState {
    pub ophan_ref: String,
    pub template_ref: String,
    pub phase: f64,
    pub axis: [f64; 3],
    pub sector: u32,
    pub sheet: u32,
    pub orientation: Value,
    pub payload: Value,
    pub witnesses: Vec<String>,
    pub event_index: u64,
    pub digest: String,
}

#[derive(Debug, Error)]
pub enum OphanError {
    #[error("invalid lifecycle transition")]
    Lifecycle,
    #[error("canonicalization: {0}")]
    Canon(#[from] serde_json::Error),
}

pub fn instantiate(template: &OphanTemplate, center_binding: &str, context: &Value, nonce: &str) -> Result<OphanState, OphanError> {
    let phase = template.rotor_profile.get("phase_origin").and_then(Value::as_f64).unwrap_or(0.0);
    let bare = json!({
        "template_ref": template.digest,
        "genome_ref": template.genome_ref,
        "center_binding": center_binding,
        "context": context,
        "nonce": nonce,
        "lifecycle": "INSTANTIATED",
        "rotor_state": {"phase":phase,"cycle_index":0,"carrier":template.rotor_profile.get("carrier").cloned().unwrap_or(json!("S1"))}
    });
    let id = digest_record("GRFPS.OphanInstanceId", "1.0.0", &bare, &[template.digest.clone(), center_binding.to_string()])?;
    let state_payload = json!({"id":id,"template_ref":template.digest,"genome_ref":template.genome_ref,"center_binding":center_binding,"lifecycle":"INSTANTIATED","rotor_state":bare["rotor_state"],"calibration":null,"evidence_refs":[],"residue_refs":[],"exposure_count":0});
    let state_digest = digest_record("GRFPS.OphanState", "1.0.0", &state_payload, &[template.digest.clone()])?;
    Ok(OphanState { id, template_ref: template.digest.clone(), genome_ref: template.genome_ref.clone(), center_binding: center_binding.into(), lifecycle: OphanLifecycle::Instantiated, rotor_state: bare["rotor_state"].clone(), calibration: None, evidence_refs: vec![], residue_refs: vec![], exposure_count: 0, state_digest })
}
