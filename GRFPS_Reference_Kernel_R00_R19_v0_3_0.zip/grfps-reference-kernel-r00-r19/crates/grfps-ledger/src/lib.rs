use grfps_canon::digest_record;
use grfps_types::{Digest, TraceSegment};
use serde::Serialize;
use serde_json::Value;

#[derive(Debug, Clone)]
pub struct Ledger {
    run_ref: Digest,
    segments: Vec<TraceSegment>,
    checkpoints: Vec<Value>,
}

impl Ledger {
    pub fn new(run_ref: Digest) -> Self { Self { run_ref, segments: vec![], checkpoints: vec![] } }
    pub fn head(&self) -> Option<&Digest> { self.segments.last().map(|s| &s.digest) }
    pub fn segments(&self) -> &[TraceSegment] { &self.segments }
    pub fn checkpoints(&self) -> &[Value] { &self.checkpoints }

    pub fn append(&mut self, operator: &str, input_digest: Digest, pre_digest: Digest, post_digest: Digest, witnesses: Vec<String>, residues: Vec<String>, clocks: Value) -> serde_json::Result<Digest> {
        let parent = self.head().cloned();
        let payload = serde_json::json!({
            "run_ref": self.run_ref,
            "parent_digest": parent,
            "input_digest": input_digest,
            "operator": operator,
            "pre_digest": pre_digest,
            "post_digest": post_digest,
            "witnesses": witnesses,
            "residues": residues,
            "clocks": clocks,
            "determinism": "DETERMINISTIC"
        });
        let parents = parent.clone().into_iter().collect::<Vec<_>>();
        let digest = digest_record("GRFPS.TraceSegment", "1.0.0", &payload, &parents)?;
        let segment: TraceSegment = serde_json::from_value({ let mut v = payload; v.as_object_mut().unwrap().insert("digest".into(), Value::String(digest.clone())); v })?;
        self.segments.push(segment);
        Ok(digest)
    }

    pub fn checkpoint<T: Serialize>(&mut self, state: &T, update_index: u64) -> serde_json::Result<Value> {
        let state_digest = digest_record("GRFPS.RuntimeState", "1.0.0", state, &[])?;
        let payload = serde_json::json!({
            "run_ref": self.run_ref,
            "update_index": update_index,
            "trace_head": self.head(),
            "state_digest": state_digest
        });
        let parents = self.head().cloned().into_iter().collect::<Vec<_>>();
        let digest = digest_record("GRFPS.Checkpoint", "1.0.0", &payload, &parents)?;
        let mut out = payload;
        out.as_object_mut().unwrap().insert("digest".into(), Value::String(digest));
        self.checkpoints.push(out.clone());
        Ok(out)
    }
}
