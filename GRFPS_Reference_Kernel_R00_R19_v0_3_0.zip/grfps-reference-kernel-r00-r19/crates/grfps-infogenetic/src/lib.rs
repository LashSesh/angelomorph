use grfps_canon::digest_record;
use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GraphWindowRecord {
    pub origin: Value,
    pub scale: String,
    pub window_id: String,
    pub members: Vec<String>,
    pub canonical_graph: Value,
    pub boundary: Value,
    pub digest: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GraphResoniteRecord {
    pub origin: Value,
    pub window_ref: String,
    pub canon: String,
    pub orbit_size: usize,
    pub stabilizer_size: usize,
    pub spectrum: Value,
    pub trace_powers: Vec<i64>,
    pub properties: Value,
    pub boundary: Value,
    pub gates: Value,
    pub digest: String,
}

pub fn graph_infogenome_digest(members: &[String]) -> Result<String, serde_json::Error> {
    let mut m = members.to_vec();
    m.sort();
    digest_record("GRFPS.GraphInfogenomeRecord", "1.0.0", &m, &m)
}
