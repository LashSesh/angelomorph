use grfps_canon::{canonical_value, digest_record};
use grfps_operator::{OperatorRegistry, RegistryError};
use grfps_types::{Digest, GenomeCompileManifest, PerceptualGenome, PerceptualProgram};
use serde_json::{json, Value};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum GenomeError {
    #[error("json: {0}")]
    Json(#[from] serde_json::Error),
    #[error("registry: {0}")]
    Registry(#[from] RegistryError),
    #[error("type mismatch in gene {0}")]
    TypeMismatch(String),
}

pub struct GenomeCompiler<'a> { pub registry: &'a OperatorRegistry }

impl<'a> GenomeCompiler<'a> {
    pub fn parse(&self, bytes: &[u8]) -> Result<PerceptualGenome, GenomeError> { Ok(serde_json::from_slice(bytes)?) }

    pub fn normalize(&self, mut g: PerceptualGenome) -> Result<PerceptualGenome, GenomeError> {
        g.observables.sort_by(|a,b| a.id.cmp(&b.id));
        g.relations.sort_by(|a,b| a.id.cmp(&b.id));
        g.ophan_templates.sort_by(|a,b| a.id.cmp(&b.id));
        g.phase_profiles.sort_by(|a,b| a.id.cmp(&b.id));
        g.attractor_programs.sort_by(|a,b| a.id.cmp(&b.id));
        g.boundary_programs.sort_by(|a,b| a.id.cmp(&b.id));
        g.render_grammar.sort_by(|a,b| a.id.cmp(&b.id));
        g.evolution_programs.sort_by(|a,b| a.id.cmp(&b.id));
        g.digest = None;
        Ok(g)
    }

    pub fn compile(&self, genome: PerceptualGenome) -> Result<(PerceptualGenome, GenomeCompileManifest, PerceptualProgram), GenomeError> {
        let mut g = self.normalize(genome)?;
        let mut resolved: Vec<Value> = vec![];
        let mut linked: Vec<Digest> = vec![];
        for gene in &g.observables {
            let op = self.registry.resolve(&gene.operator_ref)?;
            if op.domain != gene.input_type || op.codomain != gene.output_type { return Err(GenomeError::TypeMismatch(gene.id.clone())); }
            linked.push(gene.operator_ref.clone());
            resolved.push(json!({"gene_id": gene.id, "operator_digest": gene.operator_ref, "operator_id": op.operator_id}));
        }
        for gene in &g.ophan_templates {
            for d in &gene.operator_refs { let _ = self.registry.resolve(d)?; linked.push(d.clone()); }
        }
        linked.sort(); linked.dedup();
        let bare = canonical_value(&g)?;
        let genome_digest = digest_record("GRFPS.PerceptualGenome", &g.version, &bare, &g.lineage)?;
        g.digest = Some(genome_digest.clone());
        let scheduler_plan = json!({
            "gene_order": g.observables.iter().map(|x| x.id.clone()).collect::<Vec<_>>(),
            "linked_operators": linked,
            "scale_lattice": g.scale_lattice,
            "budgets": g.budgets,
        });
        let registry_digest = self.registry.snapshot_digest()?;
        let manifest_payload = json!({
            "genome_ref": genome_digest,
            "resolved_refs": resolved,
            "type_report": {"ok": true, "issues": []},
            "linked_operators": linked,
            "scheduler_plan": scheduler_plan,
            "registry_digest": registry_digest,
        });
        let manifest_digest = digest_record("GRFPS.GenomeCompileManifest", "1.0.0", &manifest_payload, &[g.digest.clone().unwrap()])?;
        let manifest: GenomeCompileManifest = serde_json::from_value({ let mut x=manifest_payload; x.as_object_mut().unwrap().insert("digest".into(), Value::String(manifest_digest.clone())); x })?;
        let program_payload = json!({
            "genome_ref": g.digest.clone().unwrap(),
            "compile_manifest_ref": manifest_digest,
            "operator_dag": manifest.linked_operators,
            "gene_order": manifest.scheduler_plan["gene_order"],
            "scale_lattice": g.scale_lattice,
            "attractor_programs": g.attractor_programs,
            "boundary_programs": g.boundary_programs,
            "render_grammar": g.render_grammar,
        });
        let program_digest = digest_record("GRFPS.PerceptualProgram", "1.0.0", &program_payload, &[manifest.digest.clone()])?;
        let program: PerceptualProgram = serde_json::from_value({ let mut x=program_payload; x.as_object_mut().unwrap().insert("digest".into(), Value::String(program_digest)); x })?;
        Ok((g, manifest, program))
    }
}
