use grfps_canon::digest_record;
use serde::{Deserialize, Serialize};
use serde_json::json;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SyntheticWorldSpec {
    pub world_id: String,
    pub world_type: String,
    pub clock: String,
    pub scales: Vec<String>,
    pub attractors: Vec<String>,
    pub boundary_topology: String,
    pub sealed_ground_truth_digest: String,
}

impl SyntheticWorldSpec {
    pub fn binding(&self) -> serde_json::Result<serde_json::Value> {
        let world_ref = digest_record("GRFPS.SyntheticWorldSpec", "1.0.0", self, &[])?;
        Ok(json!({
            "adapter": "SyntheticWorldAdapter/v1",
            "world_ref": world_ref,
            "world_frame": "world://synthetic/root",
            "machine_frame": "machine://grfps/root",
            "human_frame": "human://reference/root",
            "clock": self.clock,
            "aperture": {"kind":"kernel-empty","budget":0},
            "calibration": {"status":"canonical"},
            "uncertainty": {"model":"exact-kernel"}
        }))
    }
}
