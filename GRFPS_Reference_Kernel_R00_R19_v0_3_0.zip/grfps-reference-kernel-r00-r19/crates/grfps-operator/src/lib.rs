use grfps_canon::digest_record;
use grfps_types::{Digest, OperatorSpec};
use std::collections::BTreeMap;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum RegistryError {
    #[error("unresolved operator digest {0}")]
    Unresolved(Digest),
    #[error("serialization: {0}")]
    Serialization(#[from] serde_json::Error),
}

#[derive(Debug, Default, Clone)]
pub struct OperatorRegistry {
    by_digest: BTreeMap<Digest, OperatorSpec>,
}

impl OperatorRegistry {
    pub fn register(&mut self, spec: OperatorSpec) -> Result<Digest, RegistryError> {
        let digest = digest_record("GRFPS.OperatorSpec", &spec.version, &spec, &[])?;
        self.by_digest.insert(digest.clone(), spec);
        Ok(digest)
    }

    pub fn resolve(&self, digest: &str) -> Result<&OperatorSpec, RegistryError> {
        self.by_digest.get(digest).ok_or_else(|| RegistryError::Unresolved(digest.to_owned()))
    }

    pub fn snapshot_digest(&self) -> Result<Digest, RegistryError> {
        Ok(digest_record("GRFPS.OperatorRegistry", "1.0.0", &self.by_digest, &[])?)
    }

    pub fn iter(&self) -> impl Iterator<Item = (&Digest, &OperatorSpec)> { self.by_digest.iter() }
}
