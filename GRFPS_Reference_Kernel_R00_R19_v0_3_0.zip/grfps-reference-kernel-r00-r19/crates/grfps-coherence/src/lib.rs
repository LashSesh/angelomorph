use grfps_canon::digest_record;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::BTreeMap;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CoherenceNode {
    pub operator_ref: String,
    pub phase: f64,
    pub response_vector: Vec<f64>,
    pub coherence: f64,
    pub stability_vector: BTreeMap<String, f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CoherenceEdge {
    pub source: String,
    pub target: String,
    pub weight: f64,
    pub relation_type: String,
    pub dependency: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DependencyProfile {
    pub items: Vec<String>,
    pub effective_rank: usize,
    pub clusters: Vec<Vec<String>>,
    pub redundancy: BTreeMap<String, f64>,
    pub adjusted_weight: BTreeMap<String, f64>,
    pub digest: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SchedulerDecision {
    pub ranked: Vec<Value>,
    pub selected: Vec<Value>,
    pub held: Vec<Value>,
    pub remaining_budget: Value,
    pub digest: String,
}

pub fn scheduler_score(features: &BTreeMap<String, f64>, weights: &BTreeMap<String, f64>) -> f64 {
    let pos = ["information_gain", "coverage_gain", "boundary_gain", "target_gain"];
    let neg = ["cost", "risk", "redundancy"];
    let mut score = 0.0;
    for k in pos { score += features.get(k).copied().unwrap_or(0.0) * weights.get(k).copied().unwrap_or(1.0); }
    for k in neg { score -= features.get(k).copied().unwrap_or(0.0) * weights.get(k).copied().unwrap_or(1.0); }
    score
}

pub fn profile_digest(profile: &Value) -> Result<String, serde_json::Error> {
    digest_record("GRFPS.DependencyProfile", "1.0.0", profile, &[])
}
