use grfps_canon::digest_record;
use grfps_genome::{GenomeCompiler, GenomeError};
use grfps_ledger::Ledger;
use grfps_operator::OperatorRegistry;
use grfps_synthworld::SyntheticWorldSpec;
use grfps_types::{IdentityLock, PerceptualGenome, PulseStatus};
use serde_json::{json, Value};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum RuntimeError {
    #[error("genome: {0}")]
    Genome(#[from] GenomeError),
    #[error("json: {0}")]
    Json(#[from] serde_json::Error),
}

pub struct ReferenceKernel {
    pub identity: IdentityLock,
    pub registry: OperatorRegistry,
}

impl ReferenceKernel {
    pub fn empty_run(&self, genome: PerceptualGenome, world: &SyntheticWorldSpec, run_id: &str) -> Result<Value, RuntimeError> {
        let binding = world.binding()?;
        let rd_payload = json!({
            "run_id": run_id,
            "version": self.identity.reference_kernel_version,
            "identity_digest": self.identity.digest,
            "domain": "synthetic-kernel",
            "models": ["GRFPS-v3"],
            "tolerances": {"canonical":"exact"},
            "budgets": {"kernel_steps":16},
            "policies": {"mode":"empty-run"},
            "seeds": {"primary":0},
            "clocks": {"event":0,"epoch":0,"lineage":0},
            "adapters": [binding["adapter"].clone()],
            "conformance": ["C00","C01","C02","C15"]
        });
        let rd_digest = digest_record("GRFPS.RunDescriptor", "1.0.0", &rd_payload, &[self.identity.digest.clone()])?;
        let mut ledger = Ledger::new(rd_digest.clone());
        let compiler = GenomeCompiler { registry: &self.registry };
        let (genome, manifest, program) = compiler.compile(genome)?;
        let mut state = json!({
            "Binding": {"run_ref": rd_digest, "world": binding},
            "CausalField": {}, "PerceptualGenome": {"genome_ref": genome.digest, "compile_manifest_ref": manifest.digest, "perceptual_program_ref": program.digest},
            "OphanField": {}, "SyntheticPercept": {}, "InfogeneticMap": {}, "ReflectionShell": {},
            "Gyrosphere": {}, "Navigator": {}, "EffectPort": {}, "HumanView": {}, "Ledger": {},
            "status": PulseStatus::Stop, "update_index": 1
        });
        let state_digest = digest_record("GRFPS.RuntimeState", "1.0.0", &state, &[])?;
        let _ = ledger.append("constitution.seal", state_digest.clone(), state_digest.clone(), state_digest.clone(), vec!["SealWitness".into()], vec![], json!({"event":1}))?;
        state["Ledger"]["trace_head"] = json!(ledger.head());
        let checkpoint = ledger.checkpoint(&state, 1)?;
        Ok(json!({
            "run_descriptor_digest": rd_digest,
            "genome": genome,
            "compile_manifest": manifest,
            "perceptual_program": program,
            "runtime_state": state,
            "checkpoint": checkpoint,
            "trace": ledger.segments()
        }))
    }
}
