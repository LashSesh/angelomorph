use serde::Serialize;
use serde_json::{Map, Value};
use sha2::{Digest as _, Sha256};

fn normalize(v: Value) -> Value {
    match v {
        Value::Object(m) => {
            let mut keys: Vec<_> = m.into_iter().collect();
            keys.sort_by(|a, b| a.0.cmp(&b.0));
            let mut out = Map::new();
            for (k, v) in keys { out.insert(k, normalize(v)); }
            Value::Object(out)
        }
        Value::Array(xs) => Value::Array(xs.into_iter().map(normalize).collect()),
        other => other,
    }
}

pub fn canonical_value<T: Serialize>(value: &T) -> serde_json::Result<Value> {
    Ok(normalize(serde_json::to_value(value)?))
}

pub fn canonical_bytes<T: Serialize>(value: &T) -> serde_json::Result<Vec<u8>> {
    serde_json::to_vec(&canonical_value(value)?)
}

pub fn sha256_hex(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}

pub fn digest_record<T: Serialize>(record_type: &str, version: &str, payload: &T, parents: &[String]) -> serde_json::Result<String> {
    let mut ps = parents.to_vec();
    ps.sort();
    let env = serde_json::json!({
        "type": record_type,
        "version": version,
        "payload": canonical_value(payload)?,
        "parents": ps,
    });
    Ok(sha256_hex(&canonical_bytes(&env)?))
}
