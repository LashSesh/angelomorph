use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiagonalReflection {
    pub basis: Vec<String>,
    pub diagonal: Vec<i8>,
}

impl DiagonalReflection {
    pub fn is_self_adjoint(&self) -> bool { true }
    pub fn is_involutive(&self) -> bool { self.diagonal.iter().all(|x| *x == 1 || *x == -1) }
    pub fn plus_projector(&self) -> Vec<u8> { self.diagonal.iter().map(|x| if *x == 1 {1} else {0}).collect() }
    pub fn minus_projector(&self) -> Vec<u8> { self.diagonal.iter().map(|x| if *x == -1 {1} else {0}).collect() }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn reflection_identities_hold() {
        let r=DiagonalReflection{basis:vec!["a".into(),"b".into()],diagonal:vec![1,-1]};
        assert!(r.is_self_adjoint()); assert!(r.is_involutive());
        let p=r.plus_projector(); let m=r.minus_projector();
        assert_eq!(p.iter().zip(m.iter()).map(|(a,b)|a+b).collect::<Vec<_>>(), vec![1,1]);
    }
}
