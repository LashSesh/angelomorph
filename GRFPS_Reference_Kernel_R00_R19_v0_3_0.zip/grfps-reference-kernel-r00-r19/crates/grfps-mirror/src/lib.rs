use grfps_canon::digest_record;
use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MirrorState {
    pub candidate_class: Vec<String>,
    pub model_epoch: u64,
    pub evidence_constraints: Vec<Value>,
    pub nerve_ref: String,
    pub marginal_gain: f64,
    pub identifiability: f64,
    pub digest: String,
}

pub fn candidate_digest(candidates: &[String]) -> Result<String, serde_json::Error> {
    let mut c = candidates.to_vec(); c.sort();
    digest_record("GRFPS.MirrorCandidateClass", "1.0.0", &c, &[])
}
