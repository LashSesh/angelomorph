use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::BTreeMap;

pub type Digest = String;
pub type GeneId = String;
pub type TypeRef = String;

pub const RUNTIME_SURFACES: [&str; 12] = [
    "Binding", "CausalField", "PerceptualGenome", "OphanField",
    "SyntheticPercept", "InfogeneticMap", "ReflectionShell", "Gyrosphere",
    "Navigator", "EffectPort", "HumanView", "Ledger",
];
pub const LINEAGE_SURFACE: &str = "Lineage";

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum PulseStatus {
    Advance, Probe, Hold, Reanchor, Reacquire, Residualize, Act, Stop, Fail,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum DeterminismClass { Deterministic, Seeded, Quotiented }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IdentityLock {
    pub grfps_version: String,
    pub reference_kernel_version: String,
    pub spec_pdf_sha256: Digest,
    pub spec_tex_sha256: Digest,
    pub runtime_surfaces: Vec<String>,
    pub lineage_surface: String,
    pub boundary_ports: Vec<String>,
    pub surface_digest: Digest,
    pub digest: Digest,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RunDescriptor {
    pub run_id: String,
    pub version: String,
    pub identity_digest: Digest,
    pub domain: String,
    pub models: Vec<String>,
    pub tolerances: BTreeMap<String, Value>,
    pub budgets: BTreeMap<String, Value>,
    pub policies: BTreeMap<String, Value>,
    pub seeds: BTreeMap<String, Value>,
    pub clocks: BTreeMap<String, Value>,
    pub adapters: Vec<String>,
    pub conformance: Vec<String>,
    pub digest: Digest,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorSpec {
    pub operator_id: String,
    pub version: String,
    pub family: String,
    pub domain: TypeRef,
    pub codomain: TypeRef,
    pub determinism: DeterminismClass,
    pub capability_namespace: String,
    pub preconditions: Vec<String>,
    pub postconditions: Vec<String>,
    pub witness_products: Vec<String>,
    pub residue_classes: Vec<String>,
    pub trace_fields: Vec<String>,
    pub budget_class: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResoniteGene {
    pub id: GeneId,
    pub input_type: TypeRef,
    pub output_type: TypeRef,
    pub operator_ref: Digest,
    pub quantizer: String,
    pub scale_scope: Vec<String>,
    pub phase_scope: Vec<String>,
    pub witness_contract: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GenericGene {
    pub id: GeneId,
    #[serde(default)] pub operator_ref: Option<Digest>,
    #[serde(default)] pub operator_refs: Vec<Digest>,
    #[serde(default)] pub params: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OphanGene {
    pub id: GeneId,
    pub aperture: Value,
    pub rotor_profile: Value,
    pub projection_profile: Value,
    pub operator_refs: Vec<Digest>,
    pub scheduler_features: Value,
    pub closure_contract: Value,
    pub budgets: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PerceptualGenome {
    pub genome_id: String,
    pub version: String,
    pub lineage: Vec<Digest>,
    pub observables: Vec<ResoniteGene>,
    pub relations: Vec<GenericGene>,
    pub ophan_templates: Vec<OphanGene>,
    pub scale_lattice: Value,
    pub phase_profiles: Vec<GenericGene>,
    pub attractor_programs: Vec<GenericGene>,
    pub boundary_programs: Vec<GenericGene>,
    pub render_grammar: Vec<GenericGene>,
    pub evolution_programs: Vec<GenericGene>,
    pub quantization: Value,
    pub tolerances: Value,
    pub budgets: Value,
    pub conformance: Value,
    #[serde(default)] pub digest: Option<Digest>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GenomeCompileManifest {
    pub genome_ref: Digest,
    pub resolved_refs: Vec<Value>,
    pub type_report: Value,
    pub linked_operators: Vec<Digest>,
    pub scheduler_plan: Value,
    pub registry_digest: Digest,
    pub digest: Digest,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PerceptualProgram {
    pub genome_ref: Digest,
    pub compile_manifest_ref: Digest,
    pub operator_dag: Vec<Digest>,
    pub gene_order: Vec<GeneId>,
    pub scale_lattice: Value,
    pub attractor_programs: Vec<GenericGene>,
    pub boundary_programs: Vec<GenericGene>,
    pub render_grammar: Vec<GenericGene>,
    pub digest: Digest,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TraceSegment {
    pub run_ref: Digest,
    pub parent_digest: Option<Digest>,
    pub input_digest: Digest,
    pub operator: String,
    pub pre_digest: Digest,
    pub post_digest: Digest,
    pub witnesses: Vec<String>,
    pub residues: Vec<String>,
    pub clocks: Value,
    pub determinism: String,
    pub digest: Digest,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayManifest {
    pub run_descriptor_ref: Digest,
    pub input_sequence: Vec<Value>,
    pub checkpoints: Vec<Value>,
    pub trace_head: Digest,
    pub expected_digests: BTreeMap<String, Digest>,
    pub tolerance_profile: String,
    pub result: String,
    pub digest: Digest,
}
