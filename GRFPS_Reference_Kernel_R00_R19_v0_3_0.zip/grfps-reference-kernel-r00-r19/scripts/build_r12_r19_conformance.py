from __future__ import annotations
import hashlib, json
from pathlib import Path
from typing import Any
from jsonschema import Draft202012Validator

from grfps_refkernel.canon import digest_record
from grfps_refkernel.cartography import CartographicRuntime
from grfps_refkernel.ledger import Ledger
from grfps_refkernel.operator import OperatorRegistry

ROOT=Path(__file__).resolve().parents[1]

def load(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def evidence_graph():
    return {
      'nodes':[{'id':x,'label':'node'} for x in 'abcdefg'],
      'edges':[
        {'source':'a','target':'b'},{'source':'b','target':'c'},{'source':'c','target':'a'},
        {'source':'c','target':'d'},{'source':'d','target':'e'},{'source':'e','target':'f'},
        {'source':'f','target':'g'}
      ]
    }

def candidate_models():
    return [
      {'id':'path-family','features':{'components':1,'cycle_rank':0}},
      {'id':'lollipop-family','features':{'components':1,'cycle_rank':1}},
      {'id':'double-cycle-family','features':{'components':1,'cycle_rank':2}},
      {'id':'split-family','features':{'components':2,'cycle_rank':1}},
    ]

def constraints(): return [{'feature':'components','value':1},{'feature':'cycle_rank','value':1}]

def execute_once(parent_exit: str, genome_ref: str):
    graph=evidence_graph(); ledger=Ledger(digest_record('GRFPS.RunDescriptor.R12-R19','1.0.0',{'parent':parent_exit,'genome':genome_ref,'world':'cartographic-reference'}))
    runtime=CartographicRuntime(radius=1)
    cycle=runtime.run(evidence_graph=graph,origin={'source_digest':digest_record('GRFPS.SyntheticGraphWorld','1.0.0',graph),'window':'world-0','adapter':'SyntheticGraphAdapter/v1'},candidate_models=candidate_models(),mirror_constraints=constraints(),genome_ref=genome_ref,model_epoch=0,scale='meso',ledger=ledger)
    checkpoint=ledger.checkpoint({'InfogeneticMap':cycle['graph_infogenome']['digest'],'SyntheticPercept':cycle['mirror_state']['digest'],'ReflectionShell':cycle['reflection_state']['digest'],'Navigator':{'horizon_ref':cycle['horizon_state']['digest']},'Ledger':{'trace_head':ledger.head},'status':'ADVANCE'},len(ledger.segments))
    manifest=ledger.to_manifest(ledger.run_ref,[{'kind':'SyntheticGraphWorld','digest':digest_record('GRFPS.SyntheticGraphWorld','1.0.0',graph)}],{'cycle':cycle['digest'],'graph_infogenome':cycle['graph_infogenome']['digest'],'glue':cycle['gluing_certificate']['digest'],'nerve':cycle['nerve_state']['digest'],'mirror':cycle['mirror_state']['digest'],'reflection':cycle['reflection_state']['digest'],'horizon':cycle['horizon_state']['digest'],'atlas':cycle['atlas_state']['digest'],'checkpoint':checkpoint['digest'],'trace_head':ledger.head or ''})
    return {'cycle':cycle,'trace':[x.to_dict() for x in ledger.segments],'checkpoint':checkpoint,'replay_manifest':manifest,'chain_valid':ledger.verify_chain()}

def validate(bundle):
    c=bundle['cycle']
    pairs=[
      ('graph-window-record.schema.json',c['graph_windows']),('graph-resonite-record.schema.json',c['graph_resonites']),('graph-infogenome-record.schema.json',[c['graph_infogenome']]),('gluing-certificate.schema.json',[c['gluing_certificate']]),('nerve-state.schema.json',[c['nerve_state']]),('mirror-state.schema.json',[c['mirror_state']]),('reflection-state.schema.json',[c['reflection_state']]),('horizon-state.schema.json',[c['horizon_state']]),('atlas-state.schema.json',[c['atlas_state']]),('cartographic-cycle.schema.json',[c])]
    for name, records in pairs:
        validator=Draft202012Validator(load(ROOT/'schemas'/name))
        for r in records: validator.validate(r)

def main():
    parent=load(ROOT/'conformance/r06-r11-exit.json')
    adaptive=load(ROOT/'examples/adaptive-ophan-run-bundle.json')
    genome_ref=adaptive['genome_ref']
    registry=OperatorRegistry.r00_r19_registry().snapshot()
    (ROOT/'registry/cartographic-registry.json').write_text(json.dumps(registry,indent=2,sort_keys=True)+'\n')
    a=execute_once(parent['exit_digest'],genome_ref); b=execute_once(parent['exit_digest'],genome_ref)
    validate(a)
    cycle=a['cycle']
    replay_equal=a['replay_manifest']['expected_digests']==b['replay_manifest']['expected_digests']
    stage={
      'reference_kernel_version':'0.3.0','grfps_version':'3.0.0','parent_exit_digest':parent['exit_digest'],'cartographic_registry_digest':registry['digest'],
      'R12':{'name':'GraphWindow Scanner','digest':digest_record('GRFPS.GraphWindowSet','1.0.0',[x['digest'] for x in cycle['graph_windows']]),'window_count':len(cycle['graph_windows']),'status':'SEALED'},
      'R13':{'name':'GraphResonites','digest':digest_record('GRFPS.GraphResoniteSet','1.0.0',[x['digest'] for x in cycle['graph_resonites']]),'resonite_count':len(cycle['graph_resonites']),'status':'SEALED'},
      'R14':{'name':'GraphInfogenome','digest':cycle['graph_infogenome']['digest'],'member_count':len(cycle['graph_infogenome']['members']),'status':'SEALED'},
      'R15':{'name':'Gluing Engine','digest':cycle['gluing_certificate']['digest'],'seam_count':len(cycle['gluing_certificate']['seams']),'status':'SEALED'},
      'R16':{'name':'Nerve Complex','digest':cycle['nerve_state']['digest'],'simplex_count':len(cycle['nerve_state']['simplices']),'higher_witness_count':len(cycle['nerve_state']['higher_witnesses']),'status':'SEALED'},
      'R17':{'name':'Mirror Engine','digest':cycle['mirror_state']['digest'],'candidate_count':len(cycle['mirror_state']['candidate_class']),'identifiability':cycle['mirror_state']['identifiability'],'status':'SEALED'},
      'R18':{'name':'Reflection Shell','digest':cycle['reflection_state']['digest'],'region_measure':cycle['reflection_state']['region']['measure'],'self_adjoint':cycle['reflection_state']['reflection_operator']['self_adjoint'],'involutive':cycle['reflection_state']['reflection_operator']['involutive'],'status':'SEALED'},
      'R19':{'name':'Phase Horizon','digest':cycle['horizon_state']['digest'],'current_count':len(cycle['horizon_state']['current']),'counterfactual_count':len(cycle['horizon_state']['counterfactual']),'open_count':len(cycle['horizon_state']['open']),'atlas_digest':cycle['atlas_state']['digest'],'status':'SEALED'},
      'replay_equal':replay_equal,'trace_chain_valid':a['chain_valid'],'schema_validation':'PASS'
    }
    stage['exit_digest']=digest_record('GRFPS.R12-R19.Exit','0.3.0',stage,(parent['exit_digest'],))
    ep=ROOT/'examples/cartographic-run-bundle.json'; ep.write_text(json.dumps(a,indent=2,sort_keys=True)+'\n')
    sp=ROOT/'conformance/r12-r19-exit.json'; sp.write_text(json.dumps(stage,indent=2,sort_keys=True)+'\n')
    release={'release':'GRFPS Reference Kernel R00-R19 v0.3.0','parent':load(ROOT/'conformance/r00-r11-release.json'),'cartographic_stage':stage,'files':{'cartographic_run_sha256':sha(ep),'stage_exit_sha256':sha(sp),'cartographic_registry_sha256':sha(ROOT/'registry/cartographic-registry.json'),'schema_manifest_sha256':sha(ROOT/'schemas/record-lock-manifest-r12-r19.json')}}
    release['digest']=digest_record('GRFPS.R00-R19.Release','0.3.0',release,(stage['exit_digest'],))
    (ROOT/'conformance/r00-r19-release.json').write_text(json.dumps(release,indent=2,sort_keys=True)+'\n')
    print(json.dumps(stage,indent=2,sort_keys=True))
if __name__=='__main__': main()
