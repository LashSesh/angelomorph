from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from grfps_refkernel.adaptive import AdaptiveOphanField
from grfps_refkernel.canon import digest_record
from grfps_refkernel.genome import GenomeCompiler
from grfps_refkernel.identity import IdentityLock
from grfps_refkernel.ledger import Ledger
from grfps_refkernel.operator import OperatorRegistry

ROOT = Path(__file__).resolve().parents[1]


def file_sha(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def identity_lock() -> IdentityLock:
    data = load_json(ROOT / "conformance/identity-lock.json")
    return IdentityLock(
        grfps_version=data["grfps_version"],
        reference_kernel_version=data["reference_kernel_version"],
        spec_pdf_sha256=data["spec_pdf_sha256"],
        spec_tex_sha256=data["spec_tex_sha256"],
    )


def run_descriptor(identity: IdentityLock, genome_ref: str, registry_ref: str) -> dict[str, Any]:
    payload = {
        "run_id": "run-adaptive-ophan-reference-0001",
        "version": "0.2.0",
        "identity_digest": identity.digest,
        "domain": "synthetic-ophan-field",
        "models": ["GRFPS-v3", "R06-R11"],
        "tolerances": {"canonical": "exact", "dependency_similarity": 0.985},
        "budgets": {"active_ophanim": 3, "cost": 4.0, "risk": 1.0},
        "policies": {"scheduler": "grfps-reference-utility-v1", "tie_break": "digest-ascending"},
        "seeds": {"primary": 0},
        "clocks": {"event": 0, "epoch": 0, "lineage": 0},
        "adapters": ["SyntheticOphanFieldAdapter/v1"],
        "conformance": ["C00", "C01", "C02", "C03", "C04", "C05", "C15"],
        "genome_ref": genome_ref,
        "registry_ref": registry_ref,
    }
    out = dict(payload)
    out["digest"] = digest_record("GRFPS.RunDescriptor.R06-R11", "1.0.0", payload, (identity.digest, genome_ref, registry_ref))
    return out


def execute_once(identity: IdentityLock, canonical_genome: dict[str, Any], registry_snapshot: dict[str, Any]) -> dict[str, Any]:
    rd = run_descriptor(identity, canonical_genome["digest"], registry_snapshot["digest"])
    ledger = Ledger(rd["digest"])
    field = AdaptiveOphanField(
        registry=OperatorRegistry.core_registry(),
        genome=canonical_genome,
        center_binding=digest_record("GRFPS.CenterBinding.Reference", "1.0.0", {"center":"first-person-origin"}, (identity.digest,)),
        max_active=3,
    )
    contexts = [
        {"axis": [1.0, 0.0, 0.0], "role": "alpha"},
        {"axis": [0.0, 1.0, 0.0], "role": "beta"},
        {"axis": [0.0, 0.0, 1.0], "role": "diagonal"},
    ]
    field.initial_spawn(contexts, ledger=ledger)
    cycle = field.run_cycle(
        world_payload={
            "world_id": "synthetic://ophan-field/reference",
            "channels": {"alpha": 1.0, "beta": 2.0},
            "event": 0,
            "scale": "meso",
        },
        ledger=ledger,
        budget={"cost": 4.0, "risk": 1.0},
    )
    runtime_state = {
        "Binding": {"run_ref": rd["digest"], "center_binding": field.center_binding},
        "CausalField": {"world": "synthetic://ophan-field/reference"},
        "PerceptualGenome": {"genome_ref": canonical_genome["digest"]},
        "OphanField": {"bank_ref": cycle["bank"]["digest"], "graph_ref": cycle["coherence_graph"]["digest"]},
        "SyntheticPercept": {"exposure_refs": [x["digest"] for x in cycle["exposures"]]},
        "InfogeneticMap": {}, "ReflectionShell": {}, "Gyrosphere": {}, "Navigator": {}, "EffectPort": {}, "HumanView": {},
        "Ledger": {"trace_head": ledger.head},
        "status": "ADVANCE",
        "update_index": len(ledger.segments),
    }
    checkpoint = ledger.checkpoint(runtime_state, runtime_state["update_index"])
    expected = {
        "templates": digest_record("GRFPS.OphanTemplateSet", "1.0.0", [t["digest"] for t in cycle["templates"]], (canonical_genome["digest"],)),
        "bank": cycle["bank"]["digest"],
        "exposures": digest_record("GRFPS.ExposureSet", "1.0.0", [x["digest"] for x in cycle["exposures"]]),
        "coherence_graph": cycle["coherence_graph"]["digest"],
        "dependency": cycle["dependency_profile"]["digest"],
        "scheduler": cycle["scheduler_decision"]["digest"],
        "cycle": cycle["digest"],
        "checkpoint": checkpoint["digest"],
        "trace_head": ledger.head or "",
    }
    replay_manifest = ledger.to_manifest(
        rd["digest"],
        input_sequence=[{"kind":"PerceptualGenome","digest":canonical_genome["digest"]},{"kind":"SyntheticWorldEvent","digest":digest_record("GRFPS.WorldEvent", "1.0.0", {"channels":{"alpha":1.0,"beta":2.0},"event":0,"scale":"meso"})}],
        expected_digests=expected,
    )
    return {
        "run_descriptor": rd,
        "genome_ref": canonical_genome["digest"],
        "adaptive_registry": registry_snapshot,
        "adaptive_cycle": cycle,
        "runtime_state": runtime_state,
        "trace": [s.to_dict() for s in ledger.segments],
        "checkpoint": checkpoint,
        "replay_manifest": replay_manifest,
        "chain_valid": ledger.verify_chain(),
    }


def validate_bundle(bundle: dict[str, Any]) -> None:
    validators = {
        "ophan-template.schema.json": bundle["adaptive_cycle"]["templates"],
        "ophan-state.schema.json": bundle["adaptive_cycle"]["bank"]["states"],
        "exposure-state.schema.json": bundle["adaptive_cycle"]["exposures"],
        "coherence-graph.schema.json": [bundle["adaptive_cycle"]["coherence_graph"]],
        "dependency-profile.schema.json": [bundle["adaptive_cycle"]["dependency_profile"]],
        "scheduler-decision.schema.json": [bundle["adaptive_cycle"]["scheduler_decision"]],
        "ophan-bank.schema.json": [bundle["adaptive_cycle"]["bank"]],
        "adaptive-ophan-cycle.schema.json": [bundle["adaptive_cycle"]],
    }
    for schema_name, records in validators.items():
        schema = load_json(ROOT / "schemas" / schema_name)
        validator = Draft202012Validator(schema)
        for record in records:
            validator.validate(record)


def main() -> None:
    parent = load_json(ROOT / "conformance/r00-r05-exit.json")
    identity = identity_lock()
    schema = load_json(ROOT / "schemas/perceptual-genome.schema.json")
    genome_source = load_json(ROOT / "genomes/reference-ophan-field.pgen.json")
    canonical_genome, compiled = GenomeCompiler(OperatorRegistry.core_registry(), schema).compile(genome_source)
    registry = OperatorRegistry.r00_r11_registry().snapshot()
    (ROOT / "registry/adaptive-registry.json").write_text(json.dumps(registry, indent=2, sort_keys=True) + "\n")

    first = execute_once(identity, canonical_genome, registry)
    second = execute_once(identity, canonical_genome, registry)
    validate_bundle(first)
    replay_equal = first["replay_manifest"]["expected_digests"] == second["replay_manifest"]["expected_digests"]

    cycle = first["adaptive_cycle"]
    stage = {
        "reference_kernel_version": "0.2.0",
        "grfps_version": "3.0.0",
        "parent_exit_digest": parent["exit_digest"],
        "adaptive_genome_digest": canonical_genome["digest"],
        "compile_manifest_digest": compiled["manifest"]["digest"],
        "adaptive_registry_digest": registry["digest"],
        "R06": {"name":"Ophan Template","digest":first["replay_manifest"]["expected_digests"]["templates"],"template_count":len(cycle["templates"]),"status":"SEALED"},
        "R07": {"name":"Wing Runtime","digest":first["replay_manifest"]["expected_digests"]["exposures"],"exposure_count":len(cycle["exposures"]),"trace_bound":True,"status":"SEALED"},
        "R08": {"name":"Multi-Ophan Bank","digest":cycle["bank"]["digest"],"active_count":len([s for s in cycle["bank"]["states"] if s["lifecycle"]=="ACTIVE"]),"max_active":cycle["bank"]["max_active"],"status":"SEALED"},
        "R09": {"name":"Coherence Graph","digest":cycle["coherence_graph"]["digest"],"node_count":len(cycle["coherence_graph"]["nodes"]),"edge_count":len(cycle["coherence_graph"]["edges"]),"status":"SEALED"},
        "R10": {"name":"Scheduler","digest":cycle["scheduler_decision"]["digest"],"selected_count":len(cycle["scheduler_decision"]["selected"]),"status":"SEALED"},
        "R11": {"name":"Dependency Quotient","digest":cycle["dependency_profile"]["digest"],"effective_rank":cycle["dependency_profile"]["effective_rank"],"cluster_count":len(cycle["dependency_profile"]["clusters"]),"status":"SEALED"},
        "replay_equal": replay_equal,
        "trace_chain_valid": first["chain_valid"],
        "schema_validation": "PASS",
    }
    stage["exit_digest"] = digest_record("GRFPS.R06-R11.Exit", "0.2.0", stage, (parent["exit_digest"],))

    cumulative = {
        "release": "GRFPS Reference Kernel R00-R11 v0.2.0",
        "parent": parent,
        "adaptive_stage": stage,
        "identity_digest": identity.digest,
        "spec_binding": load_json(ROOT / "docs/SPEC_BINDING.json"),
        "files": {},
    }
    first_path = ROOT / "examples/adaptive-ophan-run-bundle.json"
    first_path.write_text(json.dumps(first, indent=2, sort_keys=True) + "\n")
    stage_path = ROOT / "conformance/r06-r11-exit.json"
    stage_path.write_text(json.dumps(stage, indent=2, sort_keys=True) + "\n")
    cumulative["files"] = {
        "adaptive_run_sha256": file_sha(first_path),
        "stage_exit_sha256": file_sha(stage_path),
        "adaptive_registry_sha256": file_sha(ROOT / "registry/adaptive-registry.json"),
        "adaptive_genome_sha256": file_sha(ROOT / "genomes/reference-ophan-field.pgen.json"),
    }
    cumulative["digest"] = digest_record("GRFPS.R00-R11.Release", "0.2.0", cumulative, (stage["exit_digest"],))
    (ROOT / "conformance/r00-r11-release.json").write_text(json.dumps(cumulative, indent=2, sort_keys=True) + "\n")
    print(json.dumps(stage, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
