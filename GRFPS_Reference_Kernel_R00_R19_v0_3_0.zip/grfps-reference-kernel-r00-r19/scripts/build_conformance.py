from __future__ import annotations

import hashlib
import json
from pathlib import Path

from jsonschema import Draft202012Validator

from grfps_refkernel.canon import canonical_json, digest_record
from grfps_refkernel.genome import GenomeCompiler
from grfps_refkernel.identity import IdentityLock
from grfps_refkernel.kernel import ReferenceKernel
from grfps_refkernel.operator import OperatorRegistry
from grfps_refkernel.synthworld import SyntheticWorldAdapter, SyntheticWorldSpec

ROOT = Path(__file__).resolve().parents[1]


def file_sha(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def schema_bundle_digest() -> str:
    # R01 is a sealed parent artifact. Its digest is computed only from the
    # schema files that existed in the R00-R05 release; later extension schemas
    # belong to their own stage manifest.
    locked = (
        "identity-lock.schema.json",
        "replay-manifest.schema.json",
        "compile-manifest.schema.json",
        "record-lock-manifest.json",
        "perceptual-genome.schema.json",
        "trace-segment.schema.json",
        "run-descriptor.schema.json",
    )
    parts = []
    for name in sorted(locked):
        path = ROOT / "schemas" / name
        parts.append({"name": path.name, "sha256": file_sha(path)})
    return digest_record("GRFPS.SchemaBundle", "1.0.0", parts)


def main() -> None:
    identity_data = json.loads((ROOT / "conformance/identity-lock.json").read_text())
    identity = IdentityLock(
        grfps_version=identity_data["grfps_version"],
        reference_kernel_version=identity_data["reference_kernel_version"],
        spec_pdf_sha256=identity_data["spec_pdf_sha256"],
        spec_tex_sha256=identity_data["spec_tex_sha256"],
    )
    genome_schema = json.loads((ROOT / "schemas/perceptual-genome.schema.json").read_text())
    genome = json.loads((ROOT / "genomes/reference-minimal.pgen.json").read_text())
    kernel = ReferenceKernel.build(identity, genome_schema)
    world = SyntheticWorldAdapter(
        SyntheticWorldSpec(
            world_id="world.kernel.empty",
            world_type="kernel-empty",
            clock="clock://event",
            scales=("micro", "meso", "macro"),
            attractors=("attractor.kernel-closure",),
            boundary_topology="point-boundary",
            sealed_ground_truth_digest="1" * 64,
        )
    )
    bundle = kernel.empty_run(genome=genome, world=world)
    replay = kernel.replay_empty_run(bundle, genome, world)

    Draft202012Validator(json.loads((ROOT / "schemas/identity-lock.schema.json").read_text())).validate(bundle["identity_lock"])
    Draft202012Validator(genome_schema).validate(genome)
    Draft202012Validator(json.loads((ROOT / "schemas/run-descriptor.schema.json").read_text())).validate(bundle["run_descriptor"])
    Draft202012Validator(json.loads((ROOT / "schemas/compile-manifest.schema.json").read_text())).validate(bundle["compile_manifest"])
    trace_schema = json.loads((ROOT / "schemas/trace-segment.schema.json").read_text())
    for segment in bundle["trace"]:
        Draft202012Validator(trace_schema).validate(segment)
    Draft202012Validator(json.loads((ROOT / "schemas/replay-manifest.schema.json").read_text())).validate(bundle["replay_manifest"])

    compiler = GenomeCompiler(OperatorRegistry.core_registry(), genome_schema)
    canonical_genome, compiled = compiler.compile(genome)
    stage = {
        "reference_kernel_version": "0.1.0",
        "grfps_version": "3.0.0",
        "R00": {
            "name": "Identity Lock",
            "digest": identity.digest,
            "surface_digest": identity.surface_digest,
            "status": "SEALED",
        },
        "R01": {
            "name": "Schema Lock",
            "digest": schema_bundle_digest(),
            "record_family_count": len(json.loads((ROOT / "schemas/record-lock-manifest.json").read_text())["record_families"]),
            "status": "SEALED",
        },
        "R02": {
            "name": "Kernel Skeleton",
            "digest": kernel.registry.snapshot()["digest"],
            "operator_count": len(kernel.registry.snapshot()["entries"]),
            "trace_chain_valid": bundle["chain_valid"],
            "status": "SEALED",
        },
        "R03": {
            "name": "Empty Run",
            "digest": bundle["sealed_run"]["digest"],
            "checkpoint_digest": bundle["checkpoints"][-1]["digest"],
            "replay_equal": replay["equal"],
            "status": "SEALED",
        },
        "R04": {
            "name": "Genome AST",
            "digest": canonical_genome["digest"],
            "normal_form_digest": digest_record("GRFPS.GenomeNormalForm", "1.0.0", json.loads(canonical_json({k:v for k,v in canonical_genome.items() if k != "digest"}))),
            "status": "SEALED",
        },
        "R05": {
            "name": "Genome Compiler",
            "digest": compiled["manifest"]["digest"],
            "program_digest": compiled["program"]["digest"],
            "linked_operator_count": len(compiled["manifest"]["linked_operators"]),
            "status": "SEALED",
        },
    }
    stage["exit_digest"] = digest_record("GRFPS.R00-R05.Exit", "0.1.0", stage)
    (ROOT / "examples/empty-run-bundle.json").write_text(json.dumps(bundle, indent=2, sort_keys=True))
    (ROOT / "conformance/r00-r05-exit.json").write_text(json.dumps(stage, indent=2, sort_keys=True))
    print(json.dumps(stage, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
