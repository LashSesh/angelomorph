# R12–R19 — Graph-Infogenetic Cartography

## Canonical vertical

```text
EvidenceGraph
  -> GraphWindowSet
  -> GraphResoniteSet
  -> GraphInfogenome
  -> GluingCertificate
  -> NerveState
  -> MirrorState
  -> ReflectionState
  -> HorizonState + AtlasState
```

## R12 — GraphWindow Scanner

A finite evidence graph is decomposed into deterministic local windows under a declared radius, scale and provenance binding. Each window carries a canonical graph, local membership and cut-boundary description.

## R13 — GraphResonites

Each window emits a multi-invariant structural gene carrying canonical graph identity, orbit/stabilizer counts, exact characteristic-polynomial spectrum signature, trace powers, graph properties, boundary and provenance.

## R14 — GraphInfogenome

Resonites form a content-addressed, provenance-bound normal form. Member ordering is canonical and replay-stable.

## R15 — Gluing Engine

Overlapping patches produce explicit compatibility values and SeamWitness records. The resulting GluingCertificate binds the overlap graph, compatibility matrix, seams, residues and replay digest into one local complex.

## R16 — Nerve Complex

Patches become vertices; certified pair overlaps become edges; common higher overlaps become higher simplices. Closed higher overlaps emit holonomy witnesses.

## R17 — Mirror Engine

A finite candidate fiber is contracted by typed evidence constraints. Each MirrorState records the current candidate class, evidence set, marginal contraction gain, identifiability and lineage digest.

## R18 — Reflection Shell

The reference shell uses an exact diagonal self-adjoint involution over the current patch basis. The plus projector selects the certified connected region and the minus projector carries the complementary open patch set. The region and boundary are content-addressed and renewal-ready.

## R19 — Phase Horizon

The phase horizon exposes three continuation classes: Current, Counterfactual and Open. A rolling atlas binds local charts, certified transitions, boundary lineage and horizon state into the first replayable synthetic operational map.

## Exit condition

R12–R19 is sealed when decomposition, multi-signature, provenance, gluing, nerve construction, candidate contraction, reflection identities, horizon partition, schema validation and replay all pass in the same deterministic reference run.
