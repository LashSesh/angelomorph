# GRFPS Reference Kernel v0.2.0 — R06–R11 Adaptive Ophan Field

**Normative parent:** GRFPS v3.0.0 — Generative Rotor-Fiber Perceptual Substrate  
**Parent exit:** `858e3d82787152c88edad97bb33acccd58b7479d6c6adad12b9ae29cd0678366`  
**Stage:** R06 Ophan Template → R07 Wing Runtime → R08 Multi-Ophan Bank → R09 Coherence Graph → R10 Scheduler → R11 Dependency Quotient

## 1. Stage normal form

The adaptive perceptual field is the first runtime organ layer above the R00–R05 machine floor.

```text
PerceptualGenome
  -> OphanTemplateSet
  -> OphanBank
  -> DirectedExposures
  -> CoherenceGraph
  -> DependencyProfile
  -> SchedulerDecision
```

The executable cycle is

\[
\Gamma_P
\xrightarrow{CompileOphan}
\{T_i\}
\xrightarrow{Spawn/Reuse}
\mathcal O_t
\xrightarrow{Expose}
\mathcal W_t
\xrightarrow{Graphify}
G_t
\xrightarrow{Q_D}
\bar G_t
\xrightarrow{Schedule}
\Pi_t.
\]

Every emitted record is canonicalized, content-addressed and linked to the parent GRFPS v3 identity surface.

## 2. R06 — Ophan Template

An `OphanGene` from the compiled Perceptual Genome is linked against the content-addressed operator registry and becomes an `OphanTemplate`:

\[
T_i=(g_i,\Gamma_i,A_i,R_i,\Pi_i,\Omega_i,F_i,C_i,B_i,W_i).
\]

The record carries:

- genome and lineage binding,
- aperture specification,
- cyclic rotor profile,
- projection profile,
- resolved operator graph,
- scheduler features,
- closure contract,
- runtime budgets,
- witness contract.

The reference genome contains three templates with complementary channel projections and distinct rotor phases. This gives the next stages a finite field with independently measurable response directions.

## 3. R07 — Wing Runtime

The lifecycle is

```text
TEMPLATE -> INSTANTIATED -> CALIBRATED -> ACTIVE -> QUIESCENT -> RETIRED
```

An active Ophan emits a directed exposure

\[
W_i(t)=Expose(O_i,\theta_i(t),B_t,C_t).
\]

The exposure carries `ophan_ref`, phase, axis, sector, sheet, orientation, projected payload, witnesses, event index and digest. The reference rotor advances on `S1`; each exposure therefore has a reproducible cyclic successor.

The runtime binds every exposure to the append-only Ledger through `ophan.expose` trace segments.

## 4. R08 — Multi-Ophan Bank

The bank maintains a finite active organ set

\[
\mathcal O_t=\{O_1,\ldots,O_n\},\qquad n\le B_{active}.
\]

It implements deterministic:

- `spawn_or_reuse`,
- activation and quiescence,
- retirement,
- active and total budget accounting,
- template/context indexing,
- bank history,
- bank digest.

Canonical template/context equality permits reuse of an existing compatible instance. Runtime capacity is therefore allocated to distinct active questions rather than duplicate instances.

## 5. R09 — Coherence Graph

The active bank is represented as

\[
G_t=(V_t,E_t,w_t,\phi_t,h_t).
\]

Each node stores an Ophan reference, response vector, current phase, confidence, stability vector and resource state. Pairwise edges carry relation type, weight, dependency estimate and optional Seam reference.

The reference compatibility kernel combines response-vector alignment and cyclic phase alignment. Node coherence is the normalized mean of incident edge weights. The graph keeps an append-only local history and emits a canonical graph digest after every update.

## 6. R10 — Perceptual Scheduler

For each candidate the reference scheduler evaluates

\[
Score(o)=
\alpha IG(o)+\beta CG(o)+\gamma BG(o)+\eta TG(o)
-\lambda Cost(o)-\mu Risk(o)-\nu Red(o).
\]

The current reference implementation carries all seven terms explicitly. Selection proceeds by descending score with canonical digest order as deterministic tie-break. Cost and risk budgets are consumed by selected candidates.

The output is a `SchedulerDecision` containing:

- declared weights,
- full ranked candidate set,
- selected candidates,
- held candidates,
- remaining budget,
- decision digest.

## 7. R11 — Dependency Quotient

A response family is represented by vectors

\[
Y=\{y_i\in\mathbb R^m\}.
\]

The reference quotient computes:

- pairwise cosine similarity,
- similarity-connected dependency clusters,
- deterministic cluster representatives,
- Gaussian-elimination effective rank,
- per-item redundancy,
- dependency-adjusted evidence weights.

For a cluster of size `k`, the reference evidence weight is `1/k`. Independent singleton directions retain weight `1`. The rank is computed from the response matrix and therefore remains distinct from raw organ count.

The reference three-Ophan conformance world produces effective rank `3` from three complementary response directions.

## 8. Canonical records added in v0.2.0

The R06–R11 schema extension introduces:

```text
OphanTemplate
OphanState
ExposureState
OphanBank
CoherenceNode
CoherenceEdge
CoherenceGraph
DependencyProfile
SchedulerCandidate
SchedulerDecision
AdaptiveOphanFieldCycle
```

The parent R01 schema digest remains fixed. R06–R11 owns a separate extension manifest in `schemas/record-lock-manifest-r06-r11.json`.

## 9. Operator registry extension

The cumulative registry adds the following operator contracts above the sealed R00–R05 core:

```text
ophan.compileOphan
ophan.spawnOphan
ophan.calibrateOphan
ophan.activateOphan
ophan.expose
ophan.retireOphan
coherence.buildOperatorGraph
coherence.updateCoherence
coherence.quotientDependencies
coherence.scoreCandidate
coherence.allocateBudget
coherence.reconfigureGraph
```

The R00–R05 registry remains available as `OperatorRegistry.core_registry()`. The cumulative runtime registry is emitted as `registry/adaptive-registry.json`.

## 10. Reference conformance cycle

The sealed reference cycle uses three Ophan templates:

```text
alpha-axis probe
beta-axis probe
diagonal probe
```

and a synthetic two-channel world payload. The three directed projections generate a response matrix with effective rank `3`. The run emits:

1. template witnesses,
2. spawn/budget witnesses,
3. exposure witnesses,
4. coherence graph,
5. dependency quotient,
6. scheduler decision,
7. checkpoint,
8. replay manifest.

The same canonical inputs reproduce the same stage digests and trace head.

## 11. R06–R11 exit contract

R06–R11 is sealed when:

- every Ophan template resolves all operator references,
- every instance follows the declared lifecycle,
- every exposure is phase- and trace-bound,
- active-bank capacity is enforced,
- coherence graph construction is deterministic,
- scheduler ranking and budget allocation are deterministic,
- dependency rank and redundancy are materialized separately,
- JSON Schema validation passes,
- the Ledger chain verifies,
- exact replay reproduces all expected digests.

The canonical result is stored in `conformance/r06-r11-exit.json`.

## 12. Handoff to R12–R19

The next vertical consumes only the sealed R00–R11 artifacts and materializes the self-organizing structural map:

```text
R12 GraphWindow Scanner
R13 GraphResonites
R14 GraphInfogenome
R15 Gluing Engine
R16 Nerve Complex
R17 Mirror Engine
R18 Reflection Region
R19 Phase Horizon / Rolling Atlas
```

Its input surface is now concrete: directed Ophan exposures, an adaptive coherence graph, a dependency-adjusted response family and a deterministic scheduler trace.
