# R00–R05 Reference Kernel

## 1. Sediment

The stage establishes a content-addressed machine floor for GRFPS v3.0.0. Every subsequent runtime object binds through the same identity surface, canonical serialization, operator registry, genome lineage, trace chain and replay contract.

The stage state is:

\[
\mathcal K_{05}=
(I,S,\Omega,L,\Gamma,\mathcal C,P,W)
\]

with identity lock \(I\), schema bundle \(S\), operator registry \(\Omega\), ledger \(L\), canonical genome \(\Gamma\), genome compiler \(\mathcal C\), compiled perceptual program \(P\), and synthetic world adapter \(W\).

## 2. R00 — Identity Lock

R00 binds GRFPS v3.0.0 to the Reference Kernel by the source digests, the 12 runtime surfaces, the Lineage surface and the ABI boundary ports. The resulting `IdentityLock.digest` is the root parent of the machine lineage.

## 3. R01 — Schema Lock

R01 freezes the minimum semantics of 34 canonical record families. Core executable schemas cover IdentityLock, RunDescriptor, PerceptualGenome, GenomeCompileManifest, TraceSegment and ReplayManifest. `record-lock-manifest.json` freezes the complete v3 record-family vocabulary for later modules.

Canonical identity follows:

\[
id=H(type\Vert version\Vert canon(payload)\Vert parentDigests).
\]

## 4. R02 — Kernel Skeleton

R02 supplies the pulse status algebra, deterministic operator registry, content-addressed operator versions, append-only trace segments, checkpoints and replay manifests. The initial registry contains Constitution, Genome and Ledger operators required by the first machine floor.

## 5. R03 — Empty Run

R03 executes the minimum closed run:

```text
BindRun -> Load/Compile Genome -> Seal -> Checkpoint -> Replay
```

The run binds a SyntheticWorldAdapter, activates the canonical reference genome, records the transition chain, emits a sealed run digest and reproduces the same expected digest set under replay.

## 6. R04 — Perceptual Genome AST

R04 introduces the executable Genome package. Its normal form carries observables, relations, Ophan templates, scale lattice, phase profiles, attractor programs, boundary programs, render grammar, evolution programs, quantization, tolerances, budgets and conformance.

Normalization sorts identity-bearing gene families, stabilizes scale ordering and produces a canonical genome digest.

## 7. R05 — Genome Compiler

R05 implements the compiler pipeline:

```text
Parse -> Normalize -> Resolve -> Type -> Link -> Plan -> Seal
```

The compiler resolves operator digests against the Registry, validates observable input/output contracts, emits the deterministic scheduler plan, binds the registry digest, emits `GenomeCompileManifest`, then materializes a `PerceptualProgram`.

## 8. Exit state

The phase is represented by:

```text
conformance/r00-r05-exit.json
```

Every substage owns an independent digest and `SEALED` status. The aggregate `exit_digest` is the single carry-forward identity for R06–R11.
