# GRFPS Reference Kernel — R00–R19

**Version:** 0.3.0  
**Normative parent:** GRFPS v3.0.0 — Generative Rotor-Fiber Perceptual Substrate  
**Stage:** Machine Floor + Adaptive Ophan Field + Graph-Infogenetic Cartography

This repository materializes the cumulative GRFPS reference vertical through the first self-organizing synthetic map and phase horizon.

```text
R00 Identity Lock
R01 Schema Lock
R02 Kernel Skeleton
R03 Empty Run
R04 Genome AST
R05 Genome Compiler
R06 Ophan Template
R07 Wing Runtime
R08 Multi-Ophan Bank
R09 Coherence Graph
R10 Scheduler
R11 Dependency Quotient
R12 GraphWindow Scanner
R13 GraphResonites
R14 GraphInfogenome
R15 Gluing Engine
R16 Nerve Complex
R17 Mirror Engine
R18 Reflection Shell
R19 Phase Horizon
```

## Runtime normal form

```text
PerceptualGenome
  -> OphanField
  -> EvidenceWindows
  -> GraphWindows
  -> GraphResonites
  -> GraphInfogenome
  -> GluedPatchComplex
  -> NerveComplex
  -> MirrorFiber
  -> ReflectionRegion
  -> PhaseHorizon + RollingAtlas
```

The cartographic vertical turns local, provenance-bound observations into a replayable operational space. R12–R16 establish local structural identity and compatible gluing; R17 contracts a candidate mirror fiber; R18 certifies a self-adjoint reflective region; R19 exposes Current, Counterfactual and Open continuation charts.

## Execute conformance

```bash
./run_conformance.sh
```

The suite rebuilds all cumulative stage bundles, validates schemas, executes the Python semantic reference, and compiles/tests the Rust workspace when Cargo is available.

## Canonical handoff

`conformance/r12-r19-exit.json` is the parent artifact for R20.

The next vertical is:

```text
Scale Lattice -> Gyrosphere -> Axis Engine -> Tangent Compass
-> Attractor Runtime -> Density Renderer -> Desktop Second Layer
```
